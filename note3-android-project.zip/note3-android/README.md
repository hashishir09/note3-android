# Note3 Whiteboard (Android)

A native, offline-first Android whiteboard for teaching, handwriting, drawing and PDF annotation.
Kotlin, Jetpack Compose (UI), a custom `View` + Android Canvas (drawing), Room (project index),
JSON page files, Media3 ExoPlayer (playback). No ads, accounts, analytics or network access.

> **Verification status (read this first).** The pure-Kotlin logic (drawing engine, editing session,
> viewport, geometry tools, archive import/export) is covered by JVM unit tests that were compiled
> and run during development. The **Android layers (Compose UI, custom View, renderer, Room,
> recording service, exporter) were written without access to the Android SDK and have NOT been
> compiled or run on a device.** The first GitHub Actions run may reveal compile errors; see
> "If the build fails" below. Nothing in this repository claims a successful APK build until CI shows one.

## Build the debug APK (no computer needed)

1. Push this project to `https://github.com/hashishir09/note3-android` (branch `main`).
2. Open the repository's **Actions** tab → workflow **Build Debug APK** (runs on every push; or press *Run workflow*).
3. When it finishes, open the run and download the artifact **note3-debug-apk** (a zip containing `app-debug.apk`).
4. Unzip on the phone, allow "install unknown apps" for your file manager/browser, and install.

Local build (optional): JDK 17 + Android SDK 35, then `./gradlew :app:testDebugUnitTest :app:assembleDebug`.
APK: `app/build/outputs/apk/debug/app-debug.apk`.

### If the build fails
Open the failed step in Actions, copy the Kotlin error lines (`e: file:///...`) and send them back; each is
normally a one-line fix. The unit-test step runs first so engine regressions are caught before the APK step.

## Project layout

| Path | Responsibility |
|---|---|
| `engine/` | Pure Kotlin: element model, geometry, stroke smoothing, shape recognition, erasers, undo history, edit operations, layers, viewport, geometry aids |
| `editor/DrawingSession.kt` | Touch-to-edit logic for one page (tools, selection, text, layers, clipboard). No Android types |
| `render/` | `PageRenderer` (shared by screen and export), overlays, async bitmap cache, PDF page renderer, text layout |
| `ui/canvas/WhiteboardView.kt` | Custom View: stylus/finger input, palm rejection, pinch zoom/pan, cached live drawing |
| `ui/home`, `ui/editor`, `ui/components`, `ui/theme` | Compose screens: boards, settings, backup, editor panels, overlays |
| `data/` | Room (boards/pages index), crash-safe `PageStore`, `MediaFiles`, `ArchiveIO` (.n3wb zip), settings |
| `export/Exporter.kt` | PNG, JPG and vector PDF export |
| `recording/RecorderService.kt` | Screen recording (MediaProjection) with optional microphone |

Storage: each page is one JSON file written atomically (temp file → fsync → rename, previous version kept as `.bak`).
Imported images/PDFs/audio/video are copied into app storage so projects survive moving the originals.

## Features and status

Legend: **Unit-tested** = JVM tests pass · **Written** = implemented but not compiled/run (Android code).

### Drawing engine
| Feature | Status |
|---|---|
| Infinite canvas, zoom, pan, pinch (two fingers in any tool) | Written (viewport math unit-tested) |
| Finger and stylus; stylus pressure; palm rejection (stylus-only option); stylus eraser end / side button erases | Written (session logic unit-tested) |
| Smooth freehand pen, brush, highlighter; colors; widths | Written (stroke smoothing unit-tested) |
| Stroke eraser, partial ("intelligent") eraser | Unit-tested |
| Undo / redo | Unit-tested |
| Shape recognition (line, circle/ellipse, rectangle, triangle, polygon; Off / Hold / Always) | Unit-tested |
| Shape tools: line, arrow, circle, rectangle, triangle, tap-built polygon; fill; snap to grid | Unit-tested |
| Select (tap, lasso), move, resize, rotate | Unit-tested |
| Copy, cut, paste, duplicate, delete, group/ungroup, z-order | Unit-tested |
| Layers (add, rename, reorder, hide, lock, delete, move selection between layers) | Unit-tested |

### Content tools
| Feature | Status |
|---|---|
| Text boxes (create, edit, size, color) | Session unit-tested; dialog/rendering written |
| Image import (EXIF rotation, downsampling) | Written |
| PDF import and annotation (each PDF page becomes a page) | Written |
| Audio / video import and in-app playback (double-tap in Select mode) | Written |
| Paper: blank, grid, dots, lines; paper colors | Written |
| Ruler, set square, protractor (drag, rotate, resize; strokes snap straight to edges) | Unit-tested |
| Multiple pages: add, duplicate, delete, reorder, jump | Written |

### Teaching
| Feature | Status |
|---|---|
| Spotlight, screen cover (4 directions) | Written |
| Presentation mode (full screen, compact control bar, page turning, drawing stays on) | Written |
| Screen recording with optional microphone audio (saved to Movies/Note3) | Written |

### Storage and export
| Feature | Status |
|---|---|
| Automatic saving (0.7 s debounce, on page change, when the app goes to background) | Written |
| Offline database, backup & restore, project file import/export (`.n3wb`) | Archive format and safety checks unit-tested; Room/UI written |
| Export PNG, JPG, PDF (this page or all pages; PDF keeps vectors) | Written |

### Interface
Bottom navigation (portrait) / navigation rail (landscape), collapsible tool panel, compact floating top bar,
full-screen canvas, 48 dp touch targets, light/dark/system theme, portrait and landscape. Written, not run.

## Known limitations (honest list)

- **Handwriting recognition (handwriting → typed text) is not implemented.** Handwriting is supported as
  pressure-sensitive pen input with palm rejection. On-device recognition needs a model download, which
  conflicts with the free/offline requirement.
- **Undo history is per open page and is cleared when you switch pages or close the board.** Saved content is never lost.
- **PDF pages are rendered as bitmaps (max ~2000 px wide)**; extreme zoom on a PDF looks soft. Text in PDFs is not selectable.
- **Spotlight mode captures touches** (drawing is paused until it is switched off).
- **Screen recording captures the microphone only** (Android does not let apps record internal audio on all versions)
  and needs Android's screen-capture permission each time.
- No page thumbnails (pages are listed by number). No cloud sync (by design: offline only).
- Export area for pages without a PDF is the used region plus a margin (or a default sheet if empty).
- Video thumbnails are generated from the first frame; very large videos are not transcoded.
- Not yet verified on real devices: performance on low-RAM phones, stylus pressure on specific hardware,
  Media3 `PlayerView` theming, behaviour on Android 14+ for the recording service.

## Tests

`app/src/test` contains JVM unit tests for geometry, stroke processing, shape recognition, erasers, history,
edit operations, layers, viewport, geometry aids, the editing session and the archive format
(including path-traversal protection). Run: `./gradlew :app:testDebugUnitTest`.
