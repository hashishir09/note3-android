package com.hashishir.note3.engine

import com.hashishir.note3.engine.math.Rect
import com.hashishir.note3.engine.math.Vec
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.PI

class ViewportAndGeoToolTest {

    @Test fun coordinatesRoundTrip() {
        val v = Viewport(2f, 30f, -10f)
        assertEquals(50f, v.toWorldX(v.toScreenX(50f)), 1e-4f)
        assertEquals(-7f, v.toWorldY(v.toScreenY(-7f)), 1e-4f)
    }

    @Test fun zoomKeepsFocusPointFixed() {
        val v = Viewport(1f, 10f, 20f)
        val wx = v.toWorldX(300f)
        val wy = v.toWorldY(400f)
        v.zoomAt(2.5f, 300f, 400f)
        assertEquals(2.5f, v.scale, 1e-4f)
        assertEquals(300f, v.toScreenX(wx), 1e-3f)
        assertEquals(400f, v.toScreenY(wy), 1e-3f)
    }

    @Test fun zoomIsClamped() {
        val v = Viewport()
        v.zoomAt(1000f, 0f, 0f)
        assertEquals(Viewport.MAX_SCALE, v.scale, 1e-4f)
        v.zoomAt(1e-6f, 0f, 0f)
        assertEquals(Viewport.MIN_SCALE, v.scale, 1e-4f)
    }

    @Test fun fitCentersContent() {
        val v = Viewport()
        v.fit(Rect(0f, 0f, 1000f, 500f), 500f, 500f, padding = 0f)
        assertEquals(0.5f, v.scale, 1e-4f)
        assertEquals(250f, v.toScreenY(250f), 1e-3f)
        assertEquals(0f, v.toScreenX(0f), 1e-3f)
    }

    @Test fun visibleWorldMatchesPanAndZoom() {
        val v = Viewport(2f, -100f, -200f)
        val r = v.visibleWorld(400f, 600f)
        assertEquals(50f, r.left, 1e-3f)
        assertEquals(100f, r.top, 1e-3f)
        assertEquals(250f, r.right, 1e-3f)
        assertEquals(400f, r.bottom, 1e-3f)
    }

    @Test fun rulerHasTwoLongEdgesAndContainsItsCentre() {
        val g = GeoTool(GeoKind.RULER, 100f, 100f, 0f, 400f)
        assertEquals(2, g.edges().size)
        assertTrue(g.contains(100f, 100f))
        assertFalse(g.contains(100f, 300f))
        val (a, b) = g.edges()[0]
        assertEquals(400f, a.dist(b), 1e-3f)
    }

    @Test fun rotatedRulerStaysConsistent() {
        val g = GeoTool(GeoKind.RULER, 0f, 0f, (PI / 2).toFloat(), 200f)
        val h = g.handle()
        assertEquals(0f, h.x, 1e-3f)
        assertEquals(100f, h.y, 1e-3f)
    }

    @Test fun handleDragRotatesAndResizes() {
        val g = GeoTool(GeoKind.PROTRACTOR, 0f, 0f, 0f, 400f)
        val r = g.withHandleAt(0f, 300f)
        assertEquals((PI / 2).toFloat(), r.angle, 1e-3f)
        assertEquals(600f, r.size, 1e-2f)
    }

    @Test fun setSquareHasRightAngleCorner() {
        val g = GeoTool(GeoKind.SET_SQUARE, 0f, 0f, 0f, 300f)
        val p = g.polygon()
        val d1 = p[1] - p[0]
        val d2 = p[2] - p[0]
        assertEquals(0f, d1.dot(d2), 1e-2f)
        assertEquals(3, g.edges().size)
    }

    @Test fun protractorBaselineIsItsOnlyEdge() {
        val g = GeoTool(GeoKind.PROTRACTOR, 0f, 0f, 0f, 400f)
        assertEquals(1, g.edges().size)
        val (a, b) = g.edges()[0]
        assertEquals(400f, a.dist(b), 1e-2f)
        assertTrue(g.contains(0f, -100f))
        assertFalse(g.contains(0f, 100f))
    }

    @Test fun projectionIsClampedToSegment() {
        val p = GeoTool.projectOnSegment(500f, 30f, Vec(0f, 0f), Vec(100f, 0f))
        assertEquals(100f, p.x, 1e-4f)
        assertEquals(0f, p.y, 1e-4f)
        val q = GeoTool.projectOnSegment(40f, 30f, Vec(0f, 0f), Vec(100f, 0f))
        assertEquals(40f, q.x, 1e-4f)
    }

    @Test fun settingsWidthFollowsTool() {
        var s = ToolSettings(tool = Tool.BRUSH)
        s = s.withWidth(14f)
        assertEquals(14f, s.brushWidth, 0f)
        assertEquals(3f, s.penWidth, 0f)
        assertEquals(14f, s.width, 0f)
        val h = ToolSettings(tool = Tool.HIGHLIGHTER, color = 0xFFFF0000.toInt(), highlighterAlpha = 0x40)
        assertEquals(0x40, (h.inkColor ushr 24) and 0xFF)
        assertEquals(0xFF0000, h.inkColor and 0xFFFFFF)
    }
}
