package com.hashishir.note3.engine

import com.hashishir.note3.engine.math.Affine
import com.hashishir.note3.engine.math.Vec
import com.hashishir.note3.engine.model.Element
import com.hashishir.note3.engine.model.ImageElement
import com.hashishir.note3.engine.model.Layer
import com.hashishir.note3.engine.model.Pt
import com.hashishir.note3.engine.model.ShapeKind
import com.hashishir.note3.engine.model.StrokeElement
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNotSame
import org.junit.Assert.assertNull
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertSame
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.sin

class EngineTest {

    // ---------- helpers ----------

    private fun poly(vararg v: Pair<Float, Float>, step: Float = 4f, wobble: Float = 0f): List<Pt> {
        val out = ArrayList<Pt>()
        for (i in v.indices) {
            val a = v[i]
            val b = v[(i + 1) % v.size]
            val d = hypot(b.first - a.first, b.second - a.second)
            val n = (d / step).toInt().coerceAtLeast(1)
            for (k in 0 until n) {
                val t = k.toFloat() / n
                val w = wobble * sin((out.size) * 0.9f)
                out.add(Pt(a.first + (b.first - a.first) * t + w, a.second + (b.second - a.second) * t - w))
            }
        }
        out.add(out.first())
        return out
    }

    private fun circle(cx: Float, cy: Float, r: Float, n: Int = 90, noise: Float = 0.03f): List<Pt> =
        (0..n).map { i ->
            val th = 2.0 * PI * i / n * 1.03
            val rr = r * (1f + noise * sin(7.0 * th).toFloat())
            Pt(cx + rr * cos(th).toFloat(), cy + rr * sin(th).toFloat())
        }

    private fun stroke(id: String, vararg pts: Pair<Float, Float>, layer: String = "L1", width: Float = 4f) =
        StrokeElement(id, layer, null, pts.map { Pt(it.first, it.second) }, 0xFF000000.toInt(), width)

    // ---------- math ----------

    @Test fun affineRotateMapsAxis() {
        val m = Affine.rotate((PI / 2).toFloat(), 0f, 0f)
        val v = m.map(Vec(1f, 0f))
        assertEquals(0f, v.x, 1e-5f)
        assertEquals(1f, v.y, 1e-5f)
    }

    @Test fun affineScaleKeepsPivotAndInverts() {
        val m = Affine.scale(2f, 3f, 10f, 20f)
        val p = m.map(Vec(10f, 20f))
        assertEquals(10f, p.x, 1e-4f)
        assertEquals(20f, p.y, 1e-4f)
        val t = Affine.translate(5f, -7f) then Affine.rotate(0.7f, 3f, 4f) then m
        val inv = t.invert()!!
        val q = inv.map(t.map(Vec(12f, 34f)))
        assertEquals(12f, q.x, 1e-3f)
        assertEquals(34f, q.y, 1e-3f)
    }

    // ---------- history ----------

    @Test fun historyUndoRedo() {
        val h = History(listOf(1))
        h.push(listOf(1, 2))
        h.push(listOf(1, 2, 3))
        assertEquals(listOf(1, 2), h.undo())
        assertEquals(listOf(1), h.undo())
        assertNull(h.undo())
        assertEquals(listOf(1, 2), h.redo())
        h.push(listOf(9))
        assertFalse(h.canRedo)
    }

    @Test fun historyGestureIsSingleStep() {
        val h = History(listOf(0))
        val base = h.current
        h.update(listOf(0, 1))
        h.update(listOf(0, 1, 2))
        assertTrue(h.commit(base))
        assertEquals(listOf(0), h.undo())
        assertFalse(h.canUndo)
    }

    @Test fun historyNoOpCommitAddsNothing() {
        val h = History(listOf(0))
        assertFalse(h.commit(h.current))
        assertFalse(h.canUndo)
    }

    @Test fun historyRespectsLimit() {
        val h = History(0, limit = 3)
        for (i in 1..10) h.push(i)
        var steps = 0
        while (h.undo() != null) steps++
        assertEquals(3, steps)
    }

    // ---------- shape recognition ----------

    @Test fun recognizesCircle() {
        val r = ShapeRecognizer.recognize(circle(200f, 300f, 80f))
        assertNotNull(r)
        assertEquals(ShapeKind.ELLIPSE, r!!.kind)
        assertEquals(200f, r.pts[0].x, 6f)
        assertEquals(300f, r.pts[0].y, 6f)
        assertEquals(80f, r.pts[0].dist(r.pts[1]), 8f)
    }

    @Test fun recognizesRectangle() {
        val pts = poly(0f to 0f, 200f to 0f, 200f to 120f, 0f to 120f, wobble = 1.5f)
        val r = ShapeRecognizer.recognize(pts)
        assertNotNull(r)
        assertEquals(ShapeKind.RECT, r!!.kind)
        assertEquals(4, r.pts.size)
        // Axis-aligned after snapping.
        assertEquals(r.pts[0].y, r.pts[1].y, 0.5f)
        assertEquals(r.pts[1].x, r.pts[2].x, 0.5f)
    }

    @Test fun recognizesTriangle() {
        val pts = poly(0f to 0f, 220f to 20f, 90f to 180f, wobble = 1.2f)
        val r = ShapeRecognizer.recognize(pts)
        assertNotNull(r)
        assertEquals(ShapeKind.TRIANGLE, r!!.kind)
    }

    @Test fun recognizesLine() {
        val pts = (0..40).map { Pt(it * 5f, it * 2f + 1.5f * sin(it * 0.8f)) }
        val r = ShapeRecognizer.recognize(pts)
        assertNotNull(r)
        assertEquals(ShapeKind.LINE, r!!.kind)
    }

    @Test fun recognizesHexagonAsPolygon() {
        val v = (0 until 6).map { i ->
            val th = 2.0 * PI * i / 6
            (150f + 100f * cos(th).toFloat()) to (150f + 100f * sin(th).toFloat())
        }
        val r = ShapeRecognizer.recognize(poly(*v.toTypedArray(), wobble = 1f))
        assertNotNull(r)
        assertEquals(ShapeKind.POLYGON, r!!.kind)
        assertEquals(6, r.pts.size)
    }

    @Test fun rejectsZigZag() {
        val pts = (0..60).map { Pt(it * 6f, if ((it / 6) % 2 == 0) (it % 6) * 15f else 90f - (it % 6) * 15f) }
        assertNull(ShapeRecognizer.recognize(pts))
    }

    // ---------- eraser ----------

    @Test fun partialEraserSplitsStroke() {
        val s = stroke("s", 0f to 0f, 100f to 0f)
        val out = Eraser.erasePartial(listOf(s), 50f, 0f, 10f) { true }
        assertEquals(2, out.size)
        val b0 = out[0].bounds()
        val b1 = out[1].bounds()
        assertTrue(b0.right < 50f)
        assertTrue(b1.left > 50f)
    }

    @Test fun partialEraserNoTouchReturnsSameList() {
        val list: List<Element> = listOf(stroke("s", 0f to 0f, 100f to 0f))
        assertSame(list, Eraser.erasePartial(list, 50f, 80f, 10f) { true })
    }

    @Test fun partialEraserRemovesTinyStroke() {
        val s = stroke("s", 0f to 0f, 6f to 0f)
        assertTrue(Eraser.erasePartial(listOf(s), 3f, 0f, 10f) { true }.isEmpty())
    }

    @Test fun wholeEraserRemovesTouchedOnly() {
        val a = stroke("a", 0f to 0f, 100f to 0f)
        val b = stroke("b", 0f to 200f, 100f to 200f)
        val out = Eraser.eraseWholeElements(listOf(a, b), 50f, 2f, 6f) { true }
        assertEquals(listOf("b"), out.map { it.id })
    }

    @Test fun lockedLayerIsNotErased() {
        val a = stroke("a", 0f to 0f, 100f to 0f)
        val layers = listOf(Layer("L1", "L", visible = true, locked = true))
        val list: List<Element> = listOf(a)
        assertSame(list, Eraser.eraseWholeElements(list, 50f, 0f, 8f, EditOps.editablePredicate(layers)))
    }

    // ---------- edit operations ----------

    @Test fun transformScalesStrokeWidth() {
        val s = stroke("s", 0f to 0f, 10f to 10f, width = 4f)
        val out = EditOps.transform(listOf(s), setOf("s"), Affine.scale(2f, 2f, 0f, 0f))[0] as StrokeElement
        assertEquals(8f, out.width, 1e-4f)
        assertEquals(20f, out.points[1].x, 1e-4f)
    }

    @Test fun imageTransformMovesAndRotates() {
        val img = ImageElement("i", "L1", null, 10f, 10f, 100f, 50f, 0f, "a.png")
        val out = img.transformed(Affine.rotate((PI / 2).toFloat(), 10f, 10f)) as ImageElement
        assertEquals(10f, out.ox, 1e-3f)
        assertEquals(10f, out.oy, 1e-3f)
        assertEquals(100f, out.w, 1e-3f)
        assertEquals(50f, out.h, 1e-3f)
        assertEquals((PI / 2).toFloat(), out.rotation, 1e-3f)
        // A point inside the rotated box (below the origin) must hit.
        assertTrue(out.hitTest(-10f, 60f, 0f))
        assertFalse(out.hitTest(60f, 10f, 0f))
    }

    @Test fun groupSelectionExpandsAndDuplicates() {
        val a = stroke("a", 0f to 0f, 10f to 0f)
        val b = stroke("b", 0f to 20f, 10f to 20f)
        val c = stroke("c", 0f to 40f, 10f to 40f)
        val grouped = EditOps.group(listOf(a, b, c), setOf("a", "b"))
        assertEquals(setOf("a", "b"), EditOps.expandToGroups(grouped, setOf("a")))
        val (all, newIds) = EditOps.insertCopies(grouped, EditOps.snapshot(grouped, setOf("a", "b")), null, 5f, 5f)
        assertEquals(5, all.size)
        assertEquals(2, newIds.size)
        val copies = all.filter { it.id in newIds }
        assertNotNull(copies[0].groupId)
        assertEquals(copies[0].groupId, copies[1].groupId)
        assertNotEquals(copies[0].groupId, grouped[0].groupId)
    }

    @Test fun zOrderOps() {
        val a = stroke("a", 0f to 0f, 1f to 1f)
        val b = stroke("b", 0f to 0f, 1f to 1f)
        val c = stroke("c", 0f to 0f, 1f to 1f)
        assertEquals(listOf("b", "c", "a"), EditOps.bringToFront(listOf(a, b, c), setOf("a")).map { it.id })
        assertEquals(listOf("c", "a", "b"), EditOps.sendToBack(listOf(a, b, c), setOf("c")).map { it.id })
    }

    @Test fun topmostRespectsLayerOrder() {
        val low = stroke("low", 0f to 0f, 100f to 0f, layer = "A")
        val high = stroke("high", 0f to 0f, 100f to 0f, layer = "B")
        val layers = listOf(Layer("A", "A"), Layer("B", "B"))
        // 'high' is listed first in elements but lives on the upper layer.
        assertEquals("high", EditOps.topmostAt(listOf(high, low), layers, 50f, 0f, 4f)?.id)
    }

    @Test fun layerOps() {
        val c0 = PageContent(listOf(Layer("A", "A")), listOf(stroke("s", 0f to 0f, 1f to 1f, layer = "A")))
        val (c1, id) = LayerOps.add(c0, "B")
        assertEquals(2, c1.layers.size)
        assertEquals(c0, LayerOps.remove(c0, "A")) // last layer cannot be removed
        val c2 = LayerOps.remove(c1, "A")
        assertEquals(listOf(id), c2.layers.map { it.id })
        assertTrue(c2.elements.isEmpty())
        assertEquals(listOf("B", "A"), LayerOps.move(c1.copy(layers = listOf(Layer("A", "A"), Layer("B", "B"))), "B", -1).layers.map { it.id })
    }

    // ---------- stroke processing ----------

    @Test fun finishKeepsEndpointsAndReducesPoints() {
        val pts = (0..200).map { Pt(it.toFloat(), 0.2f * sin(it * 0.5f), 1f) }
        val out = StrokeProcessor.finish(pts, simplifyEpsilon = 0.6f)
        assertTrue(out.size < pts.size / 4)
        assertEquals(pts.first().x, out.first().x, 1e-4f)
        assertEquals(pts.last().x, out.last().x, 1e-4f)
    }

    @Test fun pseudoPressureStaysInRange() {
        var p = 1f
        repeat(50) { p = StrokeProcessor.pseudoPressure(p, 3f) }
        assertTrue(p in 0.45f..1.15f)
        assertNotSame(null, p)
        assertTrue(abs(p - 0.45f) < 0.05f)
    }
}
