package com.hashishir.note3.editor

import com.hashishir.note3.engine.GeoKind
import com.hashishir.note3.engine.GeoTool
import com.hashishir.note3.engine.History
import com.hashishir.note3.engine.PageContent
import com.hashishir.note3.engine.RecognizeMode
import com.hashishir.note3.engine.Tool
import com.hashishir.note3.engine.model.Page
import com.hashishir.note3.engine.model.ShapeElement
import com.hashishir.note3.engine.model.ShapeKind
import com.hashishir.note3.engine.model.StrokeElement
import com.hashishir.note3.engine.model.TextElement
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

class DrawingSessionTest {

    private class Recorder : SessionListener {
        val events = ArrayList<SessionEvent>()
        var contentChanges = 0
        override fun onContentChanged() { contentChanges++ }
        override fun onEvent(event: SessionEvent) { events.add(event) }
    }

    private fun session(recognize: RecognizeMode = RecognizeMode.OFF): Pair<DrawingSession, Recorder> {
        val page = Page.blank()
        val s = DrawingSession(History(PageContent(page.layers, emptyList())))
        val r = Recorder()
        s.listener = r
        s.setViewSize(1000f, 1000f)
        s.updateSettings(s.settings.copy(tool = Tool.PEN, recognize = recognize))
        return s to r
    }

    private var clock = 0L

    private fun drag(
        s: DrawingSession, x1: Float, y1: Float, x2: Float, y2: Float,
        kind: PointerKind = PointerKind.STYLUS, steps: Int = 10
    ) {
        clock += 100
        s.pointerDown(x1, y1, 0.7f, kind, clock)
        for (i in 1..steps) {
            clock += 8
            val t = i.toFloat() / steps
            s.pointerMove(x1 + (x2 - x1) * t, y1 + (y2 - y1) * t, 0.7f, clock)
        }
        clock += 8
        s.pointerUp(x2, y2, clock)
    }

    private fun tap(s: DrawingSession, x: Float, y: Float, kind: PointerKind = PointerKind.STYLUS) {
        clock += 60
        s.pointerDown(x, y, 0.7f, kind, clock)
        clock += 30
        s.pointerUp(x, y, clock)
    }

    private fun strokes(s: DrawingSession) = s.content.elements.filterIsInstance<StrokeElement>()

    private fun tool(s: DrawingSession, t: Tool) = s.updateSettings(s.settings.copy(tool = t))

    // ------------------------------------------------------------------ drawing

    @Test fun penStrokeIsAddedAndUndone() {
        val (s, _) = session()
        drag(s, 100f, 100f, 300f, 160f)
        assertEquals(1, strokes(s).size)
        assertTrue(s.canUndo)
        s.undo()
        assertEquals(0, s.content.elements.size)
        assertTrue(s.canRedo)
        s.redo()
        assertEquals(1, strokes(s).size)
    }

    @Test fun tapMakesADot() {
        val (s, _) = session()
        tap(s, 200f, 200f)
        val st = strokes(s).single()
        assertEquals(2, st.points.size)
    }

    @Test fun highlighterUsesTransparentColour() {
        val (s, _) = session()
        tool(s, Tool.HIGHLIGHTER)
        drag(s, 100f, 100f, 300f, 100f)
        val c = strokes(s).single().color
        assertEquals(0x66, (c ushr 24) and 0xFF)
    }

    @Test fun fingerIsRejectedWhenStylusOnly() {
        val (s, _) = session()
        s.updateSettings(s.settings.copy(fingerDraws = false))
        assertFalse(s.wantsPointer(PointerKind.FINGER))
        assertTrue(s.wantsPointer(PointerKind.STYLUS))
        assertTrue(s.wantsPointer(PointerKind.ERASER))
        tool(s, Tool.HAND)
        assertFalse(s.wantsPointer(PointerKind.STYLUS))
    }

    @Test fun secondFingerCancelsStroke() {
        val (s, _) = session()
        s.pointerDown(100f, 100f, 0.5f, PointerKind.FINGER, 10)
        s.pointerMove(150f, 150f, 0.5f, 20)
        s.cancelGesture()
        assertEquals(0, s.content.elements.size)
        assertTrue(s.previewPoints.isEmpty())
    }

    // ------------------------------------------------------------------ shape recognition

    private fun drawCircle(s: DrawingSession, holdMs: Long) {
        val n = 60
        clock += 100
        fun px(i: Int) = 400f + 100f * cos(2.0 * PI * i / n * 1.03).toFloat()
        fun py(i: Int) = 400f + 100f * sin(2.0 * PI * i / n * 1.03).toFloat()
        s.pointerDown(px(0), py(0), 0.7f, PointerKind.STYLUS, clock)
        for (i in 1..n) {
            clock += 8
            s.pointerMove(px(i), py(i), 0.7f, clock)
        }
        clock += holdMs
        s.pointerUp(px(n), py(n), clock)
    }

    @Test fun alwaysModeConvertsCircleToEllipse() {
        val (s, _) = session(RecognizeMode.ALWAYS)
        drawCircle(s, holdMs = 5)
        val shape = s.content.elements.single() as ShapeElement
        assertEquals(ShapeKind.ELLIPSE, shape.kind)
    }

    @Test fun holdModeNeedsAPauseBeforeLifting() {
        val (s, _) = session(RecognizeMode.HOLD)
        drawCircle(s, holdMs = 50)
        assertTrue(s.content.elements.single() is StrokeElement)
        drawCircle(s, holdMs = 800)
        assertEquals(2, s.content.elements.size)
        assertTrue(s.content.elements[1] is ShapeElement)
    }

    @Test fun offModeKeepsFreehand() {
        val (s, _) = session(RecognizeMode.OFF)
        drawCircle(s, holdMs = 900)
        assertTrue(s.content.elements.single() is StrokeElement)
    }

    // ------------------------------------------------------------------ erasers

    @Test fun strokeEraserRemovesWholeStroke() {
        val (s, _) = session()
        drag(s, 100f, 100f, 300f, 100f)
        tool(s, Tool.ERASER_STROKE)
        tap(s, 200f, 102f)
        assertEquals(0, s.content.elements.size)
        s.undo()
        assertEquals(1, s.content.elements.size)
    }

    @Test fun partialEraserSplitsStrokeAndIsOneUndoStep() {
        val (s, _) = session()
        drag(s, 100f, 100f, 300f, 100f)
        tool(s, Tool.ERASER_PARTIAL)
        drag(s, 190f, 100f, 210f, 100f, steps = 6)
        assertEquals(2, strokes(s).size)
        s.undo()
        assertEquals(1, strokes(s).size)
    }

    @Test fun stylusEraserEndErasesEvenWithPenSelected() {
        val (s, _) = session()
        drag(s, 100f, 100f, 300f, 100f)
        clock += 50
        s.pointerDown(200f, 100f, 0.5f, PointerKind.ERASER, clock)
        clock += 20
        s.pointerUp(200f, 100f, clock)
        assertEquals(2, strokes(s).size)
    }

    // ------------------------------------------------------------------ selection

    @Test fun tapSelectsAndDragMovesAsSingleUndoStep() {
        val (s, _) = session()
        drag(s, 100f, 100f, 200f, 100f)
        tool(s, Tool.SELECT)
        drag(s, 150f, 100f, 150f, 200f)
        val moved = strokes(s).single()
        assertEquals(200f, moved.points.first().y, 1f)
        s.undo()
        assertEquals(100f, strokes(s).single().points.first().y, 1f)
        assertEquals(1, strokes(s).size)
    }

    @Test fun tapWithoutMovementDoesNotCreateUndoStep() {
        val (s, _) = session()
        drag(s, 100f, 100f, 200f, 100f)
        tool(s, Tool.SELECT)
        tap(s, 150f, 100f)
        assertEquals(1, s.selection.size)
        s.undo() // undoes the stroke itself, proving the tap added nothing
        assertEquals(0, s.content.elements.size)
    }

    @Test fun resizeCornerScalesSelection() {
        val (s, _) = session()
        drag(s, 100f, 100f, 200f, 200f)
        tool(s, Tool.SELECT)
        tap(s, 150f, 150f)
        val box = s.selectionBox!!
        val w0 = box.width
        // drag bottom-right corner outwards, doubling its distance from the top-left anchor
        drag(s, box.right, box.bottom, box.left + 2 * box.width, box.top + 2 * box.height)
        val nb = s.selectionBox!!
        assertEquals(2f * w0, nb.width, w0 * 0.05f)
    }

    @Test fun rotateHandleTurnsHorizontalLineVertical() {
        val (s, _) = session()
        drag(s, 100f, 300f, 300f, 300f)
        tool(s, Tool.SELECT)
        tap(s, 200f, 300f)
        val box = s.selectionBox!!
        val hx = box.centerX
        val hy = box.top - DrawingSession.ROTATE_HANDLE_PX
        drag(s, hx, hy, box.centerX + 120f, box.centerY)
        val nb = s.selectionBox!!
        assertTrue(nb.height > nb.width)
    }

    @Test fun lassoSelectsEnclosedElements() {
        val (s, _) = session()
        drag(s, 100f, 100f, 200f, 100f)
        drag(s, 700f, 700f, 800f, 700f)
        tool(s, Tool.SELECT)
        clock += 100
        s.pointerDown(20f, 20f, 0.5f, PointerKind.STYLUS, clock)
        for ((x, y) in listOf(300f to 20f, 300f to 300f, 20f to 300f, 20f to 40f)) {
            clock += 8
            s.pointerMove(x, y, 0.5f, clock)
        }
        s.pointerUp(20f, 40f, clock + 8)
        assertEquals(1, s.selection.size)
    }

    @Test fun selectingGroupMemberSelectsWholeGroup() {
        val (s, _) = session()
        drag(s, 100f, 100f, 200f, 100f)
        drag(s, 400f, 400f, 500f, 400f)
        tool(s, Tool.SELECT)
        s.selectAll()
        s.group()
        s.clearSelection()
        tap(s, 150f, 100f)
        assertEquals(2, s.selection.size)
        s.ungroup()
        s.clearSelection()
        tap(s, 150f, 100f)
        assertEquals(1, s.selection.size)
    }

    @Test fun copyPasteAndDuplicate() {
        val (s, _) = session()
        drag(s, 100f, 100f, 200f, 100f)
        tool(s, Tool.SELECT)
        tap(s, 150f, 100f)
        s.copy()
        s.paste()
        assertEquals(2, s.content.elements.size)
        assertEquals(1, s.selection.size)
        val pasted = s.content.elements[1]
        assertTrue(pasted.id in s.selection)
        s.duplicate()
        assertEquals(3, s.content.elements.size)
        s.deleteSelection()
        assertEquals(2, s.content.elements.size)
    }

    @Test fun undoDropsStaleSelection() {
        val (s, _) = session()
        drag(s, 100f, 100f, 200f, 100f)
        tool(s, Tool.SELECT)
        tap(s, 150f, 100f)
        s.copy()
        s.paste()
        s.undo()
        assertTrue(s.selection.isEmpty())
        assertNull(s.selectionBox)
    }

    @Test fun cancelDuringMoveRestoresContent() {
        val (s, _) = session()
        drag(s, 100f, 100f, 200f, 100f)
        tool(s, Tool.SELECT)
        clock += 50
        s.pointerDown(150f, 100f, 0.5f, PointerKind.STYLUS, clock)
        s.pointerMove(150f, 160f, 0.5f, clock + 10)
        s.pointerMove(150f, 260f, 0.5f, clock + 20)
        s.cancelGesture()
        assertEquals(100f, strokes(s).single().points.first().y, 0.5f)
    }

    // ------------------------------------------------------------------ shapes

    @Test fun rectangleToolCreatesFourCorners() {
        val (s, _) = session()
        s.updateSettings(s.settings.copy(tool = Tool.SHAPE, shapeKind = ShapeKind.RECT))
        drag(s, 100f, 100f, 300f, 250f)
        val r = s.content.elements.single() as ShapeElement
        assertEquals(ShapeKind.RECT, r.kind)
        assertEquals(4, r.pts.size)
    }

    @Test fun tinyShapeDragIsDiscarded() {
        val (s, _) = session()
        s.updateSettings(s.settings.copy(tool = Tool.SHAPE, shapeKind = ShapeKind.ARROW))
        drag(s, 100f, 100f, 102f, 101f, steps = 2)
        assertEquals(0, s.content.elements.size)
    }

    @Test fun gridSnapAlignsShapeToGrid() {
        val (s, _) = session()
        s.updateSettings(s.settings.copy(tool = Tool.SHAPE, shapeKind = ShapeKind.LINE, snapToGrid = true, gridSize = 40f))
        drag(s, 97f, 103f, 305f, 211f)
        val l = s.content.elements.single() as ShapeElement
        assertEquals(80f, l.pts[0].x, 0.01f)
        assertEquals(120f, l.pts[0].y, 0.01f)
    }

    @Test fun polygonFromTapsClosesOnFirstVertex() {
        val (s, _) = session()
        s.updateSettings(s.settings.copy(tool = Tool.SHAPE, shapeKind = ShapeKind.POLYGON))
        tap(s, 100f, 100f)
        tap(s, 300f, 100f)
        tap(s, 300f, 300f)
        tap(s, 200f, 380f)
        assertEquals(4, s.polygonDraft.size)
        assertTrue(s.canFinishPolygon)
        tap(s, 102f, 101f) // close
        val p = s.content.elements.single() as ShapeElement
        assertEquals(ShapeKind.POLYGON, p.kind)
        assertEquals(4, p.pts.size)
        assertTrue(s.polygonDraft.isEmpty())
    }

    // ------------------------------------------------------------------ text

    @Test fun textToolRequestsEditorAndTextCanBeEdited() {
        val (s, r) = session()
        tool(s, Tool.TEXT)
        tap(s, 50f, 60f)
        val ev = r.events.last() as SessionEvent.EditText
        assertNull(ev.elementId)
        assertEquals(50f, ev.x, 0.01f)
        val id = s.addText("hello", 50f, 60f, 200f, 40f, 32f, 0xFF000000.toInt())
        assertNotNull(id)
        s.updateText(id!!, "hello world", 220f, 40f, 32f, 0xFF000000.toInt())
        assertEquals("hello world", (s.elementById(id) as TextElement).text)
        s.updateText(id, "  ", 10f, 10f, 32f, 0)
        assertNull(s.elementById(id))
    }

    @Test fun doubleTapOnTextInSelectModeOpensEditor() {
        val (s, r) = session()
        val id = s.addText("abc", 100f, 100f, 200f, 40f, 32f, 0xFF000000.toInt())!!
        tool(s, Tool.SELECT)
        tap(s, 150f, 120f)
        tap(s, 150f, 120f)
        val ev = r.events.filterIsInstance<SessionEvent.EditText>().last()
        assertEquals(id, ev.elementId)
    }

    // ------------------------------------------------------------------ layers

    @Test fun lockedLayerBlocksDrawingWithMessage() {
        val (s, r) = session()
        s.addLayer("Top")
        val id = s.activeLayerId
        s.setLayerLocked(id, true)
        drag(s, 100f, 100f, 200f, 100f)
        assertEquals(0, s.content.elements.size)
        assertTrue(r.events.any { it is SessionEvent.Message })
    }

    @Test fun lastLayerCannotBeRemoved() {
        val (s, r) = session()
        s.removeLayer(s.activeLayerId)
        assertEquals(1, s.content.layers.size)
        assertTrue(r.events.any { it is SessionEvent.Message })
    }

    @Test fun movingSelectionToAnotherLayer() {
        val (s, _) = session()
        drag(s, 100f, 100f, 200f, 100f)
        s.addLayer("Two")
        val two = s.activeLayerId
        tool(s, Tool.SELECT)
        // layer 1 element is still editable
        tap(s, 150f, 100f)
        s.moveSelectionToLayer(two)
        assertEquals(two, s.content.elements.single().layerId)
    }

    // ------------------------------------------------------------------ geometry tools

    @Test fun strokeAlongRulerEdgeSnapsStraight() {
        val (s, _) = session()
        s.geometry.add(GeoTool(GeoKind.RULER, 500f, 500f, 0f, 600f))
        // top edge of the ruler is y = 500 - 36 = 464
        drag(s, 300f, 470f, 700f, 484f)
        val st = strokes(s).single()
        assertEquals(2, st.points.size)
        assertEquals(464f, st.points[0].y, 0.01f)
        assertEquals(464f, st.points[1].y, 0.01f)
        assertEquals(300f, st.points[0].x, 0.5f)
        assertEquals(700f, st.points[1].x, 0.5f)
    }

    @Test fun rulerHandleRotatesAndResizes() {
        val (s, _) = session()
        s.geometry.add(GeoTool(GeoKind.RULER, 500f, 500f, 0f, 600f))
        drag(s, 800f, 500f, 500f, 800f)
        val g = s.geometry.single()
        assertEquals((PI / 2).toFloat(), g.angle, 0.02f)
        assertEquals(600f, g.size, 2f)
        assertEquals(0, s.content.elements.size) // dragging a tool must not draw
    }

    @Test fun rulerGripMovesTool() {
        val (s, _) = session()
        s.geometry.add(GeoTool(GeoKind.RULER, 500f, 500f, 0f, 600f))
        drag(s, 500f, 500f, 560f, 530f)
        val g = s.geometry.single()
        assertEquals(560f, g.cx, 1f)
        assertEquals(530f, g.cy, 1f)
    }

    @Test fun addAndRemoveGeometryAids() {
        val (s, _) = session()
        s.addGeometry(GeoKind.PROTRACTOR)
        s.addGeometry(GeoKind.RULER)
        assertEquals(2, s.geometry.size)
        s.addGeometry(GeoKind.RULER)
        assertEquals(2, s.geometry.size)
        s.removeGeometry(GeoKind.RULER)
        assertEquals(GeoKind.PROTRACTOR, s.geometry.single().kind)
        s.clearGeometry()
        assertTrue(s.geometry.isEmpty())
    }

    @Test fun touchThresholdsScaleWithScreenDensity() {
        val (low, _) = session()
        drag(low, 100f, 100f, 300f, 100f)
        tool(low, Tool.SELECT)
        tap(low, 200f, 130f) // 30 px away: outside a 12 dp tolerance at density 1
        assertTrue(low.selection.isEmpty())

        val (high, _) = session()
        high.density = 3f
        drag(high, 100f, 100f, 300f, 100f)
        tool(high, Tool.SELECT)
        tap(high, 200f, 130f) // 12 dp * 3 = 36 px tolerance
        assertEquals(1, high.selection.size)
    }

    // ------------------------------------------------------------------ viewport interplay

    @Test fun drawingUsesWorldCoordinatesUnderZoomAndPan() {
        val (s, _) = session()
        s.viewport.scale = 2f
        s.viewport.tx = 100f
        s.viewport.ty = 50f
        drag(s, 300f, 250f, 500f, 250f)
        val st = strokes(s).single()
        assertEquals(100f, st.points.first().x, 0.5f)
        assertEquals(100f, st.points.first().y, 0.5f)
        assertEquals(200f, st.points.last().x, 0.5f)
        assertTrue(abs(st.points.last().y - 100f) < 0.5f)
    }
}
