package com.hashishir.note3.data

import com.hashishir.note3.engine.model.ImageElement
import com.hashishir.note3.engine.model.Layer
import com.hashishir.note3.engine.model.MediaElement
import com.hashishir.note3.engine.model.MediaKind
import com.hashishir.note3.engine.model.Page
import com.hashishir.note3.engine.model.PdfRef
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.nio.file.Files
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/** Tests the zip layout and its safety checks. JSON itself is covered by the instrumented-free codec test in CI. */
class ArchiveIOTest {

    private class FakeCodec : ArchiveCodec {
        val pages = HashMap<String, Page>()
        val manifests = HashMap<String, ArchiveManifest>()
        override fun encodePage(page: Page): String = "P:" + page.id.also { pages[page.id] = page }
        override fun decodePage(text: String): Page = pages.getValue(text.removePrefix("P:"))
        override fun encodeManifest(m: ArchiveManifest): String = "M:" + manifests.size.also { manifests["M:$it"] = m }
        override fun decodeManifest(text: String): ArchiveManifest = manifests.getValue(text)
    }

    private fun tmp(): File = Files.createTempDirectory("n3test").toFile().also { it.deleteOnExit() }

    private fun pageWithMedia(id: String, vararg files: String): Page {
        val layer = Layer("L-$id", "Layer")
        val els = files.mapIndexed { i, f ->
            if (f.endsWith(".png")) ImageElement("e$id$i", layer.id, null, 0f, 0f, 10f, 10f, 0f, f)
            else MediaElement("e$id$i", layer.id, null, 0f, 0f, 10f, 10f, 0f, MediaKind.AUDIO, f, f)
        }
        return Page(id = id, layers = listOf(layer), elements = els)
    }

    @Test fun roundTripKeepsPagesMediaAndOrder() {
        val src = tmp()
        val dst = tmp()
        File(src, "a.png").writeBytes(byteArrayOf(1, 2, 3, 4))
        File(src, "song.mp3").writeBytes(ByteArray(200_000) { (it % 251).toByte() })
        val p1 = pageWithMedia("page-1", "a.png")
        val p2 = pageWithMedia("page-2", "song.mp3", "a.png")
        val pdfPage = Page(id = "page-3", pdf = PdfRef("doc.pdf", 0, 595f, 842f))
        File(src, "doc.pdf").writeBytes("%PDF-fake".toByteArray())
        val all = listOf(p1, p2, pdfPage).associateBy { it.id }
        val boards = listOf(
            BoardMeta("b1", "Lesson 1", 10L, 20L, listOf("page-1", "page-2")),
            BoardMeta("b2", "Maths", 11L, 21L, listOf("page-3"))
        )
        val codec = FakeCodec()
        val out = ByteArrayOutputStream()
        val missing = ArchiveIO.write(boards, { all[it] }, src, codec, out)
        assertEquals(0, missing)

        val result = ArchiveIO.read(ByteArrayInputStream(out.toByteArray()), dst, codec)
        assertEquals(boards, result.boards)
        assertEquals(setOf("page-1", "page-2", "page-3"), result.pages.keys)
        assertEquals(0, result.skippedPages)
        assertArrayEquals(File(src, "song.mp3").readBytes(), File(dst, "song.mp3").readBytes())
        assertArrayEquals(byteArrayOf(1, 2, 3, 4), File(dst, "a.png").readBytes())
        assertTrue(File(dst, "doc.pdf").isFile)
        assertTrue(dst.listFiles()!!.none { it.name.endsWith(".part") })
    }

    @Test fun missingMediaIsCountedNotFatal() {
        val src = tmp()
        val p = pageWithMedia("p", "gone.png")
        val out = ByteArrayOutputStream()
        val missing = ArchiveIO.write(listOf(BoardMeta("b", "t", 1, 2, listOf("p"))), { p }, src, FakeCodec(), out)
        assertEquals(1, missing)
    }

    @Test fun sharedMediaIsStoredOnce() {
        val src = tmp()
        File(src, "a.png").writeBytes(ByteArray(5000))
        val p1 = pageWithMedia("p1", "a.png")
        val p2 = pageWithMedia("p2", "a.png")
        val all = mapOf("p1" to p1, "p2" to p2)
        val out = ByteArrayOutputStream()
        ArchiveIO.write(listOf(BoardMeta("b", "t", 1, 2, listOf("p1", "p2"))), { all[it] }, src, FakeCodec(), out)
        val names = zipNames(out.toByteArray())
        assertEquals(1, names.count { it == "media/a.png" })
        assertEquals("manifest.json", names.first())
    }

    @Test fun maliciousEntryNamesNeverEscapeMediaDir() {
        val root = tmp()
        val media = File(root, "media").also { it.mkdirs() }
        val codec = FakeCodec()
        val manifest = codec.encodeManifest(ArchiveManifest(boards = emptyList()))
        val bytes = ByteArrayOutputStream().also { bos ->
            ZipOutputStream(bos).use { z ->
                z.putNextEntry(ZipEntry("manifest.json")); z.write(manifest.toByteArray()); z.closeEntry()
                for (evil in listOf("media/../evil.txt", "../evil.txt", "media/..", "media/a/b.txt", "/etc/passwd", "media/sub/../../x")) {
                    z.putNextEntry(ZipEntry(evil)); z.write("x".toByteArray()); z.closeEntry()
                }
                z.putNextEntry(ZipEntry("media/ok.png")); z.write("fine".toByteArray()); z.closeEntry()
            }
        }.toByteArray()
        ArchiveIO.read(ByteArrayInputStream(bytes), media, codec)
        assertEquals(listOf("ok.png"), media.list()!!.sorted())
        assertFalse(File(root, "evil.txt").exists())
        assertEquals(setOf("media"), root.list()!!.toSet())
    }

    @Test fun missingManifestIsRejected() {
        val bytes = ByteArrayOutputStream().also { bos ->
            ZipOutputStream(bos).use { z -> z.putNextEntry(ZipEntry("media/a.png")); z.write(1); z.closeEntry() }
        }.toByteArray()
        try {
            ArchiveIO.read(ByteArrayInputStream(bytes), tmp(), FakeCodec())
            fail("expected ArchiveException")
        } catch (e: ArchiveException) {
            assertTrue(e.message!!.contains("manifest"))
        }
    }

    @Test fun foreignOrNewerFormatsAreRejected() {
        for (m in listOf(
            ArchiveManifest(format = "something-else", boards = emptyList()),
            ArchiveManifest(version = ArchiveIO.VERSION + 1, boards = emptyList())
        )) {
            val codec = FakeCodec()
            val text = codec.encodeManifest(m)
            val bytes = ByteArrayOutputStream().also { bos ->
                ZipOutputStream(bos).use { z -> z.putNextEntry(ZipEntry("manifest.json")); z.write(text.toByteArray()); z.closeEntry() }
            }.toByteArray()
            try {
                ArchiveIO.read(ByteArrayInputStream(bytes), tmp(), codec)
                fail("expected ArchiveException")
            } catch (_: ArchiveException) {
            }
        }
    }

    @Test fun notAZipIsRejectedCleanly() {
        try {
            ArchiveIO.read(ByteArrayInputStream("hello, not a zip".toByteArray()), tmp(), FakeCodec())
            fail("expected ArchiveException")
        } catch (_: ArchiveException) {
        }
    }

    @Test fun undecodablePageIsSkippedAndCounted() {
        val codec = FakeCodec()
        val text = codec.encodeManifest(ArchiveManifest(boards = listOf(BoardMeta("b", "t", 1, 2, listOf("bad")))))
        val bytes = ByteArrayOutputStream().also { bos ->
            ZipOutputStream(bos).use { z ->
                z.putNextEntry(ZipEntry("manifest.json")); z.write(text.toByteArray()); z.closeEntry()
                z.putNextEntry(ZipEntry("pages/bad.json")); z.write("garbage".toByteArray()); z.closeEntry()
            }
        }.toByteArray()
        val r = ArchiveIO.read(ByteArrayInputStream(bytes), tmp(), codec)
        assertEquals(1, r.skippedPages)
        assertTrue(r.pages.isEmpty())
    }

    @Test fun mediaNameValidation() {
        assertTrue(ArchiveIO.isSafeMediaName("3f2a-9.png"))
        assertFalse(ArchiveIO.isSafeMediaName(".."))
        assertFalse(ArchiveIO.isSafeMediaName("../x"))
        assertFalse(ArchiveIO.isSafeMediaName("a/b"))
        assertFalse(ArchiveIO.isSafeMediaName(""))
        assertFalse(ArchiveIO.isSafeMediaName("a b.png"))
    }

    private fun zipNames(bytes: ByteArray): List<String> {
        val out = ArrayList<String>()
        java.util.zip.ZipInputStream(ByteArrayInputStream(bytes)).use { z ->
            while (true) out.add((z.nextEntry ?: break).name)
        }
        return out
    }
}
