package com.hashishir.note3.recording

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.MediaRecorder
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.IBinder
import android.provider.MediaStore
import android.util.DisplayMetrics
import android.view.WindowManager
import androidx.core.app.NotificationCompat
import com.hashishir.note3.MainActivity
import com.hashishir.note3.R
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.io.File

sealed interface RecordingState {
    data object Idle : RecordingState
    data class Recording(val withAudio: Boolean, val startedAt: Long) : RecordingState
    data class Finished(val uri: Uri) : RecordingState
    data class Failed(val message: String) : RecordingState
}

/** Process-wide recording state so the UI can observe the service. */
object RecordingBus {
    private val _state = MutableStateFlow<RecordingState>(RecordingState.Idle)
    val state: StateFlow<RecordingState> = _state
    fun set(s: RecordingState) { _state.value = s }
}

/**
 * Records the screen with MediaProjection + MediaRecorder (H.264/AAC MP4) as a foreground service,
 * as Android requires. The finished file is saved to Movies/Note3 through MediaStore.
 * Limitation: only this device's screen is captured; audio is the microphone (Android does not
 * allow third-party apps to capture internal audio on all versions).
 */
class RecorderService : Service() {

    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var recorder: MediaRecorder? = null
    private var tempFile: File? = null
    private var startedAt = 0L

    private val projectionCallback = object : MediaProjection.Callback() {
        override fun onStop() {
            // The user revoked the projection from the system UI.
            finishRecording()
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> start(intent)
            ACTION_STOP -> finishRecording()
            else -> stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun start(intent: Intent) {
        if (recorder != null) return
        val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, 0)
        val data: Intent? = if (Build.VERSION.SDK_INT >= 33) {
            intent.getParcelableExtra(EXTRA_DATA, Intent::class.java)
        } else {
            @Suppress("DEPRECATION") intent.getParcelableExtra(EXTRA_DATA)
        }
        val withAudio = intent.getBooleanExtra(EXTRA_AUDIO, false)
        if (data == null) {
            fail("Screen capture permission was not granted.")
            return
        }
        // Must be in the foreground before the projection token is used.
        try {
            startForegroundCompat()
        } catch (e: Exception) {
            fail("Could not start the recording service: ${e.message}")
            return
        }
        try {
            val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            val proj = mpm.getMediaProjection(resultCode, data) ?: throw IllegalStateException("No projection")
            projection = proj
            proj.registerCallback(projectionCallback, null)

            val metrics = DisplayMetrics()
            @Suppress("DEPRECATION")
            (getSystemService(Context.WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(metrics)
            // Keep within H.264 hardware limits on low-end phones and use even dimensions.
            var w = metrics.widthPixels
            var h = metrics.heightPixels
            val longest = maxOf(w, h)
            if (longest > MAX_EDGE) {
                val k = MAX_EDGE.toFloat() / longest
                w = (w * k).toInt(); h = (h * k).toInt()
            }
            w = w and 1.inv(); h = h and 1.inv()

            val file = File(cacheDir, "rec_${System.currentTimeMillis()}.mp4")
            tempFile = file
            @Suppress("DEPRECATION")
            val rec = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(this) else MediaRecorder()
            if (withAudio) rec.setAudioSource(MediaRecorder.AudioSource.MIC)
            rec.setVideoSource(MediaRecorder.VideoSource.SURFACE)
            rec.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            rec.setVideoEncoder(MediaRecorder.VideoEncoder.H264)
            if (withAudio) {
                rec.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                rec.setAudioEncodingBitRate(96_000)
                rec.setAudioSamplingRate(44_100)
            }
            rec.setVideoSize(w, h)
            rec.setVideoFrameRate(30)
            rec.setVideoEncodingBitRate((w * h * 4).coerceIn(1_500_000, 8_000_000))
            rec.setOutputFile(file.absolutePath)
            rec.prepare()
            recorder = rec
            display = proj.createVirtualDisplay(
                "note3-rec", w, h, metrics.densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, rec.surface, null, null
            )
            rec.start()
            startedAt = System.currentTimeMillis()
            RecordingBus.set(RecordingState.Recording(withAudio, startedAt))
        } catch (e: Exception) {
            cleanup()
            fail("Could not start recording: ${e.message ?: e.javaClass.simpleName}")
        }
    }

    private fun finishRecording() {
        val rec = recorder
        val file = tempFile
        if (rec == null) {
            cleanup(); stopForegroundCompat(); stopSelf(); return
        }
        var ok = true
        try {
            rec.stop()
        } catch (_: RuntimeException) {
            ok = false // stop() throws if nothing was captured yet
        }
        cleanup()
        if (ok && file != null && file.length() > 0) {
            val uri = saveToMovies(file)
            if (uri != null) RecordingBus.set(RecordingState.Finished(uri))
            else RecordingBus.set(RecordingState.Failed("Could not save the video to your gallery."))
        } else {
            RecordingBus.set(RecordingState.Failed("The recording was too short to save."))
        }
        file?.delete()
        stopForegroundCompat()
        stopSelf()
    }

    private fun saveToMovies(src: File): Uri? {
        val name = "Note3_${System.currentTimeMillis()}.mp4"
        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, name)
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            if (Build.VERSION.SDK_INT >= 29) {
                put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/Note3")
                put(MediaStore.Video.Media.IS_PENDING, 1)
            }
        }
        if (Build.VERSION.SDK_INT < 29) {
            // Before Android 10 there is no scoped storage; use the app's own external movies folder.
            val dir = getExternalFilesDir(Environment.DIRECTORY_MOVIES) ?: return null
            dir.mkdirs()
            val dst = File(dir, name)
            return try {
                src.copyTo(dst, overwrite = true)
                androidx.core.content.FileProvider.getUriForFile(this, "$packageName.fileprovider", dst)
            } catch (_: Exception) {
                null
            }
        }
        val resolver = contentResolver
        val uri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values) ?: return null
        return try {
            resolver.openOutputStream(uri)?.use { os -> src.inputStream().use { it.copyTo(os, 64 * 1024) } }
                ?: throw IllegalStateException("no stream")
            values.clear()
            values.put(MediaStore.Video.Media.IS_PENDING, 0)
            resolver.update(uri, values, null, null)
            uri
        } catch (_: Exception) {
            resolver.delete(uri, null, null)
            null
        }
    }

    private fun cleanup() {
        runCatching { display?.release() }
        display = null
        runCatching { recorder?.reset(); recorder?.release() }
        recorder = null
        projection?.let {
            runCatching { it.unregisterCallback(projectionCallback) }
            runCatching { it.stop() }
        }
        projection = null
    }

    private fun fail(msg: String) {
        RecordingBus.set(RecordingState.Failed(msg))
        stopForegroundCompat()
        stopSelf()
    }

    override fun onDestroy() {
        if (recorder != null) finishRecording() else cleanup()
        super.onDestroy()
    }

    // ------------------------------------------------------------------ notification

    private fun startForegroundCompat() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL, getString(R.string.rec_channel_name), NotificationManager.IMPORTANCE_LOW)
            )
        }
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, RecorderService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n: Notification = NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle(getString(R.string.rec_notification_title))
            .setContentText(getString(R.string.rec_notification_text))
            .setContentIntent(open)
            .addAction(0, getString(R.string.rec_stop), stop)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIFICATION_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(NOTIFICATION_ID, n)
        }
    }

    private fun stopForegroundCompat() {
        if (Build.VERSION.SDK_INT >= 24) stopForeground(STOP_FOREGROUND_REMOVE)
        else @Suppress("DEPRECATION") stopForeground(true)
    }

    companion object {
        const val ACTION_START = "com.hashishir.note3.REC_START"
        const val ACTION_STOP = "com.hashishir.note3.REC_STOP"
        const val EXTRA_RESULT_CODE = "resultCode"
        const val EXTRA_DATA = "data"
        const val EXTRA_AUDIO = "audio"
        private const val CHANNEL = "recording"
        private const val NOTIFICATION_ID = 42
        private const val MAX_EDGE = 1920

        fun startIntent(ctx: Context, resultCode: Int, data: Intent, audio: Boolean): Intent =
            Intent(ctx, RecorderService::class.java)
                .setAction(ACTION_START)
                .putExtra(EXTRA_RESULT_CODE, resultCode)
                .putExtra(EXTRA_DATA, data)
                .putExtra(EXTRA_AUDIO, audio)

        fun stopIntent(ctx: Context): Intent = Intent(ctx, RecorderService::class.java).setAction(ACTION_STOP)
    }
}
