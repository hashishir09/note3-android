package com.hashishir.note3.engine

import com.hashishir.note3.engine.math.Rect
import com.hashishir.note3.engine.model.Element
import com.hashishir.note3.engine.model.IdGen
import com.hashishir.note3.engine.model.Pt
import com.hashishir.note3.engine.model.ShapeElement
import com.hashishir.note3.engine.model.StrokeElement
import com.hashishir.note3.engine.model.StrokeTool
import kotlin.math.floor
import kotlin.math.hypot
import kotlin.math.max

/**
 * Two eraser modes.
 *  - Stroke eraser: removes every touched element completely.
 *  - Intelligent eraser: cuts freehand strokes and shape outlines at the eraser circle, leaving the
 *    untouched parts as separate strokes. Text, images and media are not cut (use the stroke eraser).
 *
 * Every function returns the *same list instance* when nothing changed, so callers can cheaply
 * detect no-ops and avoid creating undo entries.
 */
object Eraser {

    fun eraseWholeElements(
        elements: List<Element>,
        cx: Float,
        cy: Float,
        radius: Float,
        editable: (Element) -> Boolean
    ): List<Element> {
        var out: MutableList<Element>? = null
        for ((i, e) in elements.withIndex()) {
            if (editable(e) && e.hitTest(cx, cy, radius)) {
                if (out == null) out = elements.subList(0, i).toMutableList()
            } else {
                out?.add(e)
            }
        }
        return out ?: elements
    }

    fun erasePartial(
        elements: List<Element>,
        cx: Float,
        cy: Float,
        radius: Float,
        editable: (Element) -> Boolean
    ): List<Element> {
        var out: MutableList<Element>? = null
        for ((i, e) in elements.withIndex()) {
            var replacement: List<Element>? = null
            if (editable(e)) {
                val stroke: StrokeElement? = when (e) {
                    is StrokeElement -> e
                    is ShapeElement -> shapeAsStroke(e)
                    else -> null
                }
                if (stroke != null) replacement = splitStroke(stroke, cx, cy, radius)
            }
            if (replacement != null) {
                if (out == null) out = elements.subList(0, i).toMutableList()
                out.addAll(replacement)
            } else {
                out?.add(e)
            }
        }
        return out ?: elements
    }

    private fun shapeAsStroke(s: ShapeElement): StrokeElement = StrokeElement(
        id = s.id,
        layerId = s.layerId,
        groupId = s.groupId,
        points = s.outline().map { Pt(it.x, it.y, 1f) },
        color = s.color,
        width = s.width,
        tool = StrokeTool.PEN
    )

    /** Returns null if the eraser circle does not touch the stroke; otherwise the surviving pieces. */
    fun splitStroke(s: StrokeElement, cx: Float, cy: Float, r: Float): List<StrokeElement>? {
        if (s.points.isEmpty()) return null
        if (!s.bounds().inflate(r).contains(cx, cy)) return null
        val dense = densify(s.points, max(r / 2f, 0.5f))
        var touched = false
        val inside = BooleanArray(dense.size) {
            val hit = hypot(dense[it].x - cx, dense[it].y - cy) <= r
            if (hit) touched = true
            hit
        }
        if (!touched) return null

        val pieces = ArrayList<StrokeElement>()
        var run = ArrayList<Pt>()
        fun flush() {
            if (run.size >= 2) pieces.add(s.copy(id = IdGen.next(), points = run))
            run = ArrayList()
        }
        for (i in dense.indices) {
            if (inside[i]) flush() else run.add(dense[i])
        }
        flush()
        return pieces
    }

    private fun densify(points: List<Pt>, step: Float): List<Pt> {
        if (points.size < 2) return points
        val out = ArrayList<Pt>(points.size)
        out.add(points[0])
        for (i in 1 until points.size) {
            val a = points[i - 1]
            val b = points[i]
            val d = hypot(b.x - a.x, b.y - a.y)
            val n = floor(d / step).toInt()
            for (k in 1..n) {
                val t = k.toFloat() / (n + 1)
                out.add(Pt(a.x + (b.x - a.x) * t, a.y + (b.y - a.y) * t, a.p + (b.p - a.p) * t))
            }
            out.add(b)
        }
        return out
    }

    /** Bounding box helper for dirty-region invalidation. */
    fun eraserRect(cx: Float, cy: Float, r: Float) = Rect(cx - r, cy - r, cx + r, cy + r)
}
