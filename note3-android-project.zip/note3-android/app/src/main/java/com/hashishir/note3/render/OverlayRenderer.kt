package com.hashishir.note3.render

import android.graphics.Canvas
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.Path
import com.hashishir.note3.editor.DrawingSession
import com.hashishir.note3.engine.GeoKind
import com.hashishir.note3.engine.GeoTool
import com.hashishir.note3.engine.Tool
import com.hashishir.note3.engine.model.ShapeElement
import com.hashishir.note3.engine.model.ShapeKind
import kotlin.math.cos
import kotlin.math.sin

/** Transient visuals that are not part of the page: live stroke, selection handles, lasso, rulers. */
class OverlayRenderer {

    private val accent = 0xFF2979FF.toInt()
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER }
    private val path = Path()

    /** Drawn in world coordinates (canvas already carries the viewport transform). */
    fun drawWorld(canvas: Canvas, s: DrawingSession, pageRenderer: PageRenderer, density: Float) {
        val scale = s.viewport.scale
        // geometry aids sit under the live stroke so drawing along them stays visible
        for (g in s.geometry) drawGeometry(canvas, g, scale, density)

        if (s.previewPoints.isNotEmpty()) {
            pageRenderer.drawStroke(canvas, s.previewPoints, s.previewColor, s.previewWidth, s.previewTool, scale)
        }
        s.previewShape?.let { pageRenderer.drawElement(canvas, it, scale, s.viewport.visibleWorld(s.viewW, s.viewH)) }

        if (s.polygonDraft.isNotEmpty()) {
            line.color = s.settings.color
            line.strokeWidth = s.settings.penWidth
            line.pathEffect = null
            path.rewind()
            path.moveTo(s.polygonDraft[0].x, s.polygonDraft[0].y)
            for (i in 1 until s.polygonDraft.size) path.lineTo(s.polygonDraft[i].x, s.polygonDraft[i].y)
            canvas.drawPath(path, line)
            val r = 7f * density / scale
            fill.color = accent
            canvas.drawCircle(s.polygonDraft[0].x, s.polygonDraft[0].y, r, fill)
            fill.color = s.settings.color
            for (i in 1 until s.polygonDraft.size) canvas.drawCircle(s.polygonDraft[i].x, s.polygonDraft[i].y, r * 0.6f, fill)
        }

        if (s.lasso.size >= 2) {
            line.color = accent
            line.strokeWidth = 1.6f * density / scale
            line.pathEffect = DashPathEffect(floatArrayOf(10f * density / scale, 7f * density / scale), 0f)
            path.rewind()
            path.moveTo(s.lasso[0].x, s.lasso[0].y)
            for (i in 1 until s.lasso.size) path.lineTo(s.lasso[i].x, s.lasso[i].y)
            canvas.drawPath(path, line)
            line.pathEffect = null
        }

        s.eraserPos?.let {
            line.color = 0xFF888888.toInt()
            line.strokeWidth = 1.5f * density / scale
            line.pathEffect = null
            canvas.drawCircle(it.x, it.y, s.settings.eraserRadiusPx * density / scale, line)
        }
    }

    /** Drawn in screen pixels, after the world transform is removed (constant-size handles). */
    fun drawScreen(canvas: Canvas, s: DrawingSession, density: Float) {
        val box = s.selectionBox
        if (box != null && s.selection.isNotEmpty() && s.settings.tool == Tool.SELECT) {
            val v = s.viewport
            val l = v.toScreenX(box.left)
            val t = v.toScreenY(box.top)
            val r = v.toScreenX(box.right)
            val b = v.toScreenY(box.bottom)
            line.color = accent
            line.strokeWidth = 1.5f * density
            line.pathEffect = DashPathEffect(floatArrayOf(8f * density, 5f * density), 0f)
            canvas.drawRect(l, t, r, b, line)
            line.pathEffect = null
            // rotate handle
            val hx = (l + r) / 2f
            val hy = t - DrawingSession.ROTATE_HANDLE_PX * density
            canvas.drawLine(hx, t, hx, hy, line)
            handle(canvas, hx, hy, density, round = true)
            handle(canvas, l, t, density, false)
            handle(canvas, r, t, density, false)
            handle(canvas, r, b, density, false)
            handle(canvas, l, b, density, false)
        }
        if (s.settings.tool == Tool.SHAPE && s.settings.shapeKind == ShapeKind.POLYGON && s.polygonDraft.isNotEmpty()) {
            // nothing extra: the draft itself is drawn in world space
        }
    }

    private fun handle(canvas: Canvas, x: Float, y: Float, density: Float, round: Boolean) {
        val r = 8f * density
        fill.color = 0xFFFFFFFF.toInt()
        line.color = accent
        line.strokeWidth = 2f * density
        if (round) {
            canvas.drawCircle(x, y, r, fill); canvas.drawCircle(x, y, r, line)
        } else {
            canvas.drawRect(x - r, y - r, x + r, y + r, fill); canvas.drawRect(x - r, y - r, x + r, y + r, line)
        }
    }

    // ------------------------------------------------------------------ geometry aids

    private fun drawGeometry(canvas: Canvas, g: GeoTool, scale: Float, density: Float) {
        val poly = g.polygon()
        path.rewind()
        path.moveTo(poly[0].x, poly[0].y)
        for (i in 1 until poly.size) path.lineTo(poly[i].x, poly[i].y)
        path.close()
        fill.color = 0x40F9D65C
        canvas.drawPath(path, fill)
        line.color = 0xFF8D6E00.toInt()
        line.strokeWidth = 1.6f * density / scale
        line.pathEffect = null
        canvas.drawPath(path, line)

        canvas.save()
        canvas.translate(g.cx, g.cy)
        canvas.rotate(Math.toDegrees(g.angle.toDouble()).toFloat())
        line.strokeWidth = 1f * density / scale
        text.color = 0xFF5D4700.toInt()
        text.textSize = g.size * 0.035f
        when (g.kind) {
            GeoKind.RULER -> ruler(canvas, g)
            GeoKind.SET_SQUARE -> setSquare(canvas, g)
            GeoKind.PROTRACTOR -> protractor(canvas, g)
        }
        canvas.restore()

        // grips: centre moves the tool, the end handle rotates and resizes it
        val grip = 9f * density / scale
        fill.color = 0xFFFFFFFF.toInt()
        line.color = 0xFF8D6E00.toInt()
        line.strokeWidth = 2f * density / scale
        canvas.drawCircle(g.cx, g.cy, grip, fill); canvas.drawCircle(g.cx, g.cy, grip, line)
        val h = g.handle()
        fill.color = 0xFFFFB300.toInt()
        canvas.drawCircle(h.x, h.y, grip, fill); canvas.drawCircle(h.x, h.y, grip, line)
    }

    private fun ruler(canvas: Canvas, g: GeoTool) {
        val half = g.size / 2f
        val top = -g.thickness / 2f
        val step = 20f
        var i = 0
        var x = -half
        while (x <= half + 0.01f) {
            val major = i % 5 == 0
            val len = if (major) g.thickness * 0.4f else g.thickness * 0.22f
            canvas.drawLine(x, top, x, top + len, line)
            if (major && i % 5 == 0 && x < half - step) canvas.drawText((i / 5).toString(), x, top + len + text.textSize, text)
            x += step
            i++
        }
    }

    private fun setSquare(canvas: Canvas, g: GeoTool) {
        val h = g.size / 2f
        val step = 20f
        var i = 0
        var t = 0f
        while (t <= g.size) {
            val len = if (i % 5 == 0) g.size * 0.05f else g.size * 0.025f
            canvas.drawLine(-h + t, -h, -h + t, -h + len, line)
            canvas.drawLine(-h, -h + t, -h + len, -h + t, line)
            t += step
            i++
        }
        val m = g.size * 0.08f
        canvas.drawRect(-h, -h, -h + m, -h + m, line)
    }

    private fun protractor(canvas: Canvas, g: GeoTool) {
        val r = g.size / 2f
        for (deg in 0..180 step 5) {
            val a = Math.toRadians(deg.toDouble())
            val len = when {
                deg % 30 == 0 -> r * 0.12f
                deg % 10 == 0 -> r * 0.08f
                else -> r * 0.045f
            }
            val cx = cos(a).toFloat()
            val cy = -sin(a).toFloat()
            canvas.drawLine(cx * r, cy * r, cx * (r - len), cy * (r - len), line)
            if (deg % 30 == 0) canvas.drawText(deg.toString(), cx * (r - len - text.textSize), cy * (r - len - text.textSize) + text.textSize * 0.35f, text)
        }
        canvas.drawLine(-r * 0.04f, 0f, r * 0.04f, 0f, line)
        canvas.drawLine(0f, -r * 0.04f, 0f, r * 0.04f, line)
    }
}
