package com.hashishir.note3

import android.app.Application
import com.hashishir.note3.data.BoardRepository
import com.hashishir.note3.data.MediaFiles
import com.hashishir.note3.data.PageStore
import com.hashishir.note3.data.SettingsStore
import com.hashishir.note3.data.db.AppDatabase
import com.hashishir.note3.render.AsyncBitmapCache
import com.hashishir.note3.render.PdfPages
import com.hashishir.note3.render.RenderResources
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.asCoroutineDispatcher
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.io.File
import java.util.concurrent.Executors

/** Hand-written dependency container; keeps the app free of a DI framework. */
class AppContainer(app: Application) {
    val settings = SettingsStore(app)
    val database = AppDatabase.create(app)
    val pageStore = PageStore(File(app.filesDir, "pages"))
    val media = MediaFiles(File(app.filesDir, "media"), app.contentResolver)
    val repository = BoardRepository(database, pageStore, media.dir)
    val pdfPages = PdfPages()

    /** Outlives screens, so a pending autosave is never lost when the editor closes. */
    val appScope = CoroutineScope(SupervisorJob())

    /** Page writes and page loads share one thread so they happen in the order they were requested. */
    val saveDispatcher = Executors.newSingleThreadExecutor { r -> Thread(r, "page-io") }.asCoroutineDispatcher()

    /** Suspends until every page write requested so far has finished. */
    suspend fun awaitSaves() = kotlinx.coroutines.withContext(saveDispatcher) { }

    private val _renderTick = MutableStateFlow(0)

    /** Incremented whenever a background bitmap (image, PDF page, thumbnail) finished loading. */
    val renderTick: StateFlow<Int> = _renderTick

    private val bitmaps = AsyncBitmapCache(cacheBytes(app)) { _renderTick.value++ }
    val renderResources = RenderResources(media, pdfPages, bitmaps)

    private fun cacheBytes(app: Application): Int {
        val am = app.getSystemService(android.content.Context.ACTIVITY_SERVICE) as android.app.ActivityManager
        val perApp = am.memoryClass * 1024 * 1024
        // A sixth of the app heap, between 16 and 64 MB: friendly to 2-3 GB phones.
        return (perApp / 6).coerceIn(16 shl 20, 64 shl 20)
    }
}

class Note3App : Application() {
    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
    }

    override fun onTrimMemory(level: Int) {
        super.onTrimMemory(level)
        if (level >= TRIM_MEMORY_RUNNING_LOW) container.renderResources.bitmaps.clear()
    }
}
