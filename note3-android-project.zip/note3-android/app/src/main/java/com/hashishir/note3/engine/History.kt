package com.hashishir.note3.engine

/**
 * Snapshot-based undo/redo. States are immutable, so snapshots share structure and stay cheap.
 *
 * Typical gesture flow: remember [current] as the base, call [update] while the gesture runs
 * (no history entries), then [commit] with the base when the gesture ends so the whole gesture
 * is exactly one undo step.
 */
class History<T>(initial: T, private val limit: Int = 100) {
    private val undoStack = ArrayDeque<T>()
    private val redoStack = ArrayDeque<T>()

    var current: T = initial
        private set

    val canUndo: Boolean get() = undoStack.isNotEmpty()
    val canRedo: Boolean get() = redoStack.isNotEmpty()

    /** Replaces the current state without creating an undo entry (used mid-gesture). */
    fun update(state: T) {
        current = state
    }

    /** Records [base] as an undo point if the state actually changed since then. */
    fun commit(base: T): Boolean {
        if (base === current) return false
        undoStack.addLast(base)
        while (undoStack.size > limit) undoStack.removeFirst()
        redoStack.clear()
        return true
    }

    /** Convenience: apply a change as a single undo step. */
    fun push(state: T) {
        val base = current
        current = state
        commit(base)
    }

    fun undo(): T? {
        if (undoStack.isEmpty()) return null
        redoStack.addLast(current)
        current = undoStack.removeLast()
        return current
    }

    fun redo(): T? {
        if (redoStack.isEmpty()) return null
        undoStack.addLast(current)
        current = redoStack.removeLast()
        return current
    }

    fun reset(state: T) {
        undoStack.clear()
        redoStack.clear()
        current = state
    }
}
