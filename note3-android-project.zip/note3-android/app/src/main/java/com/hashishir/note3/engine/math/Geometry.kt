package com.hashishir.note3.engine.math

import kotlinx.serialization.Serializable
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

/** Plain 2D vector / point in world coordinates. No Android dependency so the engine is JVM-testable. */
@Serializable
data class Vec(val x: Float, val y: Float) {
    operator fun plus(o: Vec) = Vec(x + o.x, y + o.y)
    operator fun minus(o: Vec) = Vec(x - o.x, y - o.y)
    operator fun times(s: Float) = Vec(x * s, y * s)
    fun length(): Float = hypot(x, y)
    fun dot(o: Vec): Float = x * o.x + y * o.y
    fun cross(o: Vec): Float = x * o.y - y * o.x
    fun dist(o: Vec): Float = hypot(x - o.x, y - o.y)
}

data class Rect(val left: Float, val top: Float, val right: Float, val bottom: Float) {
    val width: Float get() = right - left
    val height: Float get() = bottom - top
    val centerX: Float get() = (left + right) / 2f
    val centerY: Float get() = (top + bottom) / 2f

    fun inflate(d: Float) = Rect(left - d, top - d, right + d, bottom + d)
    fun contains(x: Float, y: Float) = x in left..right && y in top..bottom
    fun intersects(o: Rect) = left <= o.right && o.left <= right && top <= o.bottom && o.top <= bottom
    fun union(o: Rect) = Rect(min(left, o.left), min(top, o.top), max(right, o.right), max(bottom, o.bottom))

    companion object {
        fun fromPoints(points: List<Vec>): Rect {
            if (points.isEmpty()) return Rect(0f, 0f, 0f, 0f)
            var l = points[0].x
            var t = points[0].y
            var r = l
            var b = t
            for (p in points) {
                if (p.x < l) l = p.x
                if (p.x > r) r = p.x
                if (p.y < t) t = p.y
                if (p.y > b) b = p.y
            }
            return Rect(l, t, r, b)
        }
    }
}

/**
 * 2D affine transform: x' = a*x + c*y + e ; y' = b*x + d*y + f.
 * Elements bake transforms into their geometry, so selection edits stay exact and simple.
 */
data class Affine(
    val a: Float, val b: Float, val c: Float, val d: Float, val e: Float, val f: Float
) {
    fun mapX(x: Float, y: Float): Float = a * x + c * y + e
    fun mapY(x: Float, y: Float): Float = b * x + d * y + f
    fun map(v: Vec): Vec = Vec(mapX(v.x, v.y), mapY(v.x, v.y))

    /** Applies this transform first, then [o]. */
    infix fun then(o: Affine): Affine = Affine(
        a = o.a * a + o.c * b,
        b = o.b * a + o.d * b,
        c = o.a * c + o.c * d,
        d = o.b * c + o.d * d,
        e = o.a * e + o.c * f + o.e,
        f = o.b * e + o.d * f + o.f
    )

    val determinant: Float get() = a * d - b * c

    /** Uniform-equivalent scale factor (geometric mean of axis scales). */
    val scaleFactor: Float get() = sqrt(abs(determinant))

    fun invert(): Affine? {
        val det = determinant
        if (abs(det) < 1e-9f) return null
        val ia = d / det
        val ib = -b / det
        val ic = -c / det
        val id = a / det
        return Affine(ia, ib, ic, id, -(ia * e + ic * f), -(ib * e + id * f))
    }

    companion object {
        val IDENTITY = Affine(1f, 0f, 0f, 1f, 0f, 0f)
        fun translate(dx: Float, dy: Float) = Affine(1f, 0f, 0f, 1f, dx, dy)
        fun scale(sx: Float, sy: Float, px: Float, py: Float) =
            Affine(sx, 0f, 0f, sy, px - sx * px, py - sy * py)

        fun rotate(radians: Float, px: Float, py: Float): Affine {
            val cs = cos(radians)
            val sn = sin(radians)
            return Affine(cs, sn, -sn, cs, px - cs * px + sn * py, py - sn * px - cs * py)
        }
    }
}

object Geo {
    fun distPointSegment(px: Float, py: Float, ax: Float, ay: Float, bx: Float, by: Float): Float {
        val dx = bx - ax
        val dy = by - ay
        val len2 = dx * dx + dy * dy
        if (len2 < 1e-12f) return hypot(px - ax, py - ay)
        var t = ((px - ax) * dx + (py - ay) * dy) / len2
        t = t.coerceIn(0f, 1f)
        return hypot(px - (ax + t * dx), py - (ay + t * dy))
    }

    fun pointInPolygon(x: Float, y: Float, poly: List<Vec>): Boolean {
        if (poly.size < 3) return false
        var inside = false
        var j = poly.size - 1
        for (i in poly.indices) {
            val pi = poly[i]
            val pj = poly[j]
            if ((pi.y > y) != (pj.y > y) &&
                x < (pj.x - pi.x) * (y - pi.y) / (pj.y - pi.y) + pi.x
            ) inside = !inside
            j = i
        }
        return inside
    }

    fun pathLength(points: List<Vec>): Float {
        var s = 0f
        for (i in 1 until points.size) s += points[i - 1].dist(points[i])
        return s
    }

    /** Ramer–Douglas–Peucker simplification (iterative, safe for long strokes). */
    fun simplifyRdp(points: List<Vec>, epsilon: Float): List<Vec> {
        val n = points.size
        if (n < 3) return points
        val keep = BooleanArray(n)
        keep[0] = true
        keep[n - 1] = true
        val stack = ArrayDeque<IntArray>()
        stack.addLast(intArrayOf(0, n - 1))
        while (stack.isNotEmpty()) {
            val (s, e) = stack.removeLast()
            if (e <= s + 1) continue
            var maxD = -1f
            var idx = -1
            val a = points[s]
            val b = points[e]
            for (i in s + 1 until e) {
                val d = distPointSegment(points[i].x, points[i].y, a.x, a.y, b.x, b.y)
                if (d > maxD) {
                    maxD = d
                    idx = i
                }
            }
            if (maxD > epsilon && idx >= 0) {
                keep[idx] = true
                stack.addLast(intArrayOf(s, idx))
                stack.addLast(intArrayOf(idx, e))
            }
        }
        val out = ArrayList<Vec>()
        for (i in 0 until n) if (keep[i]) out.add(points[i])
        return out
    }

    /** Resamples a polyline to [count] points evenly spaced along its length. */
    fun resampleUniform(points: List<Vec>, count: Int): List<Vec> {
        if (points.size < 2 || count < 2) return points
        val total = pathLength(points)
        if (total < 1e-6f) return List(count) { points[0] }
        val step = total / (count - 1)
        val out = ArrayList<Vec>(count)
        out.add(points[0])
        var acc = 0f
        var next = step
        for (i in 1 until points.size) {
            val a = points[i - 1]
            val b = points[i]
            val seg = a.dist(b)
            while (seg > 0f && acc + seg >= next && out.size < count - 1) {
                val t = (next - acc) / seg
                out.add(Vec(a.x + (b.x - a.x) * t, a.y + (b.y - a.y) * t))
                next += step
            }
            acc += seg
        }
        while (out.size < count) out.add(points.last())
        return out
    }

    fun angleBetween(a: Vec, b: Vec): Float = atan2(a.cross(b), a.dot(b))
}
