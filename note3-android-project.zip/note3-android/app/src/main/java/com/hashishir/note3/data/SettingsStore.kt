package com.hashishir.note3.data

import android.content.Context
import com.hashishir.note3.engine.RecognizeMode
import com.hashishir.note3.engine.Tool
import com.hashishir.note3.engine.ToolSettings
import com.hashishir.note3.engine.model.PaperStyle
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

enum class ThemeMode { SYSTEM, LIGHT, DARK }

data class AppSettings(
    val theme: ThemeMode = ThemeMode.SYSTEM,
    val fingerDraws: Boolean = true,
    val recognize: RecognizeMode = RecognizeMode.HOLD,
    val keepScreenOn: Boolean = true,
    val defaultPaper: PaperStyle = PaperStyle.BLANK,
    val defaultPaperColor: Int = 0xFFFFFFFF.toInt(),
    val eraserRadiusDp: Float = 18f
)

/** Small SharedPreferences-backed store: app settings plus the last used pen settings. */
class SettingsStore(context: Context) {

    private val prefs = context.applicationContext.getSharedPreferences("settings", Context.MODE_PRIVATE)
    private val state = MutableStateFlow(read())
    val flow: StateFlow<AppSettings> = state

    private inline fun <reified E : Enum<E>> enumOf(key: String, default: E): E =
        runCatching { enumValueOf<E>(prefs.getString(key, default.name) ?: default.name) }.getOrDefault(default)

    private fun read() = AppSettings(
        theme = enumOf("theme", ThemeMode.SYSTEM),
        fingerDraws = prefs.getBoolean("fingerDraws", true),
        recognize = enumOf("recognize", RecognizeMode.HOLD),
        keepScreenOn = prefs.getBoolean("keepScreenOn", true),
        defaultPaper = enumOf("defaultPaper", PaperStyle.BLANK),
        defaultPaperColor = prefs.getInt("defaultPaperColor", 0xFFFFFFFF.toInt()),
        eraserRadiusDp = prefs.getFloat("eraserRadiusDp", 18f)
    )

    fun update(transform: (AppSettings) -> AppSettings) {
        val n = transform(state.value)
        prefs.edit()
            .putString("theme", n.theme.name)
            .putBoolean("fingerDraws", n.fingerDraws)
            .putString("recognize", n.recognize.name)
            .putBoolean("keepScreenOn", n.keepScreenOn)
            .putString("defaultPaper", n.defaultPaper.name)
            .putInt("defaultPaperColor", n.defaultPaperColor)
            .putFloat("eraserRadiusDp", n.eraserRadiusDp)
            .apply()
        state.value = n
    }

    /** Pen settings are restored per launch so the user's color and widths survive. */
    fun loadTool(): ToolSettings {
        val a = state.value
        val tool = runCatching { enumValueOf<Tool>(prefs.getString("tool", Tool.PEN.name) ?: "PEN") }
            .getOrDefault(Tool.PEN)
        return ToolSettings(
            tool = if (tool == Tool.HAND || tool == Tool.TEXT) Tool.PEN else tool,
            color = prefs.getInt("toolColor", 0xFF1A1A1A.toInt()),
            penWidth = prefs.getFloat("penWidth", 3f),
            brushWidth = prefs.getFloat("brushWidth", 10f),
            highlighterWidth = prefs.getFloat("highlighterWidth", 22f),
            fingerDraws = a.fingerDraws,
            recognize = a.recognize,
            eraserRadiusPx = a.eraserRadiusDp
        )
    }

    fun saveTool(t: ToolSettings) {
        prefs.edit()
            .putString("tool", t.tool.name)
            .putInt("toolColor", t.color)
            .putFloat("penWidth", t.penWidth)
            .putFloat("brushWidth", t.brushWidth)
            .putFloat("highlighterWidth", t.highlighterWidth)
            .apply()
    }
}
