package com.hashishir.note3.export

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import com.hashishir.note3.engine.math.Rect
import com.hashishir.note3.engine.model.Page
import com.hashishir.note3.render.PageRenderer
import com.hashishir.note3.render.RenderPage
import com.hashishir.note3.render.RenderResources
import java.io.IOException
import java.io.OutputStream
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

enum class ImageFormat(val ext: String, val mime: String) {
    PNG("png", "image/png"),
    JPG("jpg", "image/jpeg")
}

/**
 * Renders pages to PNG/JPG bitmaps or a multi-page PDF. All loads are synchronous, so call from a
 * background thread. PDF output keeps strokes, shapes and text as vectors.
 */
class Exporter(resources: RenderResources) {

    private val res = resources.withBlocking()
    private val renderer = PageRenderer(res)

    /** The world rectangle that gets exported for a page. */
    fun boundsOf(page: Page): Rect {
        page.pdf?.let { return Rect(0f, 0f, it.width, it.height) }
        var b: Rect? = null
        val visible = page.layers.filter { it.visible }.map { it.id }.toHashSet()
        for (e in page.elements) {
            if (e.layerId !in visible) continue
            b = if (b == null) e.bounds() else b.union(e.bounds())
        }
        if (b == null) return Rect(0f, 0f, DEFAULT_W, DEFAULT_H)
        val m = MARGIN
        var r = b.inflate(m)
        if (r.width < MIN_W) r = Rect(r.centerX - MIN_W / 2f, r.top, r.centerX + MIN_W / 2f, r.bottom)
        if (r.height < MIN_H) r = Rect(r.left, r.centerY - MIN_H / 2f, r.right, r.centerY + MIN_H / 2f)
        return r
    }

    private fun renderPage(page: Page) = RenderPage(page.paper, page.paperColor, page.pdf, page.layers, page.elements)

    /** Pixel scale so the bitmap stays within ~8 megapixels and 4096 px per side. */
    private fun pixelScale(b: Rect): Float {
        val w = b.width.coerceAtLeast(1f)
        val h = b.height.coerceAtLeast(1f)
        val byPixels = sqrt(MAX_PIXELS / (w * h))
        val bySide = MAX_SIDE / max(w, h)
        return min(2f, min(byPixels, bySide))
    }

    @Throws(IOException::class)
    fun renderBitmap(page: Page): Bitmap {
        val b = boundsOf(page)
        val s = pixelScale(b)
        val bw = (b.width * s).toInt().coerceAtLeast(1)
        val bh = (b.height * s).toInt().coerceAtLeast(1)
        val bmp = try {
            Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888)
        } catch (e: OutOfMemoryError) {
            throw IOException("Not enough memory to export this page as an image.")
        }
        val c = Canvas(bmp)
        c.drawColor(if (page.pdf != null) 0xFFFFFFFF.toInt() else page.paperColor)
        c.scale(s, s)
        c.translate(-b.left, -b.top)
        val rp = renderPage(page)
        renderer.drawBackground(c, rp, s, b)
        renderer.drawElements(c, rp, s, b)
        return bmp
    }

    @Throws(IOException::class)
    fun writeImage(page: Page, format: ImageFormat, out: OutputStream) {
        val bmp = renderBitmap(page)
        try {
            val ok = bmp.compress(
                if (format == ImageFormat.PNG) Bitmap.CompressFormat.PNG else Bitmap.CompressFormat.JPEG,
                if (format == ImageFormat.PNG) 100 else 92,
                out
            )
            if (!ok) throw IOException("Could not encode the image.")
            out.flush()
        } finally {
            bmp.recycle()
        }
    }

    /** One PDF page per whiteboard page. [onProgress] receives (done, total). */
    @Throws(IOException::class)
    fun writePdf(pages: List<Page>, out: OutputStream, onProgress: (Int, Int) -> Unit = { _, _ -> }) {
        if (pages.isEmpty()) throw IOException("Nothing to export.")
        val doc = PdfDocument()
        try {
            val bg = Paint().apply { style = Paint.Style.FILL }
            pages.forEachIndexed { i, page ->
                val b = boundsOf(page)
                // PDF units are points; keep each page within ~A2 so viewers stay responsive.
                val k = min(1f, MAX_PDF_SIDE / max(b.width, b.height))
                val pw = (b.width * k).toInt().coerceAtLeast(1)
                val ph = (b.height * k).toInt().coerceAtLeast(1)
                val p = doc.startPage(PdfDocument.PageInfo.Builder(pw, ph, i + 1).create())
                val c = p.canvas
                bg.color = if (page.pdf != null) 0xFFFFFFFF.toInt() else page.paperColor
                c.drawRect(0f, 0f, pw.toFloat(), ph.toFloat(), bg)
                c.scale(k, k)
                c.translate(-b.left, -b.top)
                val rp = renderPage(page)
                // scale hint 2f: embedded PDF/image bitmaps are loaded at 2x the page's point size
                renderer.drawBackground(c, rp, 2f * k, b)
                renderer.drawElements(c, rp, 2f * k, b)
                doc.finishPage(p)
                onProgress(i + 1, pages.size)
            }
            doc.writeTo(out)
            out.flush()
        } finally {
            doc.close()
        }
    }

    companion object {
        const val DEFAULT_W = 1000f
        const val DEFAULT_H = 1400f
        const val MIN_W = 600f
        const val MIN_H = 400f
        const val MARGIN = 40f
        const val MAX_PIXELS = 8_000_000f
        const val MAX_SIDE = 4096f
        const val MAX_PDF_SIDE = 1684f
    }
}
