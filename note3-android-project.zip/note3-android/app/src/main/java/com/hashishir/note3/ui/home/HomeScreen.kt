package com.hashishir.note3.ui.home

import android.text.format.DateUtils
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Backup
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.hashishir.note3.data.ThemeMode
import com.hashishir.note3.data.db.BoardSummary
import com.hashishir.note3.engine.RecognizeMode
import com.hashishir.note3.engine.model.PaperStyle
import com.hashishir.note3.ui.components.ChoiceChips
import com.hashishir.note3.ui.components.PaperPicker
import com.hashishir.note3.ui.components.SectionLabel
import com.hashishir.note3.ui.components.TouchTarget

private enum class HomeTab(val label: String) { BOARDS("Boards"), BACKUP("Backup"), SETTINGS("Settings") }

@Composable
fun HomeScreen(vm: HomeViewModel, onOpen: (String) -> Unit) {
    var tab by rememberSaveable { mutableStateOf(HomeTab.BOARDS) }
    val snack = remember { SnackbarHostState() }
    val busy by vm.busy.collectAsState()

    LaunchedEffect(Unit) { vm.messages.collect { snack.showSnackbar(it) } }
    LaunchedEffect(Unit) { vm.created.collect { onOpen(it) } }

    Scaffold(
        snackbarHost = { SnackbarHost(snack) },
        bottomBar = {
            NavigationBar {
                for (t in HomeTab.entries) {
                    NavigationBarItem(
                        selected = tab == t,
                        onClick = { tab = t },
                        icon = {
                            Icon(
                                when (t) {
                                    HomeTab.BOARDS -> Icons.Default.Folder
                                    HomeTab.BACKUP -> Icons.Default.Backup
                                    HomeTab.SETTINGS -> Icons.Default.Settings
                                },
                                contentDescription = null
                            )
                        },
                        label = { Text(t.label) }
                    )
                }
            }
        }
    ) { pad ->
        Box(Modifier.fillMaxSize().padding(pad)) {
            when (tab) {
                HomeTab.BOARDS -> BoardsTab(vm, onOpen)
                HomeTab.BACKUP -> BackupTab(vm)
                HomeTab.SETTINGS -> SettingsTab(vm)
            }
            if (busy != null) BusyOverlay(busy!!)
        }
    }
}

@Composable
fun BusyOverlay(label: String) {
    Box(
        Modifier
            .fillMaxSize()
            .clickable(enabled = true, onClick = {}),
        contentAlignment = Alignment.Center
    ) {
        Card {
            Row(Modifier.padding(20.dp), verticalAlignment = Alignment.CenterVertically) {
                CircularProgressIndicator(Modifier.padding(end = 16.dp))
                Text(label)
            }
        }
    }
}

// ---------------------------------------------------------------------- boards

@Composable
private fun BoardsTab(vm: HomeViewModel, onOpen: (String) -> Unit) {
    val boards by vm.boards.collectAsState()
    val settings by vm.settings.collectAsState()
    var showNew by rememberSaveable { mutableStateOf(false) }
    var renameTarget by remember { mutableStateOf<BoardSummary?>(null) }
    var deleteTarget by remember { mutableStateOf<BoardSummary?>(null) }

    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")) { uri ->
        val id = pendingExport
        pendingExport = null
        if (uri != null && id != null) vm.export(uri, id, "Saving project file…")
    }

    Box(Modifier.fillMaxSize()) {
        val list = boards
        when {
            list == null -> CircularProgressIndicator(Modifier.align(Alignment.Center))
            list.isEmpty() -> Column(
                Modifier.align(Alignment.Center).padding(32.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("No boards yet", style = MaterialTheme.typography.headlineSmall)
                Spacer(Modifier.height(8.dp))
                Text(
                    "Create a whiteboard to start drawing, or restore a backup from the Backup tab.",
                    style = MaterialTheme.typography.bodyMedium
                )
            }
            else -> LazyColumn(
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 96.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(list, key = { it.id }) { b ->
                    BoardCard(
                        b,
                        onOpen = { onOpen(b.id) },
                        onRename = { renameTarget = b },
                        onDuplicate = { vm.duplicate(b.id) },
                        onExport = {
                            pendingExport = b.id
                            exportLauncher.launch(safeName(b.title) + ".n3wb")
                        },
                        onDelete = { deleteTarget = b }
                    )
                }
            }
        }
        ExtendedFloatingActionButton(
            onClick = { showNew = true },
            icon = { Icon(Icons.Default.Add, null) },
            text = { Text("New board") },
            modifier = Modifier.align(Alignment.BottomEnd).padding(16.dp)
        )
    }

    if (showNew) {
        NewBoardDialog(
            defaultPaper = settings.defaultPaper,
            defaultColor = settings.defaultPaperColor,
            onDismiss = { showNew = false },
            onCreate = { t, p, c -> showNew = false; vm.createBoard(t, p, c) }
        )
    }
    renameTarget?.let { b ->
        var text by remember(b.id) { mutableStateOf(b.title) }
        AlertDialog(
            onDismissRequest = { renameTarget = null },
            title = { Text("Rename board") },
            text = { OutlinedTextField(text, { text = it }, singleLine = true) },
            confirmButton = { TextButton(onClick = { vm.rename(b.id, text); renameTarget = null }) { Text("Rename") } },
            dismissButton = { TextButton(onClick = { renameTarget = null }) { Text("Cancel") } }
        )
    }
    deleteTarget?.let { b ->
        AlertDialog(
            onDismissRequest = { deleteTarget = null },
            title = { Text("Delete \"${b.title}\"?") },
            text = { Text("All ${b.pageCount} page(s) of this board will be removed from this device. This cannot be undone.") },
            confirmButton = { TextButton(onClick = { vm.delete(b.id); deleteTarget = null }) { Text("Delete") } },
            dismissButton = { TextButton(onClick = { deleteTarget = null }) { Text("Cancel") } }
        )
    }
}

private var pendingExport: String? = null

private fun safeName(title: String): String =
    title.replace(Regex("[^A-Za-z0-9 _\\-]"), "_").trim().ifEmpty { "board" }

@Composable
private fun BoardCard(
    b: BoardSummary,
    onOpen: () -> Unit,
    onRename: () -> Unit,
    onDuplicate: () -> Unit,
    onExport: () -> Unit,
    onDelete: () -> Unit
) {
    var menu by remember { mutableStateOf(false) }
    Card(Modifier.fillMaxWidth().clickable(onClick = onOpen)) {
        Row(Modifier.padding(start = 16.dp, top = 8.dp, bottom = 8.dp, end = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f).padding(vertical = 8.dp)) {
                Text(b.title, style = MaterialTheme.typography.titleMedium, maxLines = 1)
                Text(
                    "${b.pageCount} page${if (b.pageCount == 1) "" else "s"} · edited " +
                        DateUtils.getRelativeTimeSpanString(b.updatedAt, System.currentTimeMillis(), DateUtils.MINUTE_IN_MILLIS),
                    style = MaterialTheme.typography.bodySmall
                )
            }
            Box {
                IconButton(onClick = { menu = true }, modifier = Modifier.height(TouchTarget)) {
                    Icon(Icons.Default.MoreVert, contentDescription = "Board options")
                }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    DropdownMenuItem(text = { Text("Rename") }, onClick = { menu = false; onRename() })
                    DropdownMenuItem(text = { Text("Duplicate") }, onClick = { menu = false; onDuplicate() })
                    DropdownMenuItem(text = { Text("Export project file") }, onClick = { menu = false; onExport() })
                    DropdownMenuItem(text = { Text("Delete") }, onClick = { menu = false; onDelete() })
                }
            }
        }
    }
}

@Composable
private fun NewBoardDialog(
    defaultPaper: PaperStyle,
    defaultColor: Int,
    onDismiss: () -> Unit,
    onCreate: (String, PaperStyle, Int) -> Unit
) {
    var title by rememberSaveable { mutableStateOf("") }
    var paper by rememberSaveable { mutableStateOf(defaultPaper) }
    var color by rememberSaveable { mutableStateOf(defaultColor) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("New board") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                OutlinedTextField(
                    title, { title = it }, label = { Text("Title") }, singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                PaperPicker(paper, color) { p, c -> paper = p; color = c }
            }
        },
        confirmButton = { TextButton(onClick = { onCreate(title.trim().ifEmpty { "Untitled" }, paper, color) }) { Text("Create") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

// ---------------------------------------------------------------------- backup

@Composable
private fun BackupTab(vm: HomeViewModel) {
    val backupLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")) { uri ->
        if (uri != null) vm.export(uri, null, "Creating backup…")
    }
    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.import(uri)
    }
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Backup & restore", style = MaterialTheme.typography.headlineSmall)
        Text(
            "A backup contains every board with its pages, images, PDFs and media in one .n3wb file. " +
                "It works fully offline: store it on your phone, a memory card or any cloud app you already use.",
            style = MaterialTheme.typography.bodyMedium
        )
        Button(
            onClick = { backupLauncher.launch("note3-backup-${java.text.SimpleDateFormat("yyyyMMdd-HHmm", java.util.Locale.US).format(java.util.Date())}.n3wb") },
            modifier = Modifier.fillMaxWidth().height(56.dp)
        ) { Text("Back up all boards") }
        OutlinedButton(
            onClick = { importLauncher.launch(arrayOf("*/*")) },
            modifier = Modifier.fillMaxWidth().height(56.dp)
        ) { Text("Restore backup / import project file") }
        Text(
            "Restoring or importing adds the boards in the file as new boards. Your existing boards are never overwritten.",
            style = MaterialTheme.typography.bodySmall
        )
    }
}

// ---------------------------------------------------------------------- settings

@Composable
private fun SettingsTab(vm: HomeViewModel) {
    val s by vm.settings.collectAsState()
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)
    ) {
        Text("Settings", style = MaterialTheme.typography.headlineSmall)

        SectionLabel("Theme")
        ChoiceChips(
            listOf("System" to ThemeMode.SYSTEM, "Light" to ThemeMode.LIGHT, "Dark" to ThemeMode.DARK),
            s.theme, { v -> vm.updateSettings { it.copy(theme = v) } }
        )

        SectionLabel("Drawing")
        SwitchRow("Draw with finger", "Turn off to write with a stylus only; fingers then pan and zoom (palm rejection).", s.fingerDraws) { v ->
            vm.updateSettings { it.copy(fingerDraws = v) }
        }
        Text("Shape recognition", style = MaterialTheme.typography.bodyLarge, modifier = Modifier.padding(top = 8.dp))
        ChoiceChips(
            listOf("Off" to RecognizeMode.OFF, "Hold at end" to RecognizeMode.HOLD, "Always" to RecognizeMode.ALWAYS),
            s.recognize, { v -> vm.updateSettings { it.copy(recognize = v) } }
        )
        Text("Eraser size: ${s.eraserRadiusDp.toInt()} dp", modifier = Modifier.padding(top = 12.dp))
        Slider(
            value = s.eraserRadiusDp,
            onValueChange = { v -> vm.updateSettings { it.copy(eraserRadiusDp = v) } },
            valueRange = 8f..48f
        )

        SectionLabel("Screen")
        SwitchRow("Keep screen on while editing", null, s.keepScreenOn) { v -> vm.updateSettings { it.copy(keepScreenOn = v) } }

        SectionLabel("New boards")
        PaperPicker(s.defaultPaper, s.defaultPaperColor) { p, c -> vm.updateSettings { it.copy(defaultPaper = p, defaultPaperColor = c) } }

        HorizontalDivider(Modifier.padding(vertical = 16.dp))
        SectionLabel("About")
        Text(
            "Note3 Whiteboard works completely offline. Everything is stored on this device; no account, ads or network access.",
            style = MaterialTheme.typography.bodyMedium
        )
    }
}

@Composable
private fun SwitchRow(title: String, subtitle: String?, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth().height(if (subtitle == null) TouchTarget + 8.dp else 72.dp).clickable { onChange(!checked) },
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge)
            if (subtitle != null) Text(subtitle, style = MaterialTheme.typography.bodySmall)
        }
        Switch(checked = checked, onCheckedChange = onChange)
    }
}
