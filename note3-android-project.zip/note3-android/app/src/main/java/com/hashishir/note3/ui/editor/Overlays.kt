package com.hashishir.note3.ui.editor

import android.net.Uri
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathFillType
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import com.hashishir.note3.engine.model.MediaElement
import com.hashishir.note3.engine.model.MediaKind
import com.hashishir.note3.ui.components.ColorRow
import com.hashishir.note3.ui.components.SectionLabel
import com.hashishir.note3.ui.components.TouchTarget
import java.io.File

// ---------------------------------------------------------------------- spotlight

/** Dims everything except a movable, resizable circle. Drag to move, pinch to resize. */
@Composable
fun SpotlightOverlay() {
    var center by remember { mutableStateOf(Offset.Unspecified) }
    var radius by remember { mutableFloatStateOf(-1f) }
    Canvas(
        Modifier
            .fillMaxSize()
            .pointerInput(Unit) {
                detectTransformGestures { _, pan, zoom, _ ->
                    val base = if (center.isUnspecified) Offset(size.width / 2f, size.height / 2f) else center
                    center = base + pan
                    val r = if (radius < 0f) size.minDimension * 0.22f else radius
                    radius = (r * zoom).coerceIn(48f, size.maxDimension.toFloat())
                }
            }
    ) {
        val c = if (center.isUnspecified) Offset(size.width / 2f, size.height / 2f) else center
        val r = if (radius < 0f) size.minDimension * 0.22f else radius
        val p = Path().apply {
            fillType = PathFillType.EvenOdd
            addRect(Rect(0f, 0f, size.width, size.height))
            addOval(Rect(c.x - r, c.y - r, c.x + r, c.y + r))
        }
        drawPath(p, Color.Black.copy(alpha = 0.8f))
        drawCircle(Color.White.copy(alpha = 0.7f), radius = r, center = c, style = Stroke(width = 2.dp.toPx()))
    }
}

// ---------------------------------------------------------------------- screen cover

enum class CoverSide(val label: String) { TOP("From top"), BOTTOM("From bottom"), LEFT("From left"), RIGHT("From right") }

/** A curtain that hides part of the board; drag it to reveal or hide content. Only the curtain captures touches. */
@Composable
fun ScreenCover(side: CoverSide) {
    BoxWithConstraints(Modifier.fillMaxSize()) {
        var frac by remember(side) { mutableFloatStateOf(0.92f) }
        val wPx = constraints.maxWidth.toFloat().coerceAtLeast(1f)
        val hPx = constraints.maxHeight.toFloat().coerceAtLeast(1f)
        val horizontal = side == CoverSide.LEFT || side == CoverSide.RIGHT
        val align = when (side) {
            CoverSide.TOP -> Alignment.TopCenter
            CoverSide.BOTTOM -> Alignment.BottomCenter
            CoverSide.LEFT -> Alignment.CenterStart
            CoverSide.RIGHT -> Alignment.CenterEnd
        }
        val size = if (horizontal) Modifier.fillMaxHeight().width(maxWidth * frac) else Modifier.fillMaxWidth().height(maxHeight * frac)
        Box(
            Modifier
                .align(align)
                .then(size)
                .background(Color(0xFF37474F))
                .pointerInput(side) {
                    detectDragGestures { change, drag ->
                        change.consume()
                        val d = when (side) {
                            CoverSide.TOP -> drag.y / hPx
                            CoverSide.BOTTOM -> -drag.y / hPx
                            CoverSide.LEFT -> drag.x / wPx
                            CoverSide.RIGHT -> -drag.x / wPx
                        }
                        frac = (frac + d).coerceIn(0.06f, 1f)
                    }
                },
            contentAlignment = Alignment.Center
        ) {
            Text("Drag to reveal", color = Color.White.copy(alpha = 0.75f), style = MaterialTheme.typography.labelLarge)
        }
    }
}

// ---------------------------------------------------------------------- text editor

@Composable
fun TextEditDialog(
    state: TextEditState,
    onCancel: () -> Unit,
    onDelete: () -> Unit,
    onCommit: (String, Float, Int) -> Unit,
    onCustomColor: (Int, (Int) -> Unit) -> Unit
) {
    var text by remember(state) { mutableStateOf(state.text) }
    var size by remember(state) { mutableFloatStateOf(state.fontSize) }
    var color by remember(state) { mutableStateOf(state.color) }
    AlertDialog(
        onDismissRequest = onCancel,
        title = { Text(if (state.elementId == null) "Add text" else "Edit text") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                OutlinedTextField(
                    value = text, onValueChange = { text = it },
                    label = { Text("Text") }, minLines = 2, maxLines = 6,
                    modifier = Modifier.fillMaxWidth()
                )
                SectionLabel("Size: ${size.toInt()}")
                Slider(value = size, onValueChange = { size = it }, valueRange = 14f..120f)
                SectionLabel("Color")
                ColorRow(color, { color = it }, { onCustomColor(color) { c -> color = c } })
            }
        },
        confirmButton = { TextButton(onClick = { onCommit(text, size, color) }, enabled = text.isNotBlank()) { Text("OK") } },
        dismissButton = {
            Row {
                if (state.elementId != null) TextButton(onClick = onDelete) { Text("Delete") }
                TextButton(onClick = onCancel) { Text("Cancel") }
            }
        }
    )
}

// ---------------------------------------------------------------------- media player

@Composable
fun MediaPlayerDialog(el: MediaElement, file: File, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val player = remember { ExoPlayer.Builder(ctx).build() }
    DisposableEffect(player) {
        player.setMediaItem(MediaItem.fromUri(Uri.fromFile(file)))
        player.prepare()
        player.playWhenReady = true
        onDispose { player.release() }
    }
    Dialog(onDismissRequest = onClose) {
        Surface(shape = MaterialTheme.shapes.large, tonalElevation = 6.dp) {
            Column(Modifier.padding(12.dp)) {
                Text(el.name, style = MaterialTheme.typography.titleSmall, maxLines = 1)
                Spacer(Modifier.height(8.dp))
                AndroidView(
                    factory = { c -> PlayerView(c).apply { this.player = player; useController = true; controllerShowTimeoutMs = 0 } },
                    modifier = Modifier.fillMaxWidth().height(if (el.kind == MediaKind.VIDEO) 220.dp else 120.dp)
                )
                TextButton(onClick = onClose, modifier = Modifier.align(Alignment.End)) { Text("Close") }
            }
        }
    }
}

// ---------------------------------------------------------------------- layers

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LayersSheet(vm: EditorViewModel, ui: EditorUi, onDismiss: () -> Unit) {
    var rename by remember { mutableStateOf<String?>(null) }
    var newName by remember { mutableStateOf("") }
    var adding by remember { mutableStateOf(false) }
    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(Modifier.navigationBarsPadding().padding(horizontal = 16.dp).padding(bottom = 16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Layers", style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
                TextButton(onClick = { newName = "Layer ${ui.layers.size + 1}"; adding = true }) { Text("Add layer") }
            }
            Text("Top of the list is drawn in front. New drawing goes to the selected layer.", style = MaterialTheme.typography.bodySmall)
            Spacer(Modifier.height(8.dp))
            LazyColumn(Modifier.height((56 * ui.layers.size.coerceIn(1, 6)).dp + 8.dp)) {
                items(ui.layers.reversed(), key = { it.id }) { l ->
                    Row(Modifier.fillMaxWidth().height(56.dp), verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(selected = l.id == ui.activeLayerId, onClick = { vm.session.setActiveLayer(l.id) })
                        Text(
                            l.name, maxLines = 1, modifier = Modifier
                                .weight(1f)
                                .padding(end = 4.dp)
                                .pointerInput(l.id) { detectTapGesturesLong { newName = l.name; rename = l.id } }
                        )
                        IconButton(onClick = { vm.session.setLayerVisible(l.id, !l.visible) }) {
                            Icon(if (l.visible) Icons.Default.Visibility else Icons.Default.VisibilityOff, if (l.visible) "Hide layer" else "Show layer")
                        }
                        IconButton(onClick = { vm.session.setLayerLocked(l.id, !l.locked) }) {
                            Icon(if (l.locked) Icons.Default.Lock else Icons.Default.LockOpen, if (l.locked) "Unlock layer" else "Lock layer")
                        }
                        IconButton(onClick = { vm.session.moveLayer(l.id, 1) }) { Icon(Icons.Default.KeyboardArrowUp, "Move layer forward") }
                        IconButton(onClick = { vm.session.moveLayer(l.id, -1) }) { Icon(Icons.Default.KeyboardArrowDown, "Move layer back") }
                        IconButton(onClick = { vm.session.removeLayer(l.id) }, enabled = ui.layers.size > 1) { Icon(Icons.Default.Delete, "Delete layer") }
                    }
                }
            }
            Text("Long-press a layer name to rename it.", style = MaterialTheme.typography.bodySmall)
        }
    }
    if (adding || rename != null) {
        AlertDialog(
            onDismissRequest = { adding = false; rename = null },
            title = { Text(if (adding) "New layer" else "Rename layer") },
            text = { OutlinedTextField(newName, { newName = it }, singleLine = true) },
            confirmButton = {
                TextButton(onClick = {
                    val n = newName.trim().ifEmpty { "Layer" }
                    if (adding) vm.session.addLayer(n) else rename?.let { vm.session.renameLayer(it, n) }
                    adding = false; rename = null
                }) { Text("OK") }
            },
            dismissButton = { TextButton(onClick = { adding = false; rename = null }) { Text("Cancel") } }
        )
    }
}

private suspend fun androidx.compose.ui.input.pointer.PointerInputScope.detectTapGesturesLong(onLong: () -> Unit) {
    androidx.compose.foundation.gestures.detectTapGestures(onLongPress = { onLong() })
}
