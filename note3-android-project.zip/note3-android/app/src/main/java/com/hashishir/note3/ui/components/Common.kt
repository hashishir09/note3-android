package com.hashishir.note3.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.hashishir.note3.engine.model.PaperStyle

/** Minimum comfortable touch target. */
val TouchTarget = 48.dp

val SwatchColors: List<Int> = listOf(
    0xFF1A1A1A, 0xFFFFFFFF, 0xFFD32F2F, 0xFFF57C00, 0xFFFBC02D, 0xFF388E3C,
    0xFF00897B, 0xFF1976D2, 0xFF5E35B1, 0xFFC2185B, 0xFF6D4C41, 0xFF757575
).map { it.toInt() }

val PaperColors: List<Pair<String, Int>> = listOf(
    "White" to 0xFFFFFFFF.toInt(),
    "Cream" to 0xFFFFF8E1.toInt(),
    "Gray" to 0xFFECEFF1.toInt(),
    "Blackboard" to 0xFF1F2A27.toInt(),
    "Black" to 0xFF000000.toInt()
)

@Composable
fun SectionLabel(text: String, modifier: Modifier = Modifier) {
    Text(
        text,
        style = MaterialTheme.typography.labelLarge,
        fontWeight = FontWeight.SemiBold,
        color = MaterialTheme.colorScheme.primary,
        modifier = modifier.padding(top = 8.dp, bottom = 4.dp)
    )
}

/** Horizontally scrolling row so options never overflow on narrow phones. */
@Composable
fun ScrollRow(modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    Row(
        modifier = modifier.horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) { content() }
}

@Composable
fun <T> ChoiceChips(options: List<Pair<String, T>>, selected: T, onSelect: (T) -> Unit, modifier: Modifier = Modifier) {
    ScrollRow(modifier) {
        for ((label, value) in options) {
            FilterChip(
                selected = value == selected,
                onClick = { onSelect(value) },
                label = { Text(label) },
                modifier = Modifier.height(TouchTarget)
            )
        }
    }
}

@Composable
fun ColorSwatch(color: Int, selected: Boolean, onClick: () -> Unit, name: String = "Color") {
    val ring = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline
    Box(
        modifier = Modifier
            .size(TouchTarget)
            .semantics { contentDescription = if (selected) "$name, selected" else name }
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Box(
            Modifier
                .size(if (selected) 36.dp else 32.dp)
                .background(Color(color), CircleShape)
                .border(BorderStroke(if (selected) 3.dp else 1.dp, ring), CircleShape)
        )
    }
}

@Composable
fun ColorRow(selected: Int, onSelect: (Int) -> Unit, onCustom: () -> Unit) {
    ScrollRow {
        for (c in SwatchColors) ColorSwatch(c, selected == c, { onSelect(c) })
        val custom = selected !in SwatchColors
        Box(
            Modifier
                .size(TouchTarget)
                .clickable(onClick = onCustom),
            contentAlignment = Alignment.Center
        ) {
            Box(
                Modifier
                    .size(34.dp)
                    .background(if (custom) Color(selected) else MaterialTheme.colorScheme.surfaceVariant, CircleShape)
                    .border(BorderStroke(if (custom) 3.dp else 1.dp, MaterialTheme.colorScheme.outline), CircleShape),
                contentAlignment = Alignment.Center
            ) { if (!custom) Text("+", style = MaterialTheme.typography.titleMedium) }
        }
    }
}

@Composable
fun PaperPicker(style: PaperStyle, color: Int, onChange: (PaperStyle, Int) -> Unit) {
    SectionLabel("Paper")
    ChoiceChips(
        listOf("Blank" to PaperStyle.BLANK, "Grid" to PaperStyle.GRID, "Dots" to PaperStyle.DOTS, "Lines" to PaperStyle.LINES),
        style, { onChange(it, color) }
    )
    SectionLabel("Paper color")
    ScrollRow {
        for ((name, c) in PaperColors) ColorSwatch(c, c == color, { onChange(style, c) }, "$name paper")
    }
}

@Composable
fun ColorPickerDialog(initial: Int, onDismiss: () -> Unit, onPick: (Int) -> Unit) {
    var r by remember { mutableIntStateOf((initial shr 16) and 0xFF) }
    var g by remember { mutableIntStateOf((initial shr 8) and 0xFF) }
    var b by remember { mutableIntStateOf(initial and 0xFF) }
    val color = 0xFF000000.toInt() or (r shl 16) or (g shl 8) or b
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Custom color") },
        text = {
            Column {
                Box(
                    Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .background(Color(color), MaterialTheme.shapes.medium)
                        .border(1.dp, MaterialTheme.colorScheme.outline, MaterialTheme.shapes.medium)
                )
                Spacer(Modifier.height(8.dp))
                ChannelSlider("Red", r) { r = it }
                ChannelSlider("Green", g) { g = it }
                ChannelSlider("Blue", b) { b = it }
            }
        },
        confirmButton = { TextButton(onClick = { onPick(color) }) { Text("Use color") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
private fun ChannelSlider(label: String, value: Int, onChange: (Int) -> Unit) {
    var v by remember(value) { mutableFloatStateOf(value.toFloat()) }
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(label, modifier = Modifier.padding(end = 8.dp).width(56.dp))
        Slider(
            value = v,
            onValueChange = { v = it; onChange(it.toInt()) },
            valueRange = 0f..255f,
            modifier = Modifier.weight(1f)
        )
    }
}
