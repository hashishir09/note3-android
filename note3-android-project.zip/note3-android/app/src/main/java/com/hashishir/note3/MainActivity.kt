package com.hashishir.note3

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.getValue
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.lifecycle.viewmodel.compose.viewModel
import com.hashishir.note3.ui.editor.EditorScreen
import com.hashishir.note3.ui.home.HomeScreen
import com.hashishir.note3.ui.home.HomeViewModel
import com.hashishir.note3.ui.theme.Note3Theme

class MainActivity : ComponentActivity() {

    private var pendingImport by mutableStateOf<Uri?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        if (savedInstanceState == null) pendingImport = importUriFrom(intent)
        val container = (application as Note3App).container
        setContent {
            val settings by container.settings.flow.collectAsState()
            Note3Theme(settings.theme) {
                var openBoard by rememberSaveable { mutableStateOf<String?>(null) }
                val home: HomeViewModel = viewModel()
                val uri = pendingImport
                if (uri != null) {
                    // A .n3wb file was opened from a file manager: import it as a new board.
                    androidx.compose.runtime.LaunchedEffect(uri) {
                        home.import(uri)
                        pendingImport = null
                    }
                }
                val id = openBoard
                if (id == null) {
                    HomeScreen(home) { openBoard = it }
                } else {
                    EditorScreen(id) { openBoard = null }
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        importUriFrom(intent)?.let { pendingImport = it }
    }

    private fun importUriFrom(intent: Intent?): Uri? =
        if (intent?.action == Intent.ACTION_VIEW) intent.data else null
}
