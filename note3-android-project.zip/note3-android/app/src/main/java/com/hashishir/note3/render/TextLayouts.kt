package com.hashishir.note3.render

import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.util.LruCache
import kotlin.math.ceil

/** Builds and caches [StaticLayout]s for text boxes (text is laid out in world units). */
object TextLayouts {

    private val cache = LruCache<String, StaticLayout>(48)

    fun layout(text: String, fontSize: Float, color: Int, width: Float): StaticLayout {
        val w = width.toInt().coerceAtLeast(8)
        val key = "$w|$fontSize|$color|${text.hashCode()}|${text.length}"
        cache.get(key)?.let { return it }
        val paint = TextPaint(TextPaint.ANTI_ALIAS_FLAG).apply {
            this.color = color
            textSize = fontSize
        }
        val l = StaticLayout.Builder.obtain(text, 0, text.length, paint, w)
            .setAlignment(Layout.Alignment.ALIGN_NORMAL)
            .setIncludePad(false)
            .build()
        cache.put(key, l)
        return l
    }

    /** Height needed to show [text] at [fontSize] inside a box [width] wide. */
    fun measureHeight(text: String, fontSize: Float, width: Float): Float =
        ceil(layout(text, fontSize, 0xFF000000.toInt(), width).height.toFloat()).coerceAtLeast(fontSize * 1.3f)

    /** Width of the longest line, used to size a new text box to its content. */
    fun measureWidth(text: String, fontSize: Float, maxWidth: Float): Float {
        val paint = TextPaint(TextPaint.ANTI_ALIAS_FLAG).apply { textSize = fontSize }
        var widest = 0f
        for (line in text.split('\n')) widest = maxOf(widest, paint.measureText(line))
        return ceil(widest).coerceIn(fontSize * 2f, maxWidth)
    }
}
