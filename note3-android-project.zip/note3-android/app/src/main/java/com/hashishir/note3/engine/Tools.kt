package com.hashishir.note3.engine

import com.hashishir.note3.engine.math.Geo
import com.hashishir.note3.engine.math.Vec
import com.hashishir.note3.engine.model.ShapeKind
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.sin

enum class Tool { PEN, BRUSH, HIGHLIGHTER, ERASER_STROKE, ERASER_PARTIAL, SELECT, SHAPE, TEXT, HAND }

/** When freehand strokes are converted to clean shapes. */
enum class RecognizeMode { OFF, HOLD, ALWAYS }

data class ToolSettings(
    val tool: Tool = Tool.PEN,
    val color: Int = 0xFF1A1A1A.toInt(),
    val penWidth: Float = 3f,
    val brushWidth: Float = 10f,
    val highlighterWidth: Float = 22f,
    val highlighterAlpha: Int = 0x66,
    val shapeKind: ShapeKind = ShapeKind.LINE,
    val fillShapes: Boolean = false,
    val snapToGrid: Boolean = false,
    val gridSize: Float = 40f,
    val recognize: RecognizeMode = RecognizeMode.HOLD,
    /** When false only a stylus draws; fingers pan and zoom (palm rejection for handwriting). */
    val fingerDraws: Boolean = true,
    val eraserRadiusPx: Float = 18f,
    val textSize: Float = 32f
) {
    val width: Float
        get() = when (tool) {
            Tool.BRUSH -> brushWidth
            Tool.HIGHLIGHTER -> highlighterWidth
            else -> penWidth
        }

    fun withWidth(w: Float): ToolSettings = when (tool) {
        Tool.BRUSH -> copy(brushWidth = w)
        Tool.HIGHLIGHTER -> copy(highlighterWidth = w)
        else -> copy(penWidth = w)
    }

    /** Ink color with the highlighter's transparency applied when relevant. */
    val inkColor: Int
        get() = if (tool == Tool.HIGHLIGHTER) (color and 0x00FFFFFF) or (highlighterAlpha shl 24) else color
}

enum class GeoKind { RULER, SET_SQUARE, PROTRACTOR }

/**
 * A geometry drawing aid placed on the canvas. [size] is the main dimension in world units:
 * ruler length, set-square leg length, protractor diameter. Strokes drawn along an edge snap to it.
 */
data class GeoTool(val kind: GeoKind, val cx: Float, val cy: Float, val angle: Float, val size: Float) {

    private fun local(lx: Float, ly: Float): Vec {
        val c = cos(angle)
        val s = sin(angle)
        return Vec(cx + c * lx - s * ly, cy + s * lx + c * ly)
    }

    val thickness: Float get() = size * 0.12f

    /** Unit-size position of the resize/rotate handle in local coordinates. */
    private val handleUnit: Vec
        get() = when (kind) {
            GeoKind.SET_SQUARE -> Vec(0.5f, -0.5f)
            else -> Vec(0.5f, 0f)
        }

    fun polygon(): List<Vec> = when (kind) {
        GeoKind.RULER -> {
            val hw = size / 2f
            val hh = thickness / 2f
            listOf(local(-hw, -hh), local(hw, -hh), local(hw, hh), local(-hw, hh))
        }
        GeoKind.SET_SQUARE -> {
            val h = size / 2f
            listOf(local(-h, -h), local(h, -h), local(-h, h))
        }
        GeoKind.PROTRACTOR -> {
            val r = size / 2f
            val out = ArrayList<Vec>(34)
            for (i in 0..32) {
                val t = Math.PI.toFloat() * i / 32f
                out.add(local(r * cos(t), -r * sin(t)))
            }
            out
        }
    }

    /** Straight edges that drawn strokes can snap to. */
    fun edges(): List<Pair<Vec, Vec>> {
        val p = polygon()
        return when (kind) {
            GeoKind.RULER -> listOf(p[0] to p[1], p[3] to p[2])
            GeoKind.SET_SQUARE -> listOf(p[0] to p[1], p[0] to p[2], p[1] to p[2])
            GeoKind.PROTRACTOR -> listOf(p.last() to p.first())
        }
    }

    fun handle(): Vec = local(handleUnit.x * size, handleUnit.y * size)

    fun center(): Vec = Vec(cx, cy)

    fun contains(x: Float, y: Float): Boolean = Geo.pointInPolygon(x, y, polygon())

    fun distanceToNearestEdge(x: Float, y: Float): Float {
        var best = Float.MAX_VALUE
        for ((a, b) in edges()) best = minOf(best, Geo.distPointSegment(x, y, a.x, a.y, b.x, b.y))
        return best
    }

    fun moved(dx: Float, dy: Float): GeoTool = copy(cx = cx + dx, cy = cy + dy)

    /** Dragging the handle rotates the tool about its centre and resizes it. */
    fun withHandleAt(x: Float, y: Float): GeoTool {
        val dx = x - cx
        val dy = y - cy
        val dist = hypot(dx, dy)
        if (dist < 4f) return this
        val hu = handleUnit
        val newAngle = atan2(dy, dx) - atan2(hu.y, hu.x)
        val newSize = (dist / hypot(hu.x, hu.y)).coerceIn(MIN_SIZE, MAX_SIZE)
        return copy(angle = newAngle, size = newSize)
    }

    companion object {
        const val MIN_SIZE = 120f
        const val MAX_SIZE = 6000f

        fun create(kind: GeoKind, centerX: Float, centerY: Float, referenceSize: Float): GeoTool =
            GeoTool(kind, centerX, centerY, 0f, (referenceSize * 0.7f).coerceIn(MIN_SIZE, MAX_SIZE))

        /** Closest point on a segment, clamped to its end points. */
        fun projectOnSegment(x: Float, y: Float, a: Vec, b: Vec): Vec {
            val dx = b.x - a.x
            val dy = b.y - a.y
            val len2 = dx * dx + dy * dy
            if (len2 < 1e-9f) return a
            val t = (((x - a.x) * dx + (y - a.y) * dy) / len2).coerceIn(0f, 1f)
            return Vec(a.x + t * dx, a.y + t * dy)
        }
    }
}
