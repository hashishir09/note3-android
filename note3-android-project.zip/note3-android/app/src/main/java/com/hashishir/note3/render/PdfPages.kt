package com.hashishir.note3.render

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import java.io.File
import java.io.IOException

data class PdfPageInfo(val widthPt: Int, val heightPt: Int)

/**
 * Thin wrapper over the platform [PdfRenderer] (free, built into Android 5+). The platform renderer
 * allows only one open page per document, so every call is synchronized. Documents are kept open
 * until [close], which the owner must call when the editor is destroyed.
 */
class PdfPages {

    private class Doc(val pfd: ParcelFileDescriptor, val renderer: PdfRenderer)

    private val docs = HashMap<String, Doc>()
    private val lock = Any()

    private fun open(file: File): Doc? {
        docs[file.path]?.let { return it }
        return try {
            val pfd = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
            val doc = Doc(pfd, PdfRenderer(pfd))
            docs[file.path] = doc
            doc
        } catch (_: Exception) {
            null
        }
    }

    /** Page sizes in PDF points, or throws if the file is not a readable PDF (e.g. password protected). */
    @Throws(IOException::class)
    fun inspect(file: File): List<PdfPageInfo> = synchronized(lock) {
        val doc = open(file) ?: throw IOException("This PDF cannot be opened (it may be damaged or password protected).")
        val out = ArrayList<PdfPageInfo>(doc.renderer.pageCount)
        for (i in 0 until doc.renderer.pageCount) {
            val p = doc.renderer.openPage(i)
            try {
                out.add(PdfPageInfo(p.width, p.height))
            } finally {
                p.close()
            }
        }
        out
    }

    /** Renders one page to a white-backed bitmap [widthPx] wide, or null on failure. */
    fun render(file: File, pageIndex: Int, widthPx: Int): Bitmap? = synchronized(lock) {
        val doc = open(file) ?: return null
        if (pageIndex !in 0 until doc.renderer.pageCount) return null
        val page = doc.renderer.openPage(pageIndex)
        try {
            val w = widthPx.coerceIn(64, 4096)
            val h = (w.toLong() * page.height / page.width).toInt().coerceAtLeast(1)
            val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            bmp.eraseColor(Color.WHITE)
            page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
            bmp
        } catch (_: Throwable) {
            null
        } finally {
            page.close()
        }
    }

    fun release(file: File) = synchronized(lock) {
        docs.remove(file.path)?.let {
            runCatching { it.renderer.close() }
            runCatching { it.pfd.close() }
        }
        Unit
    }

    fun close() = synchronized(lock) {
        for (d in docs.values) {
            runCatching { d.renderer.close() }
            runCatching { d.pfd.close() }
        }
        docs.clear()
    }
}
