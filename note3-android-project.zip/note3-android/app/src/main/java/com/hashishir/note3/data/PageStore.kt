package com.hashishir.note3.data

import com.hashishir.note3.engine.model.Page
import java.io.File
import java.io.FileOutputStream
import java.io.IOException

/**
 * Stores each page as one JSON file. Writes are crash-safe: the new content is written and synced to a
 * temporary file, the previous version is kept as `.bak`, and only then is the new file moved into place.
 * [load] falls back to the backup if the main file is missing or unreadable.
 */
class PageStore(private val dir: File) {

    init {
        dir.mkdirs()
    }

    private val safeId = Regex("^[A-Za-z0-9\\-]{1,64}$")

    private fun file(id: String) = File(dir, "$id.json")
    private fun backup(id: String) = File(dir, "$id.json.bak")

    fun load(id: String): Page? {
        if (!safeId.matches(id)) return null
        for (f in listOf(file(id), backup(id))) {
            if (!f.isFile) continue
            try {
                return AppJson.decodeFromString(Page.serializer(), f.readText(Charsets.UTF_8))
            } catch (_: Exception) {
                // try the backup next
            }
        }
        return null
    }

    @Throws(IOException::class)
    fun save(page: Page) {
        if (!safeId.matches(page.id)) throw IOException("Invalid page id")
        val text = AppJson.encodeToString(Page.serializer(), page)
        val tmp = File(dir, "${page.id}.json.tmp")
        FileOutputStream(tmp).use { os ->
            os.write(text.toByteArray(Charsets.UTF_8))
            os.flush()
            os.fd.sync()
        }
        val target = file(page.id)
        if (target.exists()) {
            val bak = backup(page.id)
            bak.delete()
            target.renameTo(bak)
        }
        if (!tmp.renameTo(target)) {
            tmp.delete()
            throw IOException("Could not write page ${page.id}")
        }
    }

    fun delete(id: String) {
        if (!safeId.matches(id)) return
        file(id).delete()
        backup(id).delete()
        File(dir, "$id.json.tmp").delete()
    }
}
