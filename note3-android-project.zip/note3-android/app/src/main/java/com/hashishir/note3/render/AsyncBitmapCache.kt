package com.hashishir.note3.render

import android.graphics.Bitmap
import android.os.Handler
import android.os.Looper
import android.util.LruCache
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors

/**
 * Bitmap cache whose loads run on a background thread so drawing never blocks on disk or decoding.
 * [get] returns the cached bitmap or null and schedules the load; [onReady] runs on the main thread
 * after a load finishes so the view can redraw. Evicted bitmaps are not recycled (they may still be
 * on screen for one more frame); the garbage collector reclaims them.
 */
class AsyncBitmapCache(maxBytes: Int, private val onReady: () -> Unit) {

    private val cache = object : LruCache<String, Bitmap>(maxBytes.coerceAtLeast(1 shl 20)) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }
    private val pending = ConcurrentHashMap.newKeySet<String>()
    private val failed = ConcurrentHashMap.newKeySet<String>()
    private val executor = Executors.newSingleThreadExecutor { r -> Thread(r, "bitmap-loader").apply { priority = Thread.MIN_PRIORITY } }
    private val main = Handler(Looper.getMainLooper())

    @Volatile
    private var closed = false

    fun peek(key: String): Bitmap? = cache.get(key)

    fun get(key: String, loader: () -> Bitmap?): Bitmap? {
        cache.get(key)?.let { return it }
        if (closed || key in failed) return null
        if (pending.add(key)) {
            executor.execute {
                val bmp = try {
                    loader()
                } catch (_: Throwable) { // includes OutOfMemoryError: show nothing rather than crash
                    null
                }
                if (bmp != null) cache.put(key, bmp) else failed.add(key)
                pending.remove(key)
                if (!closed) main.post(onReady)
            }
        }
        return null
    }

    /** Loads on the calling thread (used by exporters). The result is not cached. */
    fun getBlocking(loader: () -> Bitmap?): Bitmap? = try {
        loader()
    } catch (_: Throwable) {
        null
    }

    fun forget(prefix: String) {
        failed.removeAll { it.startsWith(prefix) }
        for (k in cache.snapshot().keys) if (k.startsWith(prefix)) cache.remove(k)
    }

    fun clear() {
        cache.evictAll()
        failed.clear()
    }

    fun close() {
        closed = true
        executor.shutdownNow()
        cache.evictAll()
    }
}
