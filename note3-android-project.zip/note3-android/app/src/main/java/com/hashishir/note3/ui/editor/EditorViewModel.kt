package com.hashishir.note3.ui.editor

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.hashishir.note3.Note3App
import com.hashishir.note3.editor.DrawingSession
import com.hashishir.note3.editor.SessionEvent
import com.hashishir.note3.editor.SessionListener
import com.hashishir.note3.engine.GeoKind
import com.hashishir.note3.engine.History
import com.hashishir.note3.engine.PageContent
import com.hashishir.note3.engine.RecognizeMode
import com.hashishir.note3.engine.Tool
import com.hashishir.note3.engine.ToolSettings
import com.hashishir.note3.engine.math.Rect
import com.hashishir.note3.engine.model.IdGen
import com.hashishir.note3.engine.model.ImageElement
import com.hashishir.note3.engine.model.Layer
import com.hashishir.note3.engine.model.MediaElement
import com.hashishir.note3.engine.model.MediaKind
import com.hashishir.note3.engine.model.Page
import com.hashishir.note3.engine.model.PaperStyle
import com.hashishir.note3.engine.model.PdfRef
import com.hashishir.note3.engine.model.TextElement
import com.hashishir.note3.export.Exporter
import com.hashishir.note3.export.ImageFormat
import com.hashishir.note3.render.PageRenderer
import com.hashishir.note3.render.TextLayouts
import com.hashishir.note3.ui.canvas.PageMeta
import com.hashishir.note3.ui.canvas.WhiteboardView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.lang.ref.WeakReference
import kotlin.math.min

data class EditorUi(
    val loaded: Boolean = false,
    val title: String = "",
    val pageIndex: Int = 0,
    val pageCount: Int = 1,
    val canUndo: Boolean = false,
    val canRedo: Boolean = false,
    val selectionCount: Int = 0,
    val selectionGrouped: Boolean = false,
    val canPaste: Boolean = false,
    val layers: List<Layer> = emptyList(),
    val activeLayerId: String = "",
    val polygonPoints: Int = 0,
    val settings: ToolSettings = ToolSettings(),
    val paper: PaperStyle = PaperStyle.BLANK,
    val paperColor: Int = 0xFFFFFFFF.toInt(),
    val isPdfPage: Boolean = false,
    val geometry: Set<GeoKind> = emptySet(),
    val busy: String? = null
)

data class TextEditState(
    val elementId: String?,
    val x: Float,
    val y: Float,
    val text: String,
    val fontSize: Float,
    val color: Int,
    val width: Float
)

class EditorViewModel(app: Application, private val boardId: String) : AndroidViewModel(app) {

    private val container = (app as Note3App).container
    private val repo = container.repository
    private val media = container.media

    val session = DrawingSession(History(PageContent(Page.blank().layers, emptyList())))
    val renderer = PageRenderer(container.renderResources)

    private val _ui = MutableStateFlow(EditorUi())
    val ui: StateFlow<EditorUi> = _ui

    private val _messages = MutableSharedFlow<String>(extraBufferCapacity = 16)
    val messages: SharedFlow<String> = _messages

    private val _textEdit = MutableStateFlow<TextEditState?>(null)
    val textEdit: StateFlow<TextEditState?> = _textEdit

    private val _playing = MutableStateFlow<MediaElement?>(null)
    val playing: StateFlow<MediaElement?> = _playing

    private var pageIds: List<String> = emptyList()
    private var pageIndex = 0
    private var meta = PageMeta(PaperStyle.BLANK, 0xFFFFFFFF.toInt(), null)
    private var currentPageId: String = ""
    private var title = ""
    private var view: WeakReference<WhiteboardView>? = null
    private var saveJob: Job? = null
    private var pendingViewport = false
    private var busyDepth = 0
    private val viewports = HashMap<String, FloatArray>()
    private val density = app.resources.displayMetrics.density

    private val listener = object : SessionListener {
        override fun onInvalidate() {
            view?.get()?.postInvalidateOnAnimation()
        }

        override fun onContentChanged() {
            refreshUi()
            scheduleSave()
        }

        override fun onSelectionChanged() = refreshUi()

        override fun onSettingsChanged() {
            container.settings.saveTool(session.settings)
            refreshUi()
        }

        override fun onEvent(event: SessionEvent) {
            when (event) {
                is SessionEvent.Message -> _messages.tryEmit(event.text)
                is SessionEvent.EditText -> openTextEditor(event.elementId, event.x, event.y)
                is SessionEvent.PlayMedia -> (session.elementById(event.elementId) as? MediaElement)?.let { _playing.value = it }
            }
        }
    }

    init {
        session.density = density
        session.listener = listener
        session.updateSettings(container.settings.loadTool())
        viewModelScope.launch {
            container.settings.flow.collect { a ->
                val s = session.settings
                if (s.fingerDraws != a.fingerDraws || s.recognize != a.recognize || s.eraserRadiusPx != a.eraserRadiusDp) {
                    session.updateSettings(s.copy(fingerDraws = a.fingerDraws, recognize = a.recognize, eraserRadiusPx = a.eraserRadiusDp))
                }
            }
        }
        viewModelScope.launch { load() }
    }

    // ------------------------------------------------------------------ view binding

    fun attachView(v: WhiteboardView) {
        view = WeakReference(v)
        v.bind(session, renderer)
        v.pageMeta = meta
        v.onViewportChanged = { rememberViewport() }
        v.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> applyPendingViewport() }
        applyPendingViewport()
    }

    fun detachView(v: WhiteboardView) {
        if (view?.get() === v) view = null
        v.onViewportChanged = null
    }

    /** Called when a background image/PDF page finished loading. */
    fun onBitmapReady() {
        view?.get()?.refresh()
    }

    private fun rememberViewport() {
        if (currentPageId.isEmpty()) return
        val v = session.viewport
        viewports[currentPageId] = floatArrayOf(v.scale, v.tx, v.ty)
    }

    private fun applyPendingViewport() {
        if (!pendingViewport) return
        val v = view?.get() ?: return
        if (v.width <= 0 || v.height <= 0) return
        pendingViewport = false
        val saved = viewports[currentPageId]
        val pdf = meta.pdf
        when {
            saved != null -> {
                session.viewport.scale = saved[0]; session.viewport.tx = saved[1]; session.viewport.ty = saved[2]
                v.refresh()
            }
            pdf != null -> v.fitTo(Rect(0f, 0f, pdf.width, pdf.height))
            session.content.elements.isNotEmpty() -> {
                var b: Rect? = null
                for (e in session.content.elements) b = if (b == null) e.bounds() else b.union(e.bounds())
                v.fitTo(b!!.inflate(60f))
                if (session.viewport.scale > density) {
                    // do not zoom in past 100% just because the content is small
                    session.viewport.scale = density
                    session.viewport.tx = v.width / 2f - b.centerX * density
                    session.viewport.ty = v.height / 2f - b.centerY * density
                    v.refresh()
                }
            }
            else -> v.resetViewport()
        }
    }

    fun fitContent() {
        val v = view?.get() ?: return
        val pdf = meta.pdf
        if (pdf != null) {
            v.fitTo(Rect(0f, 0f, pdf.width, pdf.height))
            return
        }
        var b: Rect? = null
        for (e in session.content.elements) b = if (b == null) e.bounds() else b.union(e.bounds())
        if (b == null) v.resetViewport() else v.fitTo(b.inflate(60f))
    }

    fun zoom(factor: Float) {
        view?.get()?.zoomBy(factor)
    }

    // ------------------------------------------------------------------ loading / saving

    private suspend fun load() {
        title = repo.boardTitle(boardId) ?: ""
        pageIds = repo.pageIds(boardId)
        if (pageIds.isEmpty()) {
            // A board always has a page; recover from an inconsistent database.
            val p = Page.blank(container.settings.flow.value.defaultPaperColor)
            repo.addPage(boardId, p, 0)
            pageIds = listOf(p.id)
        }
        loadPageAt(0)
    }

    private suspend fun loadPageAt(index: Int) {
        val i = index.coerceIn(0, pageIds.size - 1)
        val id = pageIds[i]
        val loaded = withContext(container.saveDispatcher) { repo.loadPage(id) }
        val page = loaded ?: Page(id = id).also { _messages.tryEmit("This page could not be read and was replaced by a blank page.") }
        pageIndex = i
        currentPageId = page.id
        meta = PageMeta(page.paper, page.paperColor, page.pdf)
        session.attach(History(PageContent(page.layers, page.elements)))
        view?.get()?.pageMeta = meta
        pendingViewport = true
        _ui.value = _ui.value.copy(loaded = true)
        refreshUi()
        applyPendingViewport()
    }

    private fun snapshot(): Page = Page(
        id = currentPageId,
        paper = meta.paper,
        paperColor = meta.paperColor,
        pdf = meta.pdf,
        layers = session.content.layers,
        elements = session.content.elements
    )

    private fun scheduleSave() {
        saveJob?.cancel()
        saveJob = viewModelScope.launch {
            delay(AUTOSAVE_DELAY_MS)
            flush()
        }
    }

    /** Writes the current page now. Safe to call from lifecycle callbacks. */
    fun flush() {
        saveJob?.cancel()
        if (!_ui.value.loaded || currentPageId.isEmpty()) return
        val snap = snapshot()
        container.appScope.launch(container.saveDispatcher) {
            try {
                repo.savePage(boardId, snap)
            } catch (e: Exception) {
                _messages.tryEmit("Could not save: ${e.message ?: "storage error"}")
            }
        }
    }

    override fun onCleared() {
        flush()
        super.onCleared()
    }

    private fun refreshUi() {
        val c = session.content
        _ui.value = _ui.value.copy(
            title = title,
            pageIndex = pageIndex,
            pageCount = pageIds.size,
            canUndo = session.canUndo,
            canRedo = session.canRedo,
            selectionCount = session.selection.size,
            selectionGrouped = session.selectionIsGrouped,
            canPaste = session.clipboard.isNotEmpty(),
            layers = c.layers,
            activeLayerId = session.activeLayerId,
            polygonPoints = session.polygonDraft.size,
            settings = session.settings,
            paper = meta.paper,
            paperColor = meta.paperColor,
            isPdfPage = meta.pdf != null,
            geometry = session.geometry.map { it.kind }.toSet()
        )
    }

    private suspend fun <T> busy(label: String, block: suspend () -> T): T {
        busyDepth++
        _ui.value = _ui.value.copy(busy = label)
        try {
            return block()
        } finally {
            busyDepth--
            if (busyDepth == 0) _ui.value = _ui.value.copy(busy = null)
        }
    }

    // ------------------------------------------------------------------ tools

    fun updateTool(f: (ToolSettings) -> ToolSettings) = session.updateSettings(f(session.settings))

    val appSettings: StateFlow<com.hashishir.note3.data.AppSettings> get() = container.settings.flow
    val renderTick: StateFlow<Int> get() = container.renderTick

    fun updateAppSettings(f: (com.hashishir.note3.data.AppSettings) -> com.hashishir.note3.data.AppSettings) =
        container.settings.update(f)

    fun mediaFile(name: String): java.io.File = media.file(name)

    fun toggleGeometry(kind: GeoKind) {
        if (session.geometry.any { it.kind == kind }) session.removeGeometry(kind) else session.addGeometry(kind)
        refreshUi()
    }

    fun undo() = session.undo()
    fun redo() = session.redo()

    // ------------------------------------------------------------------ text

    private fun openTextEditor(elementId: String?, x: Float, y: Float) {
        val el = elementId?.let { session.elementById(it) as? TextElement }
        val s = session.settings
        _textEdit.value = TextEditState(
            elementId = el?.id, x = el?.ox ?: x, y = el?.oy ?: y,
            text = el?.text ?: "", fontSize = el?.fontSize ?: s.textSize,
            color = el?.color ?: s.color, width = el?.w ?: 0f
        )
    }

    fun addTextBoxAtCenter() {
        val c = session.viewCenterWorld()
        openTextEditor(null, c.x - 120f, c.y - 20f)
    }

    fun commitText(state: TextEditState, text: String, fontSize: Float, color: Int) {
        _textEdit.value = null
        session.updateSettings(session.settings.copy(textSize = fontSize))
        val id = state.elementId
        val w = if (state.width > 0f) state.width else TextLayouts.measureWidth(text, fontSize, MAX_TEXT_W) + 8f
        val h = TextLayouts.measureHeight(text, fontSize, w)
        if (id == null) {
            if (session.addText(text, state.x, state.y, w, h, fontSize, color) != null) {
                session.updateSettings(session.settings.copy(tool = Tool.SELECT))
            }
        } else {
            session.updateText(id, text, w, h, fontSize, color)
        }
    }

    fun cancelText() {
        _textEdit.value = null
    }

    fun deleteText(state: TextEditState) {
        _textEdit.value = null
        state.elementId?.let { session.updateText(it, "", 1f, 1f, state.fontSize, state.color) }
    }

    fun stopPlaying() {
        _playing.value = null
    }

    // ------------------------------------------------------------------ paper

    fun setPaper(style: PaperStyle, color: Int) {
        if (meta.pdf != null) {
            _messages.tryEmit("PDF pages keep their own background.")
            return
        }
        meta = meta.copy(paper = style, paperColor = color)
        view?.get()?.pageMeta = meta
        refreshUi()
        scheduleSave()
    }

    // ------------------------------------------------------------------ pages

    fun goToPage(i: Int) {
        if (i == pageIndex || i !in pageIds.indices) return
        viewModelScope.launch {
            flush()
            loadPageAt(i)
        }
    }

    fun addPage() {
        viewModelScope.launch {
            flush()
            val paper = if (meta.pdf == null) meta.paper else PaperStyle.BLANK
            val color = if (meta.pdf == null) meta.paperColor else container.settings.flow.value.defaultPaperColor
            val p = Page(id = IdGen.next(), paper = paper, paperColor = color)
            val at = pageIndex + 1
            repo.addPage(boardId, p, at)
            pageIds = repo.pageIds(boardId)
            loadPageAt(at)
        }
    }

    fun duplicatePage() {
        viewModelScope.launch {
            flush()
            container.awaitSaves()
            val newId = repo.duplicatePage(boardId, currentPageId)
            pageIds = repo.pageIds(boardId)
            val idx = pageIds.indexOf(newId)
            if (idx >= 0) loadPageAt(idx) else refreshUi()
        }
    }

    fun deletePage() {
        if (pageIds.size <= 1) {
            _messages.tryEmit("A board needs at least one page.")
            return
        }
        viewModelScope.launch {
            saveJob?.cancel()
            val removed = currentPageId
            val oldIndex = pageIndex
            repo.deletePage(boardId, removed)
            viewports.remove(removed)
            pageIds = repo.pageIds(boardId)
            loadPageAt(min(oldIndex, pageIds.size - 1))
        }
    }

    fun movePage(delta: Int) {
        viewModelScope.launch {
            flush()
            container.awaitSaves()
            repo.movePage(boardId, currentPageId, delta)
            pageIds = repo.pageIds(boardId)
            pageIndex = pageIds.indexOf(currentPageId).coerceAtLeast(0)
            refreshUi()
        }
    }

    // ------------------------------------------------------------------ media

    private fun placement(w: Float, h: Float, maxFraction: Float = 0.6f): FloatArray {
        val v = session.viewport
        val visW = session.viewW / v.scale
        val visH = session.viewH / v.scale
        val k = min(1f, min(visW * maxFraction / w, visH * maxFraction / h))
        val nw = w * k
        val nh = h * k
        val c = session.viewCenterWorld()
        return floatArrayOf(c.x - nw / 2f, c.y - nh / 2f, nw, nh)
    }

    fun importImage(uri: Uri) {
        viewModelScope.launch {
            try {
                val img = busy("Importing image…") { withContext(Dispatchers.IO) { media.importImage(uri) } }
                val p = placement(img.width.toFloat(), img.height.toFloat())
                val e = ImageElement(IdGen.next(), session.activeLayerId, null, p[0], p[1], p[2], p[3], 0f, img.name)
                if (!session.addElement(e)) {
                    withContext(Dispatchers.IO) { media.file(img.name).delete() }
                }
            } catch (e: Exception) {
                _messages.tryEmit("Could not import the image: ${e.message ?: "unknown error"}")
            }
        }
    }

    fun importMedia(uri: Uri, kind: MediaKind) {
        viewModelScope.launch {
            try {
                val f = busy("Importing ${if (kind == MediaKind.AUDIO) "audio" else "video"}…") {
                    withContext(Dispatchers.IO) { media.importRaw(uri, if (kind == MediaKind.AUDIO) "m4a" else "mp4") }
                }
                val (w, h) = if (kind == MediaKind.AUDIO) 360f to 120f else 480f to 270f
                val p = placement(w, h, 0.7f)
                val e = MediaElement(IdGen.next(), session.activeLayerId, null, p[0], p[1], p[2], p[3], 0f, kind, f.name, f.displayName)
                if (!session.addElement(e)) withContext(Dispatchers.IO) { media.file(f.name).delete() }
            } catch (e: Exception) {
                _messages.tryEmit("Could not import the file: ${e.message ?: "unknown error"}")
            }
        }
    }

    fun importPdf(uri: Uri) {
        viewModelScope.launch {
            try {
                flush()
                val firstIndex = busy("Importing PDF…") {
                    val (name, infos) = withContext(Dispatchers.IO) {
                        val f = media.importRaw(uri, "pdf")
                        val file = media.file(f.name)
                        try {
                            f.name to container.pdfPages.inspect(file)
                        } catch (e: Exception) {
                            container.pdfPages.release(file)
                            file.delete()
                            throw e
                        }
                    }
                    if (infos.isEmpty()) throw IllegalStateException("The PDF has no pages.")
                    val use = infos.take(MAX_PDF_PAGES)
                    var at = pageIndex + 1
                    val first = at
                    use.forEachIndexed { i, inf ->
                        val page = Page(
                            id = IdGen.next(),
                            pdf = PdfRef(name, i, inf.widthPt.toFloat(), inf.heightPt.toFloat())
                        )
                        repo.addPage(boardId, page, at++)
                    }
                    if (infos.size > use.size) _messages.tryEmit("Only the first $MAX_PDF_PAGES pages were imported.")
                    first
                }
                pageIds = repo.pageIds(boardId)
                loadPageAt(firstIndex)
                session.updateSettings(session.settings.copy(tool = Tool.PEN))
            } catch (e: Exception) {
                _messages.tryEmit("Could not import the PDF: ${e.message ?: "unknown error"}")
            }
        }
    }

    // ------------------------------------------------------------------ export

    fun exportImage(uri: Uri, format: ImageFormat) {
        flush()
        viewModelScope.launch {
            try {
                busy("Exporting ${format.ext.uppercase()}…") {
                    container.awaitSaves()
                    withContext(Dispatchers.IO) {
                        val page = repo.loadPage(currentPageId) ?: throw IllegalStateException("Page not found")
                        val out = getApplication<Application>().contentResolver.openOutputStream(uri, "w")
                            ?: throw IllegalStateException("Cannot write to the chosen location")
                        out.use { Exporter(container.renderResources).writeImage(page, format, it) }
                    }
                }
                _messages.tryEmit("${format.ext.uppercase()} exported.")
            } catch (e: Exception) {
                _messages.tryEmit("Export failed: ${e.message ?: "unknown error"}")
            }
        }
    }

    fun exportPdf(uri: Uri, allPages: Boolean) {
        flush()
        viewModelScope.launch {
            try {
                busy("Exporting PDF…") {
                    container.awaitSaves()
                    withContext(Dispatchers.IO) {
                        val ids = if (allPages) repo.pageIds(boardId) else listOf(currentPageId)
                        val pages = ids.mapNotNull { repo.loadPage(it) }
                        val out = getApplication<Application>().contentResolver.openOutputStream(uri, "w")
                            ?: throw IllegalStateException("Cannot write to the chosen location")
                        out.use { Exporter(container.renderResources).writePdf(pages, it) }
                    }
                }
                _messages.tryEmit("PDF exported.")
            } catch (e: Exception) {
                _messages.tryEmit("Export failed: ${e.message ?: "unknown error"}")
            }
        }
    }

    fun exportProject(uri: Uri) {
        flush()
        viewModelScope.launch {
            try {
                val missing = busy("Saving project file…") {
                    container.awaitSaves()
                    withContext(Dispatchers.IO) {
                        val out = getApplication<Application>().contentResolver.openOutputStream(uri, "w")
                            ?: throw IllegalStateException("Cannot write to the chosen location")
                        out.use { repo.exportArchive(listOf(boardId), it) }
                    }
                }
                _messages.tryEmit(if (missing > 0) "Project saved ($missing media file(s) were missing)." else "Project file saved.")
            } catch (e: Exception) {
                _messages.tryEmit("Could not save the project: ${e.message ?: "unknown error"}")
            }
        }
    }

    // ------------------------------------------------------------------ misc

    fun renameBoard(newTitle: String) {
        viewModelScope.launch {
            repo.renameBoard(boardId, newTitle)
            title = newTitle.ifBlank { "Untitled" }
            refreshUi()
        }
    }

    class Factory(private val app: Application, private val boardId: String) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T = EditorViewModel(app, boardId) as T
    }

    companion object {
        const val AUTOSAVE_DELAY_MS = 700L
        const val MAX_TEXT_W = 640f
        const val MAX_PDF_PAGES = 300
    }
}
