package com.hashishir.note3.editor

import com.hashishir.note3.engine.Eraser
import com.hashishir.note3.engine.EditOps
import com.hashishir.note3.engine.GeoKind
import com.hashishir.note3.engine.GeoTool
import com.hashishir.note3.engine.History
import com.hashishir.note3.engine.LayerOps
import com.hashishir.note3.engine.PageContent
import com.hashishir.note3.engine.RecognizeMode
import com.hashishir.note3.engine.ShapeRecognizer
import com.hashishir.note3.engine.StrokeProcessor
import com.hashishir.note3.engine.Tool
import com.hashishir.note3.engine.ToolSettings
import com.hashishir.note3.engine.Viewport
import com.hashishir.note3.engine.math.Affine
import com.hashishir.note3.engine.math.Geo
import com.hashishir.note3.engine.math.Rect
import com.hashishir.note3.engine.math.Vec
import com.hashishir.note3.engine.model.Element
import com.hashishir.note3.engine.model.IdGen
import com.hashishir.note3.engine.model.MediaElement
import com.hashishir.note3.engine.model.Pt
import com.hashishir.note3.engine.model.ShapeElement
import com.hashishir.note3.engine.model.ShapeKind
import com.hashishir.note3.engine.model.StrokeElement
import com.hashishir.note3.engine.model.StrokeTool
import com.hashishir.note3.engine.model.TextElement
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.ceil
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.roundToInt

enum class PointerKind { FINGER, STYLUS, ERASER }

sealed interface SessionEvent {
    data class Message(val text: String) : SessionEvent
    data class EditText(val elementId: String?, val x: Float, val y: Float) : SessionEvent
    data class PlayMedia(val elementId: String) : SessionEvent
}

interface SessionListener {
    /** Something visual changed (called very often while drawing). */
    fun onInvalidate() {}

    /** The committed page content changed: persist it and refresh undo/redo state. */
    fun onContentChanged() {}

    fun onSelectionChanged() {}
    fun onSettingsChanged() {}
    fun onEvent(event: SessionEvent) {}
}

/**
 * All editing behaviour of one open whiteboard page, independent of Android so it can be unit-tested.
 * The view translates touch events into [pointerDown]/[pointerMove]/[pointerUp] calls using screen
 * coordinates; the session converts them to world coordinates with [viewport].
 */
class DrawingSession(initialHistory: History<PageContent>) {

    var listener: SessionListener? = null

    var history: History<PageContent> = initialHistory
        private set
    val content: PageContent get() = history.current
    val canUndo: Boolean get() = history.canUndo
    val canRedo: Boolean get() = history.canRedo

    val viewport = Viewport()
    var viewW = 0f
    var viewH = 0f

    /** Screen density (pixels per dp). All touch thresholds are defined in dp and scaled by this. */
    var density = 1f

    var settings: ToolSettings = ToolSettings()
        private set

    var activeLayerId: String = initialHistory.current.layers.last().id
        private set

    var selection: Set<String> = emptySet()
        private set
    var selectionBox: Rect? = null
        private set
    var clipboard: List<Element> = emptyList()
        private set

    /** Geometry aids currently shown on the canvas (not saved with the page). */
    val geometry = ArrayList<GeoTool>()

    // ---- live previews read by the renderer ----
    val previewPoints = ArrayList<Pt>()
    var previewColor: Int = 0
        private set
    var previewWidth: Float = 0f
        private set
    var previewTool: StrokeTool = StrokeTool.PEN
        private set
    var previewShape: ShapeElement? = null
        private set
    val lasso = ArrayList<Vec>()
    val polygonDraft = ArrayList<Vec>()
    var eraserPos: Vec? = null
        private set

    // ---- gesture state ----
    private enum class Mode { IDLE, STROKE, ERASE, MOVE, RESIZE, ROTATE, LASSO, SHAPE, POLY_TAP, TEXT_TAP, GEO_MOVE, GEO_HANDLE, IGNORE }

    private var mode = Mode.IDLE
    private var downSx = 0f
    private var downSy = 0f
    private var downWx = 0f
    private var downWy = 0f
    private var lastSx = 0f
    private var lastSy = 0f
    private var lastTime = 0L
    private var pointerKind = PointerKind.FINGER
    private var smoothedPressure = 0.8f
    private var holdAnchorX = 0f
    private var holdAnchorY = 0f
    private var holdTime = 0L
    private var strokeColor = 0
    private var strokeWidth = 3f
    private var strokeTool = StrokeTool.PEN
    private var snapEdge: Pair<Vec, Vec>? = null
    private var eraseBase: PageContent? = null
    private var eraseTool = Tool.ERASER_PARTIAL
    private var lastWx = 0f
    private var lastWy = 0f
    private var dragBase: PageContent? = null
    private var dragMoved = false
    private var tapTarget: Element? = null
    private var lastTapId: String? = null
    private var lastTapTime = 0L
    private var rotateStart = 0f
    private var resizeAnchor = Vec(0f, 0f)
    private var resizeStartDist = 1f
    private var shapeStart = Vec(0f, 0f)
    private var geoIndex = -1
    private var pasteCount = 0

    // ------------------------------------------------------------------ settings / pages

    fun updateSettings(s: ToolSettings) {
        val toolChanged = s.tool != settings.tool
        settings = s
        if (toolChanged) {
            cancelGesture()
            if (s.tool != Tool.SHAPE || s.shapeKind != ShapeKind.POLYGON) polygonDraft.clear()
            eraserPos = null
        }
        if (s.tool == Tool.SHAPE && s.shapeKind != ShapeKind.POLYGON) polygonDraft.clear()
        listener?.onSettingsChanged()
        listener?.onInvalidate()
    }

    /** Switches the session to another page's history. */
    fun attach(h: History<PageContent>) {
        cancelGesture()
        history = h
        selection = emptySet()
        polygonDraft.clear()
        if (content.layers.none { it.id == activeLayerId }) activeLayerId = content.layers.last().id
        refreshSelectionBox()
        listener?.onSelectionChanged()
        listener?.onInvalidate()
    }

    fun setViewSize(w: Float, h: Float) {
        viewW = w
        viewH = h
    }

    fun viewCenterWorld(): Vec = Vec(viewport.toWorldX(viewW / 2f), viewport.toWorldY(viewH / 2f))

    // ------------------------------------------------------------------ pointer input

    /** True if a pointer of this kind should edit the page; otherwise the view should pan with it. */
    fun wantsPointer(kind: PointerKind): Boolean {
        if (kind == PointerKind.FINGER && !settings.fingerDraws && settings.tool != Tool.SELECT) return false
        return settings.tool != Tool.HAND || kind == PointerKind.ERASER
    }

    fun pointerDown(sx: Float, sy: Float, pressure: Float, kind: PointerKind, timeMs: Long) {
        cancelGesture()
        pointerKind = kind
        downSx = sx; downSy = sy; lastSx = sx; lastSy = sy; lastTime = timeMs
        val wx = viewport.toWorldX(sx)
        val wy = viewport.toWorldY(sy)
        downWx = wx; downWy = wy; lastWx = wx; lastWy = wy
        holdAnchorX = sx; holdAnchorY = sy; holdTime = timeMs
        smoothedPressure = 0.8f

        if (kind != PointerKind.ERASER && beginGeometry(wx, wy, sx, sy)) return

        val tool = if (kind == PointerKind.ERASER) Tool.ERASER_PARTIAL else settings.tool
        when (tool) {
            Tool.PEN, Tool.BRUSH, Tool.HIGHLIGHTER -> beginStroke(tool, wx, wy, pressure, kind)
            Tool.ERASER_STROKE, Tool.ERASER_PARTIAL -> beginErase(tool, wx, wy)
            Tool.SELECT -> beginSelect(wx, wy, sx, sy)
            Tool.SHAPE -> beginShape(wx, wy)
            Tool.TEXT -> mode = Mode.TEXT_TAP
            Tool.HAND -> mode = Mode.IGNORE
        }
    }

    fun pointerMove(sx: Float, sy: Float, pressure: Float, timeMs: Long) {
        if (mode == Mode.IDLE || mode == Mode.IGNORE) return
        val wx = viewport.toWorldX(sx)
        val wy = viewport.toWorldY(sy)
        when (mode) {
            Mode.STROKE -> moveStroke(sx, sy, wx, wy, pressure, timeMs)
            Mode.ERASE -> {
                eraseSegment(lastWx, lastWy, wx, wy)
                eraserPos = Vec(wx, wy)
            }
            Mode.MOVE -> moveSelection(sx, sy, wx, wy)
            Mode.RESIZE -> applyDrag(
                Affine.scale(
                    s = (hypot(wx - resizeAnchor.x, wy - resizeAnchor.y) / resizeStartDist).coerceIn(0.05f, 50f),
                    anchor = resizeAnchor
                )
            )
            Mode.ROTATE -> {
                val box = selectionBoxOf(dragBase) ?: return
                var ang = atan2(wy - box.centerY, wx - box.centerX) - rotateStart
                val step = (PI / 12.0).toFloat()
                val snapped = (ang / step).roundToInt() * step
                if (abs(ang - snapped) < Math.toRadians(3.0).toFloat()) ang = snapped
                applyDrag(Affine.rotate(ang, box.centerX, box.centerY))
            }
            Mode.LASSO -> {
                if (hypot(wx - lasso.last().x, wy - lasso.last().y) * viewport.scale >= 3f * density) lasso.add(Vec(wx, wy))
            }
            Mode.SHAPE -> previewShape = buildShape(shapeStart, snapWorld(Vec(wx, wy)))
            Mode.GEO_MOVE -> {
                geometry[geoIndex] = geometry[geoIndex].moved(wx - lastWx, wy - lastWy)
            }
            Mode.GEO_HANDLE -> geometry[geoIndex] = geometry[geoIndex].withHandleAt(wx, wy)
            else -> {}
        }
        lastSx = sx; lastSy = sy; lastWx = wx; lastWy = wy; lastTime = timeMs
        listener?.onInvalidate()
    }

    fun pointerUp(sx: Float, sy: Float, timeMs: Long) {
        val wx = viewport.toWorldX(sx)
        val wy = viewport.toWorldY(sy)
        when (mode) {
            Mode.STROKE -> finishStroke(timeMs)
            Mode.ERASE -> finishErase()
            Mode.MOVE -> finishMove(timeMs)
            Mode.RESIZE, Mode.ROTATE -> finishDrag()
            Mode.LASSO -> finishLasso()
            Mode.SHAPE -> finishShape(sx, sy, wx, wy)
            Mode.POLY_TAP -> finishPolyTap(sx, sy, wx, wy)
            Mode.TEXT_TAP -> finishTextTap(sx, sy, wx, wy)
            else -> {}
        }
        mode = Mode.IDLE
        eraserPos = null
        listener?.onInvalidate()
    }

    /** Aborts the current gesture (for example when a second finger lands). */
    fun cancelGesture() {
        when (mode) {
            Mode.STROKE -> previewPoints.clear()
            Mode.ERASE -> finishErase()
            Mode.MOVE, Mode.RESIZE, Mode.ROTATE -> {
                dragBase?.let { history.update(it) }
                dragBase = null
                refreshSelectionBox()
            }
            Mode.LASSO -> lasso.clear()
            Mode.SHAPE -> previewShape = null
            else -> {}
        }
        mode = Mode.IDLE
        eraserPos = null
        snapEdge = null
        listener?.onInvalidate()
    }

    // ------------------------------------------------------------------ geometry tools

    private fun beginGeometry(wx: Float, wy: Float, sx: Float, sy: Float): Boolean {
        if (geometry.isEmpty()) return false
        val hit = GRIP_HIT_PX * density
        for (i in geometry.indices.reversed()) {
            val g = geometry[i]
            val h = g.handle()
            if (hypot(viewport.toScreenX(h.x) - sx, viewport.toScreenY(h.y) - sy) <= hit) {
                geoIndex = i; mode = Mode.GEO_HANDLE; return true
            }
            if (hypot(viewport.toScreenX(g.cx) - sx, viewport.toScreenY(g.cy) - sy) <= hit) {
                geoIndex = i; mode = Mode.GEO_MOVE; return true
            }
        }
        if (settings.tool == Tool.SELECT || settings.tool == Tool.HAND) {
            val margin = SNAP_PX * density / viewport.scale
            for (i in geometry.indices.reversed()) {
                val g = geometry[i]
                if (g.contains(wx, wy) && g.distanceToNearestEdge(wx, wy) > margin) {
                    geoIndex = i; mode = Mode.GEO_MOVE; return true
                }
            }
        }
        return false
    }

    fun addGeometry(kind: GeoKind) {
        geometry.removeAll { it.kind == kind }
        val c = viewCenterWorld()
        val ref = minOf(viewport.toWorldX(viewW) - viewport.toWorldX(0f), viewport.toWorldY(viewH) - viewport.toWorldY(0f))
        geometry.add(GeoTool.create(kind, c.x, c.y, ref))
        listener?.onInvalidate()
    }

    fun removeGeometry(kind: GeoKind) {
        geometry.removeAll { it.kind == kind }
        listener?.onInvalidate()
    }

    fun clearGeometry() {
        geometry.clear()
        listener?.onInvalidate()
    }

    private fun nearestGeometryEdge(wx: Float, wy: Float): Pair<Vec, Vec>? {
        if (geometry.isEmpty()) return null
        val maxD = SNAP_PX * density / viewport.scale
        var best: Pair<Vec, Vec>? = null
        var bestD = maxD
        for (g in geometry) for (e in g.edges()) {
            val d = Geo.distPointSegment(wx, wy, e.first.x, e.first.y, e.second.x, e.second.y)
            if (d <= bestD) {
                bestD = d
                best = e
            }
        }
        return best
    }

    // ------------------------------------------------------------------ freehand drawing

    private fun layerEditable(): Boolean {
        val l = content.layers.firstOrNull { it.id == activeLayerId } ?: return false
        return l.visible && !l.locked
    }

    private fun warnLayer() {
        listener?.onEvent(SessionEvent.Message("The active layer is hidden or locked."))
    }

    private fun beginStroke(tool: Tool, wx: Float, wy: Float, pressure: Float, kind: PointerKind) {
        if (!layerEditable()) {
            warnLayer(); mode = Mode.IGNORE; return
        }
        strokeTool = when (tool) {
            Tool.BRUSH -> StrokeTool.BRUSH
            Tool.HIGHLIGHTER -> StrokeTool.HIGHLIGHTER
            else -> StrokeTool.PEN
        }
        strokeColor = settings.inkColor
        strokeWidth = settings.width
        snapEdge = nearestGeometryEdge(wx, wy)
        val p0 = if (kind == PointerKind.STYLUS) pressure.coerceIn(0.15f, 1.2f) else smoothedPressure
        val start = snapEdge?.let { GeoTool.projectOnSegment(wx, wy, it.first, it.second) } ?: Vec(wx, wy)
        previewPoints.clear()
        previewPoints.add(Pt(start.x, start.y, p0))
        previewColor = strokeColor
        previewWidth = strokeWidth
        previewTool = strokeTool
        mode = Mode.STROKE
    }

    private fun moveStroke(sx: Float, sy: Float, wx: Float, wy: Float, pressure: Float, timeMs: Long) {
        var px = wx
        var py = wy
        snapEdge?.let {
            val q = GeoTool.projectOnSegment(wx, wy, it.first, it.second)
            px = q.x; py = q.y
        }
        val last = previewPoints.lastOrNull()
        if (!StrokeProcessor.shouldAccept(last, px, py, 1.2f * density / viewport.scale)) return
        val p = if (pointerKind == PointerKind.STYLUS) {
            pressure.coerceIn(0.15f, 1.2f)
        } else {
            val dt = max(1L, timeMs - lastTime).toFloat()
            val speed = hypot(sx - lastSx, sy - lastSy) / dt
            smoothedPressure = StrokeProcessor.pseudoPressure(smoothedPressure, speed)
            smoothedPressure
        }
        previewPoints.add(Pt(px, py, p))
        if (hypot(sx - holdAnchorX, sy - holdAnchorY) > HOLD_SLOP_PX * density) {
            holdAnchorX = sx; holdAnchorY = sy; holdTime = timeMs
        }
    }

    private fun finishStroke(timeMs: Long) {
        val raw = ArrayList(previewPoints)
        previewPoints.clear()
        val edge = snapEdge
        snapEdge = null
        if (raw.isEmpty()) return
        var element: Element? = null
        val canRecognize = edge == null && raw.size >= 6 &&
            (strokeTool == StrokeTool.PEN || strokeTool == StrokeTool.BRUSH)
        if (canRecognize && settings.recognize != RecognizeMode.OFF) {
            val held = timeMs - holdTime >= HOLD_MS
            if (settings.recognize == RecognizeMode.ALWAYS || held) {
                ShapeRecognizer.recognize(raw)?.let { r ->
                    element = ShapeElement(
                        id = IdGen.next(), layerId = activeLayerId, groupId = null,
                        kind = r.kind, pts = r.pts, color = strokeColor, width = strokeWidth,
                        fillColor = fillFor(strokeColor)
                    )
                }
            }
        }
        if (element == null) {
            val pts = when {
                raw.size < 2 -> StrokeProcessor.dot(raw[0].x, raw[0].y, raw[0].p)
                edge != null -> listOf(raw.first(), raw.last())
                else -> StrokeProcessor.finish(raw, 0.5f * density / viewport.scale, 1)
            }
            element = StrokeElement(IdGen.next(), activeLayerId, null, pts, strokeColor, strokeWidth, strokeTool)
        }
        push(content.copy(elements = content.elements + element!!))
    }

    private fun fillFor(color: Int): Int =
        if (settings.fillShapes) (color and 0x00FFFFFF) or 0x40000000 else 0

    // ------------------------------------------------------------------ erasing

    private fun beginErase(tool: Tool, wx: Float, wy: Float) {
        eraseTool = tool
        eraseBase = content
        mode = Mode.ERASE
        eraserPos = Vec(wx, wy)
        eraseSegment(wx, wy, wx, wy)
    }

    private fun eraseSegment(fx: Float, fy: Float, tx: Float, ty: Float) {
        val r = settings.eraserRadiusPx * density / viewport.scale
        val dist = hypot(tx - fx, ty - fy)
        val steps = max(1, ceil(dist / (r * 0.6f)).toInt())
        val editable = EditOps.editablePredicate(content.layers)
        var els = content.elements
        for (i in 1..steps) {
            val t = i.toFloat() / steps
            val x = fx + (tx - fx) * t
            val y = fy + (ty - fy) * t
            els = if (eraseTool == Tool.ERASER_STROKE) {
                Eraser.eraseWholeElements(els, x, y, r, editable)
            } else {
                Eraser.erasePartial(els, x, y, r, editable)
            }
        }
        if (els !== content.elements) history.update(content.copy(elements = els))
    }

    private fun finishErase() {
        val base = eraseBase
        eraseBase = null
        if (base != null && history.commit(base)) {
            val ids = content.elements.map { it.id }.toHashSet()
            if (selection.any { it !in ids }) selection = selection.filter { it in ids }.toSet()
            changed()
            listener?.onSelectionChanged()
        }
    }

    // ------------------------------------------------------------------ selection

    private fun corner(b: Rect, i: Int): Vec = when (i) {
        0 -> Vec(b.left, b.top)
        1 -> Vec(b.right, b.top)
        2 -> Vec(b.right, b.bottom)
        else -> Vec(b.left, b.bottom)
    }

    private fun selectionBoxOf(c: PageContent?): Rect? =
        if (c == null) null else EditOps.selectionBounds(c.elements, selection)

    private fun beginSelect(wx: Float, wy: Float, sx: Float, sy: Float) {
        val box = selectionBox
        if (box != null && selection.isNotEmpty()) {
            val hx = viewport.toScreenX(box.centerX)
            val hy = viewport.toScreenY(box.top) - ROTATE_HANDLE_PX * density
            if (hypot(sx - hx, sy - hy) <= HANDLE_HIT_PX * density) {
                mode = Mode.ROTATE
                rotateStart = atan2(wy - box.centerY, wx - box.centerX)
                dragBase = content
                return
            }
            for (i in 0..3) {
                val c = corner(box, i)
                if (hypot(sx - viewport.toScreenX(c.x), sy - viewport.toScreenY(c.y)) <= HANDLE_HIT_PX * density) {
                    mode = Mode.RESIZE
                    resizeAnchor = corner(box, (i + 2) % 4)
                    resizeStartDist = max(1e-3f, hypot(c.x - resizeAnchor.x, c.y - resizeAnchor.y))
                    dragBase = content
                    return
                }
            }
        }
        val tol = HIT_TOL_PX * density / viewport.scale
        val hit = EditOps.topmostAt(content.elements, content.layers, wx, wy, tol)
        if (hit != null) {
            if (hit.id !in selection) setSelection(EditOps.expandToGroups(content.elements, setOf(hit.id)))
            tapTarget = hit
            mode = Mode.MOVE
            dragBase = content
            dragMoved = false
            return
        }
        if (box != null && selection.isNotEmpty() && box.inflate(tol).contains(wx, wy)) {
            tapTarget = null
            mode = Mode.MOVE
            dragBase = content
            dragMoved = false
            return
        }
        mode = Mode.LASSO
        lasso.clear()
        lasso.add(Vec(wx, wy))
    }

    private fun moveSelection(sx: Float, sy: Float, wx: Float, wy: Float) {
        if (!dragMoved && hypot(sx - downSx, sy - downSy) < TAP_SLOP_PX * density) return
        dragMoved = true
        applyDrag(Affine.translate(wx - downWx, wy - downWy))
    }

    private fun applyDrag(m: Affine) {
        val base = dragBase ?: return
        history.update(base.copy(elements = EditOps.transform(base.elements, selection, m)))
        refreshSelectionBox()
    }

    private fun finishMove(timeMs: Long) {
        if (dragMoved) {
            finishDrag()
            return
        }
        dragBase = null
        val target = tapTarget
        tapTarget = null
        if (target == null) return
        if (selection.size > 1) setSelection(EditOps.expandToGroups(content.elements, setOf(target.id)))
        if (lastTapId == target.id && timeMs - lastTapTime < DOUBLE_TAP_MS) {
            lastTapId = null
            when (target) {
                is TextElement -> listener?.onEvent(SessionEvent.EditText(target.id, target.ox, target.oy))
                is MediaElement -> listener?.onEvent(SessionEvent.PlayMedia(target.id))
                else -> {}
            }
        } else {
            lastTapId = target.id
            lastTapTime = timeMs
        }
    }

    private fun finishDrag() {
        val base = dragBase
        dragBase = null
        if (base != null && history.commit(base)) changed()
    }

    private fun finishLasso() {
        val pts = ArrayList(lasso)
        lasso.clear()
        if (pts.size >= 3 && Geo.pathLength(pts) * viewport.scale > 24f * density) {
            val ids = EditOps.inLasso(content.elements, content.layers, pts)
            setSelection(EditOps.expandToGroups(content.elements, ids))
        } else {
            setSelection(emptySet())
        }
    }

    fun setSelection(ids: Set<String>) {
        selection = ids
        refreshSelectionBox()
        listener?.onSelectionChanged()
        listener?.onInvalidate()
    }

    fun clearSelection() = setSelection(emptySet())

    fun selectAll() {
        val editable = EditOps.editablePredicate(content.layers)
        setSelection(content.elements.filter(editable).map { it.id }.toSet())
    }

    private fun refreshSelectionBox() {
        selectionBox = if (selection.isEmpty()) null else EditOps.selectionBounds(content.elements, selection)
    }

    fun selectedElements(): List<Element> = EditOps.snapshot(content.elements, selection)

    // ------------------------------------------------------------------ shapes

    private fun snapWorld(v: Vec): Vec {
        if (!settings.snapToGrid) return v
        val g = settings.gridSize
        return Vec((v.x / g).roundToInt() * g, (v.y / g).roundToInt() * g)
    }

    private fun beginShape(wx: Float, wy: Float) {
        if (!layerEditable()) {
            warnLayer(); mode = Mode.IGNORE; return
        }
        if (settings.shapeKind == ShapeKind.POLYGON) {
            mode = Mode.POLY_TAP
        } else {
            shapeStart = snapWorld(Vec(wx, wy))
            previewShape = null
            mode = Mode.SHAPE
        }
    }

    private fun buildShape(a: Vec, b: Vec): ShapeElement? {
        val kind = settings.shapeKind
        val pts: List<Vec> = when (kind) {
            ShapeKind.LINE, ShapeKind.ARROW -> listOf(a, b)
            ShapeKind.RECT -> listOf(a, Vec(b.x, a.y), b, Vec(a.x, b.y))
            ShapeKind.ELLIPSE -> {
                val c = Vec((a.x + b.x) / 2f, (a.y + b.y) / 2f)
                listOf(c, Vec(b.x, c.y), Vec(c.x, b.y))
            }
            ShapeKind.TRIANGLE -> listOf(Vec((a.x + b.x) / 2f, a.y), b, Vec(a.x, b.y))
            ShapeKind.POLYGON -> return null
        }
        return ShapeElement(
            id = IdGen.next(), layerId = activeLayerId, groupId = null, kind = kind, pts = pts,
            color = settings.color, width = settings.penWidth,
            fillColor = if (kind == ShapeKind.LINE || kind == ShapeKind.ARROW) 0 else fillFor(settings.color)
        )
    }

    private fun finishShape(sx: Float, sy: Float, wx: Float, wy: Float) {
        val preview = previewShape
        previewShape = null
        if (preview == null || hypot(sx - downSx, sy - downSy) < 6f * density) return
        val built = buildShape(shapeStart, snapWorld(Vec(wx, wy))) ?: return
        push(content.copy(elements = content.elements + built))
    }

    private fun finishPolyTap(sx: Float, sy: Float, wx: Float, wy: Float) {
        if (hypot(sx - downSx, sy - downSy) > 14f * density) return
        val p = snapWorld(Vec(wx, wy))
        if (polygonDraft.size >= 3) {
            val first = polygonDraft[0]
            val d = hypot(viewport.toScreenX(first.x) - sx, viewport.toScreenY(first.y) - sy)
            if (d <= 24f * density) {
                finishPolygon()
                return
            }
        }
        polygonDraft.add(p)
    }

    val canFinishPolygon: Boolean get() = polygonDraft.size >= 3

    fun finishPolygon() {
        if (polygonDraft.size < 3 || !layerEditable()) return
        val e = ShapeElement(
            id = IdGen.next(), layerId = activeLayerId, groupId = null, kind = ShapeKind.POLYGON,
            pts = ArrayList(polygonDraft), color = settings.color, width = settings.penWidth,
            fillColor = fillFor(settings.color)
        )
        polygonDraft.clear()
        push(content.copy(elements = content.elements + e))
    }

    fun cancelPolygon() {
        polygonDraft.clear()
        listener?.onInvalidate()
    }

    // ------------------------------------------------------------------ text tool

    private fun finishTextTap(sx: Float, sy: Float, wx: Float, wy: Float) {
        if (hypot(sx - downSx, sy - downSy) > 14f * density) return
        val hit = EditOps.topmostAt(content.elements, content.layers, wx, wy, HIT_TOL_PX * density / viewport.scale)
        if (hit is TextElement) {
            listener?.onEvent(SessionEvent.EditText(hit.id, hit.ox, hit.oy))
        } else {
            if (!layerEditable()) {
                warnLayer(); return
            }
            listener?.onEvent(SessionEvent.EditText(null, wx, wy))
        }
    }

    fun elementById(id: String): Element? = content.elements.firstOrNull { it.id == id }

    fun addText(text: String, x: Float, y: Float, w: Float, h: Float, fontSize: Float, color: Int): String? {
        if (text.isBlank()) return null
        if (!layerEditable()) {
            warnLayer(); return null
        }
        val e = TextElement(
            id = IdGen.next(), layerId = activeLayerId, ox = x, oy = y, w = w, h = h,
            text = text, color = color, fontSize = fontSize
        )
        push(content.copy(elements = content.elements + e))
        return e.id
    }

    fun updateText(id: String, text: String, w: Float, h: Float, fontSize: Float, color: Int) {
        val old = elementById(id) as? TextElement ?: return
        if (text.isBlank()) {
            push(content.copy(elements = EditOps.delete(content.elements, setOf(id))))
            if (id in selection) setSelection(selection - id)
            return
        }
        val updated = old.copy(text = text, w = w, h = h, fontSize = fontSize, color = color)
        push(content.copy(elements = content.elements.map { if (it.id == id) updated else it }))
    }

    // ------------------------------------------------------------------ element insertion

    /** Adds an image/media/other element to the active layer and selects it. */
    fun addElement(e: Element): Boolean {
        if (!layerEditable()) {
            warnLayer(); return false
        }
        val placed = e.withMeta(layerId = activeLayerId)
        push(content.copy(elements = content.elements + placed))
        selection = setOf(placed.id)
        refreshSelectionBox()
        updateSettings(settings.copy(tool = Tool.SELECT))
        listener?.onSelectionChanged()
        return true
    }

    // ------------------------------------------------------------------ edit actions

    fun deleteSelection() {
        if (selection.isEmpty()) return
        push(content.copy(elements = EditOps.delete(content.elements, selection)))
        setSelection(emptySet())
    }

    fun copy() {
        if (selection.isEmpty()) return
        clipboard = selectedElements()
        pasteCount = 0
    }

    fun cut() {
        copy()
        deleteSelection()
    }

    fun paste() {
        if (clipboard.isEmpty() || !layerEditable()) {
            if (clipboard.isNotEmpty()) warnLayer()
            return
        }
        var b: Rect? = null
        for (e in clipboard) b = if (b == null) e.bounds() else b.union(e.bounds())
        val box = b ?: return
        val center = viewCenterWorld()
        val offset = 24f * pasteCount
        val dx = center.x - box.centerX + offset
        val dy = center.y - box.centerY + offset
        pasteCount++
        insertCopies(clipboard, dx, dy)
    }

    fun duplicate() {
        if (selection.isEmpty()) return
        val src = selectedElements()
        insertCopies(src, 32f, 32f)
    }

    private fun insertCopies(src: List<Element>, dx: Float, dy: Float) {
        val (list, ids) = EditOps.insertCopies(content.elements, src, activeLayerId, dx, dy)
        push(content.copy(elements = list))
        setSelection(ids)
    }

    fun group() {
        if (selection.size < 2) return
        push(content.copy(elements = EditOps.group(content.elements, selection)))
    }

    fun ungroup() {
        if (selection.isEmpty()) return
        push(content.copy(elements = EditOps.ungroup(content.elements, selection)))
    }

    fun bringToFront() {
        if (selection.isEmpty()) return
        push(content.copy(elements = EditOps.bringToFront(content.elements, selection)))
    }

    fun sendToBack() {
        if (selection.isEmpty()) return
        push(content.copy(elements = EditOps.sendToBack(content.elements, selection)))
    }

    fun moveSelectionToLayer(layerId: String) {
        if (selection.isEmpty() || content.layers.none { it.id == layerId }) return
        push(content.copy(elements = EditOps.moveToLayer(content.elements, selection, layerId)))
    }

    val selectionIsGrouped: Boolean
        get() = content.elements.any { it.id in selection && it.groupId != null }

    // ------------------------------------------------------------------ layers

    fun setActiveLayer(id: String) {
        if (content.layers.any { it.id == id }) {
            activeLayerId = id
            listener?.onContentChanged()
        }
    }

    fun addLayer(name: String) {
        val (c, id) = LayerOps.add(content, name)
        push(c)
        activeLayerId = id
    }

    fun removeLayer(id: String) {
        val c = LayerOps.remove(content, id)
        if (c === content) {
            listener?.onEvent(SessionEvent.Message("A page needs at least one layer."))
            return
        }
        push(c)
        if (activeLayerId == id) activeLayerId = c.layers.last().id
        pruneSelection()
    }

    fun renameLayer(id: String, name: String) = push(LayerOps.rename(content, id, name))
    fun setLayerVisible(id: String, v: Boolean) { push(LayerOps.setVisible(content, id, v)); pruneSelection() }
    fun setLayerLocked(id: String, v: Boolean) { push(LayerOps.setLocked(content, id, v)); pruneSelection() }
    fun moveLayer(id: String, delta: Int) = push(LayerOps.move(content, id, delta))

    private fun pruneSelection() {
        val editable = EditOps.editablePredicate(content.layers)
        val ok = content.elements.filter(editable).map { it.id }.toHashSet()
        if (selection.any { it !in ok }) setSelection(selection.filter { it in ok }.toSet())
    }

    // ------------------------------------------------------------------ history

    fun undo() {
        cancelGesture()
        if (history.undo() != null) afterHistoryJump()
    }

    fun redo() {
        cancelGesture()
        if (history.redo() != null) afterHistoryJump()
    }

    private fun afterHistoryJump() {
        val ids = content.elements.map { it.id }.toHashSet()
        selection = selection.filter { it in ids }.toSet()
        if (content.layers.none { it.id == activeLayerId }) activeLayerId = content.layers.last().id
        changed()
        listener?.onSelectionChanged()
    }

    private fun push(c: PageContent) {
        history.push(c)
        changed()
    }

    private fun changed() {
        refreshSelectionBox()
        listener?.onContentChanged()
        listener?.onInvalidate()
    }

    companion object {
        const val HIT_TOL_PX = 12f
        const val SNAP_PX = 14f
        const val HANDLE_HIT_PX = 30f
        const val GRIP_HIT_PX = 30f
        const val ROTATE_HANDLE_PX = 44f
        const val TAP_SLOP_PX = 8f
        const val HOLD_SLOP_PX = 4f
        const val HOLD_MS = 500L
        const val DOUBLE_TAP_MS = 350L
    }
}

private fun Affine.Companion.scale(s: Float, anchor: Vec): Affine = scale(s, s, anchor.x, anchor.y)
