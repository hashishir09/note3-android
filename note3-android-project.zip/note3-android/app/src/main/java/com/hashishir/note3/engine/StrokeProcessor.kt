package com.hashishir.note3.engine

import com.hashishir.note3.engine.math.Geo
import com.hashishir.note3.engine.math.Vec
import com.hashishir.note3.engine.model.Pt
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

/** Input filtering and post-processing for freehand strokes. All distances are in world units. */
object StrokeProcessor {

    /** Returns true if [next] is far enough from [last] to be worth recording. */
    fun shouldAccept(last: Pt?, nextX: Float, nextY: Float, minDist: Float): Boolean {
        if (last == null) return true
        return hypot(nextX - last.x, nextY - last.y) >= minDist
    }

    /**
     * Derives a pseudo-pressure for finger input from drawing speed: slower strokes get thicker,
     * faster ones thinner. [speed] is in screen pixels per millisecond. Smoothed against [prev].
     */
    fun pseudoPressure(prev: Float, speed: Float): Float {
        val target = (1.25f - speed * 0.55f).coerceIn(0.45f, 1.15f)
        return prev + (target - prev) * 0.25f
    }

    /**
     * Light 3-tap smoothing that keeps both endpoints fixed, followed by RDP reduction so
     * committed strokes stay small in memory and in the database.
     */
    fun finish(points: List<Pt>, simplifyEpsilon: Float, smoothPasses: Int = 1): List<Pt> {
        if (points.size < 3) return points
        var cur = points
        repeat(smoothPasses) { cur = smoothOnce(cur) }
        if (simplifyEpsilon <= 0f) return cur
        // Simplify on positions, then map back to the surviving samples (keeps pressure).
        val vecs = cur.map { Vec(it.x, it.y) }
        val keep = BooleanArray(cur.size)
        keep[0] = true
        keep[cur.size - 1] = true
        rdpMark(vecs, 0, cur.size - 1, simplifyEpsilon, keep)
        val out = ArrayList<Pt>()
        for (i in cur.indices) if (keep[i]) out.add(cur[i])
        return out
    }

    private fun smoothOnce(src: List<Pt>): List<Pt> {
        val out = ArrayList<Pt>(src.size)
        out.add(src[0])
        for (i in 1 until src.size - 1) {
            val a = src[i - 1]
            val b = src[i]
            val c = src[i + 1]
            out.add(
                Pt(
                    x = (a.x + 2f * b.x + c.x) / 4f,
                    y = (a.y + 2f * b.y + c.y) / 4f,
                    p = (a.p + 2f * b.p + c.p) / 4f
                )
            )
        }
        out.add(src.last())
        return out
    }

    private fun rdpMark(v: List<Vec>, s: Int, e: Int, eps: Float, keep: BooleanArray) {
        val stack = ArrayDeque<IntArray>()
        stack.addLast(intArrayOf(s, e))
        while (stack.isNotEmpty()) {
            val (a, b) = stack.removeLast()
            if (b <= a + 1) continue
            var maxD = -1f
            var idx = -1
            for (i in a + 1 until b) {
                val d = Geo.distPointSegment(v[i].x, v[i].y, v[a].x, v[a].y, v[b].x, v[b].y)
                if (d > maxD) {
                    maxD = d
                    idx = i
                }
            }
            if (maxD > eps && idx >= 0) {
                keep[idx] = true
                stack.addLast(intArrayOf(a, idx))
                stack.addLast(intArrayOf(idx, b))
            }
        }
    }

    /** A dot (tap without movement) is stored as a two-point stroke so it renders with round caps. */
    fun dot(x: Float, y: Float, p: Float): List<Pt> = listOf(Pt(x, y, p), Pt(x + 0.01f, y + 0.01f, p))

    fun clampWidth(width: Float, minW: Float, maxW: Float): Float = max(minW, min(maxW, width))
}
