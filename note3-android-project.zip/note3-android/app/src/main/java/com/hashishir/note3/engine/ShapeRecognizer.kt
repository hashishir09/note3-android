package com.hashishir.note3.engine

import com.hashishir.note3.engine.math.Geo
import com.hashishir.note3.engine.math.Rect
import com.hashishir.note3.engine.math.Vec
import com.hashishir.note3.engine.model.Pt
import com.hashishir.note3.engine.model.ShapeKind
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.sqrt

data class RecognizedShape(val kind: ShapeKind, val pts: List<Vec>)

/**
 * Converts a hand-drawn stroke into a clean shape. Returns null when the stroke does not clearly
 * resemble a supported shape (so the original freehand stroke is kept).
 *
 * Supported: line, triangle, rectangle (also rotated), ellipse/circle, and polygons with up to 8 corners.
 * Arrows are not auto-detected; use the arrow tool.
 */
object ShapeRecognizer {

    fun recognize(points: List<Pt>): RecognizedShape? {
        if (points.size < 6) return null
        val raw = points.map { Vec(it.x, it.y) }
        val box = Rect.fromPoints(raw)
        val diag = hypot(box.width, box.height)
        if (diag < 1e-3f) return null
        val len = Geo.pathLength(raw)
        val first = raw.first()
        val last = raw.last()
        val gap = first.dist(last)

        val closed = gap < 0.2f * len && len > diag * 1.3f
        return if (closed) recognizeClosed(raw, diag) else recognizeLine(raw, len)
    }

    private fun recognizeLine(raw: List<Vec>, len: Float): RecognizedShape? {
        val a = raw.first()
        val b = raw.last()
        val segLen = a.dist(b)
        if (segLen < 1e-3f) return null
        var maxDev = 0f
        for (p in raw) maxDev = max(maxDev, Geo.distPointSegment(p.x, p.y, a.x, a.y, b.x, b.y))
        return if (maxDev <= 0.06f * segLen && len < segLen * 1.25f) {
            RecognizedShape(ShapeKind.LINE, listOf(a, b))
        } else null
    }

    private fun recognizeClosed(raw: List<Vec>, diag: Float): RecognizedShape? {
        val coarse = vertices(raw, 0.06f * diag, 28.0)
        // The fine pass keeps gentle corners (15 degrees) so a circle never collapses into a few vertices.
        val fine = vertices(raw, 0.02f * diag, 15.0)
        val nc = coarse.size

        if (nc < 3) return null
        if (nc == 3) {
            return if (triangleArea(coarse) > 0.02f * diag * diag) RecognizedShape(ShapeKind.TRIANGLE, coarse) else null
        }
        if (nc == 4) {
            return if (isRectLike(coarse)) {
                RecognizedShape(ShapeKind.RECT, regularizeRect(coarse))
            } else {
                RecognizedShape(ShapeKind.POLYGON, coarse)
            }
        }
        // 5+ vertices: a polygon with straight edges (few vertices at a tight tolerance) or a round shape.
        if (fine.size in 5..8) return RecognizedShape(ShapeKind.POLYGON, fine)
        fitEllipse(raw)?.let { return it }
        return if (nc <= 8) RecognizedShape(ShapeKind.POLYGON, coarse) else null
    }

    /** RDP-simplified closed-loop vertices with near-collinear points removed. */
    internal fun vertices(raw: List<Vec>, eps: Float, minTurnDegrees: Double): List<Vec> {
        var s = Geo.simplifyRdp(raw, eps)
        if (s.size > 3 && s.first().dist(s.last()) < eps * 3f) s = s.dropLast(1)
        val v = s.toMutableList()
        while (v.size > 3) {
            var minTurn = Float.MAX_VALUE
            var idx = -1
            for (i in v.indices) {
                val p = v[(i - 1 + v.size) % v.size]
                val c = v[i]
                val n = v[(i + 1) % v.size]
                val t = abs(Geo.angleBetween(c - p, n - c))
                if (t < minTurn) {
                    minTurn = t
                    idx = i
                }
            }
            if (minTurn < Math.toRadians(minTurnDegrees).toFloat() && idx >= 0) v.removeAt(idx) else break
        }
        return v
    }

    private fun triangleArea(t: List<Vec>): Float =
        abs((t[1] - t[0]).cross(t[2] - t[0])) / 2f

    private fun isRectLike(q: List<Vec>): Boolean {
        for (i in q.indices) {
            val p = q[(i - 1 + 4) % 4]
            val c = q[i]
            val n = q[(i + 1) % 4]
            val ang = abs(Geo.angleBetween(c - p, n - c))
            if (abs(ang - (PI / 2).toFloat()) > Math.toRadians(25.0).toFloat()) return false
        }
        val s0 = q[0].dist(q[1])
        val s1 = q[1].dist(q[2])
        val s2 = q[2].dist(q[3])
        val s3 = q[3].dist(q[0])
        fun ok(a: Float, b: Float) = min(a, b) / max(a, b).coerceAtLeast(1e-6f) > 0.6f
        return ok(s0, s2) && ok(s1, s3)
    }

    /** Builds a true rectangle (axis-aligned when close to it) from four rough corners. */
    private fun regularizeRect(q: List<Vec>): List<Vec> {
        val cx = q.sumOf { it.x.toDouble() }.toFloat() / 4f
        val cy = q.sumOf { it.y.toDouble() }.toFloat() / 4f
        val e0 = q[1] - q[0]
        val e2 = q[2] - q[3]
        val e1 = q[2] - q[1]
        val e3 = q[3] - q[0]
        // Direction of the first pair of sides; size is the average of each opposite pair.
        val dir = Vec((e0.x + e2.x) / 2f, (e0.y + e2.y) / 2f)
        val wLen = (e0.length() + e2.length()) / 2f
        val hLen = (e1.length() + e3.length()) / 2f
        var theta = atan2(dir.y, dir.x)
        // Snap to the nearest axis if within ~8 degrees.
        val quarter = (PI / 2).toFloat()
        val snapped = (theta / quarter).roundToInt() * quarter
        if (abs(theta - snapped) < Math.toRadians(8.0).toFloat()) theta = snapped
        val cs = cos(theta)
        val sn = sin(theta)
        val ux = Vec(cs * wLen / 2f, sn * wLen / 2f)
        val vx = Vec(-sn * hLen / 2f, cs * hLen / 2f)
        val c = Vec(cx, cy)
        return listOf(c - ux - vx, c + ux - vx, c + ux + vx, c - ux + vx)
    }

    /** PCA-based ellipse fit; accepted only if the stroke hugs the fitted curve. */
    private fun fitEllipse(raw: List<Vec>): RecognizedShape? {
        val loop = raw + raw.first()
        val pts = Geo.resampleUniform(loop, 72)
        val n = pts.size
        var cx = 0f
        var cy = 0f
        for (p in pts) { cx += p.x; cy += p.y }
        cx /= n; cy /= n
        var sxx = 0f
        var sxy = 0f
        var syy = 0f
        for (p in pts) {
            val dx = p.x - cx
            val dy = p.y - cy
            sxx += dx * dx; sxy += dx * dy; syy += dy * dy
        }
        val phi = 0.5f * atan2(2f * sxy, sxx - syy)
        val cp = cos(phi)
        val sp = sin(phi)
        var mx = 0f
        var my = 0f
        for (p in pts) {
            val dx = p.x - cx
            val dy = p.y - cy
            val xr = dx * cp + dy * sp
            val yr = -dx * sp + dy * cp
            mx += xr * xr; my += yr * yr
        }
        var a = sqrt(2f * mx / n)
        var b = sqrt(2f * my / n)
        if (a < 1e-3f || b < 1e-3f) return null
        if (min(a, b) / max(a, b) < 0.2f) return null

        // Rescale so the mean normalized radius is exactly 1, then measure the residual.
        var meanR = 0f
        for (p in pts) {
            val dx = p.x - cx
            val dy = p.y - cy
            val xr = (dx * cp + dy * sp) / a
            val yr = (-dx * sp + dy * cp) / b
            meanR += sqrt(xr * xr + yr * yr)
        }
        meanR /= n
        a *= meanR
        b *= meanR
        var meanErr = 0f
        var maxErr = 0f
        for (p in pts) {
            val dx = p.x - cx
            val dy = p.y - cy
            val xr = (dx * cp + dy * sp) / a
            val yr = (-dx * sp + dy * cp) / b
            val e = abs(sqrt(xr * xr + yr * yr) - 1f)
            meanErr += e
            if (e > maxErr) maxErr = e
        }
        meanErr /= n
        if (meanErr > 0.085f || maxErr > 0.22f) return null

        if (abs(a - b) / max(a, b) < 0.12f) {
            val r = (a + b) / 2f
            a = r
            b = r
        }
        val c = Vec(cx, cy)
        val u = Vec(cp * a, sp * a)
        val v = Vec(-sp * b, cp * b)
        return RecognizedShape(ShapeKind.ELLIPSE, listOf(c, c + u, c + v))
    }
}
