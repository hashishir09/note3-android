package com.hashishir.note3.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface BoardDao {
    @Query(
        "SELECT b.id AS id, b.title AS title, b.createdAt AS createdAt, b.updatedAt AS updatedAt, " +
            "(SELECT COUNT(*) FROM pages p WHERE p.boardId = b.id) AS pageCount " +
            "FROM boards b ORDER BY b.updatedAt DESC"
    )
    fun observeSummaries(): Flow<List<BoardSummary>>

    @Query("SELECT * FROM boards WHERE id = :id")
    suspend fun get(id: String): BoardEntity?

    @Query("SELECT id FROM boards")
    suspend fun allIds(): List<String>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(board: BoardEntity)

    @Query("UPDATE boards SET title = :title, updatedAt = :now WHERE id = :id")
    suspend fun rename(id: String, title: String, now: Long)

    @Query("UPDATE boards SET updatedAt = :now WHERE id = :id")
    suspend fun touch(id: String, now: Long)

    @Query("DELETE FROM boards WHERE id = :id")
    suspend fun delete(id: String)
}

@Dao
interface PageDao {
    @Query("SELECT * FROM pages WHERE boardId = :boardId ORDER BY position ASC")
    suspend fun pagesOf(boardId: String): List<PageEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(page: PageEntity)

    @Query("UPDATE pages SET position = :position WHERE id = :id")
    suspend fun setPosition(id: String, position: Int)

    @Query("DELETE FROM pages WHERE id = :id")
    suspend fun delete(id: String)
}
