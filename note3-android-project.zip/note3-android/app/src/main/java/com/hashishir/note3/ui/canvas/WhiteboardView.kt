package com.hashishir.note3.ui.canvas

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.view.MotionEvent
import android.view.View
import com.hashishir.note3.editor.DrawingSession
import com.hashishir.note3.editor.PointerKind
import com.hashishir.note3.engine.math.Rect
import com.hashishir.note3.engine.model.PaperStyle
import com.hashishir.note3.engine.model.PdfRef
import com.hashishir.note3.render.OverlayRenderer
import com.hashishir.note3.render.PageRenderer
import com.hashishir.note3.render.RenderPage
import kotlin.math.hypot
import kotlin.math.pow

/** Non-undoable page properties the view needs for its background. */
data class PageMeta(val paper: PaperStyle, val paperColor: Int, val pdf: PdfRef?)

/**
 * The drawing surface. A custom [View] (rather than Compose Canvas) gives direct access to batched
 * stylus history, tool types and pressure, and lets live drawing use a cached bitmap of the committed page.
 */
@SuppressLint("ViewConstructor")
class WhiteboardView(context: Context) : View(context) {

    private var session: DrawingSession? = null
    private var renderer: PageRenderer? = null
    private val overlay = OverlayRenderer()
    private val density = context.resources.displayMetrics.density

    var pageMeta: PageMeta = PageMeta(PaperStyle.BLANK, 0xFFFFFFFF.toInt(), null)
        set(v) {
            field = v
            cacheValid = false
            invalidate()
        }

    /** Called after the user pans or zooms so the host can remember the viewport. */
    var onViewportChanged: (() -> Unit)? = null

    // committed-page cache used while a stroke or shape preview is being drawn
    private var cache: Bitmap? = null
    private var cacheCanvas: Canvas? = null
    private var cacheValid = false
    private var cacheContent: Any? = null
    private var cacheScale = 0f
    private var cacheTx = 0f
    private var cacheTy = 0f
    private var cacheDisabled = false
    private var renderPage: RenderPage? = null
    private var renderPageContent: Any? = null

    private enum class Mode { NONE, DRAW, PAN, PINCH, IGNORE }

    private var mode = Mode.NONE
    private var activeId = -1
    private var lastX = 0f
    private var lastY = 0f
    private var pinchDist = 0f
    private var pinchCx = 0f
    private var pinchCy = 0f

    fun bind(session: DrawingSession, renderer: PageRenderer) {
        this.session = session
        this.renderer = renderer
        session.density = density
        session.setViewSize(width.toFloat(), height.toFloat())
        cacheValid = false
        invalidate()
    }

    /** Forces a full redraw, e.g. after an async image or PDF page finished loading. */
    fun refresh() {
        cacheValid = false
        invalidate()
    }

    // ------------------------------------------------------------------ viewport helpers

    fun fitTo(world: Rect) {
        val s = session ?: return
        s.viewport.fit(world, width.toFloat(), height.toFloat(), 24f * density)
        viewportChanged()
    }

    fun resetViewport() {
        val s = session ?: return
        s.viewport.scale = density
        s.viewport.tx = 0f
        s.viewport.ty = 0f
        viewportChanged()
    }

    fun zoomBy(factor: Float) {
        val s = session ?: return
        s.viewport.zoomAt(factor, width / 2f, height / 2f)
        viewportChanged()
    }

    private fun viewportChanged() {
        cacheValid = false
        onViewportChanged?.invoke()
        invalidate()
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        session?.setViewSize(w.toFloat(), h.toFloat())
        releaseCache()
    }

    override fun onDetachedFromWindow() {
        releaseCache()
        super.onDetachedFromWindow()
    }

    private fun releaseCache() {
        cache?.recycle()
        cache = null
        cacheCanvas = null
        cacheValid = false
    }

    // ------------------------------------------------------------------ drawing

    private fun currentRenderPage(s: DrawingSession): RenderPage {
        val c = s.content
        val rp = renderPage
        val meta = pageMeta
        if (rp != null && renderPageContent === c && rp.paper == meta.paper && rp.paperColor == meta.paperColor && rp.pdf == meta.pdf) return rp
        val n = RenderPage(meta.paper, meta.paperColor, meta.pdf, c.layers, c.elements)
        renderPage = n
        renderPageContent = c
        return n
    }

    private fun drawPage(canvas: Canvas, s: DrawingSession, r: PageRenderer) {
        val meta = pageMeta
        canvas.drawColor(if (meta.pdf != null) BACKDROP else meta.paperColor)
        val v = s.viewport
        canvas.save()
        canvas.translate(v.tx, v.ty)
        canvas.scale(v.scale, v.scale)
        val page = currentRenderPage(s)
        val visible = v.visibleWorld(width.toFloat(), height.toFloat())
        r.drawBackground(canvas, page, v.scale, visible)
        r.drawElements(canvas, page, v.scale, visible)
        canvas.restore()
    }

    private fun ensureCache(s: DrawingSession, r: PageRenderer): Bitmap? {
        if (cacheDisabled || width <= 0 || height <= 0) return null
        try {
            var b = cache
            if (b == null || b.width != width || b.height != height) {
                b?.recycle()
                b = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
                cache = b
                cacheCanvas = Canvas(b)
                cacheValid = false
            }
            val v = s.viewport
            val stale = !cacheValid || cacheContent !== s.content || cacheScale != v.scale || cacheTx != v.tx || cacheTy != v.ty
            if (stale) {
                drawPage(cacheCanvas!!, s, r)
                cacheContent = s.content
                cacheScale = v.scale; cacheTx = v.tx; cacheTy = v.ty
                cacheValid = true
            }
            return b
        } catch (_: OutOfMemoryError) {
            cacheDisabled = true
            releaseCache()
            return null
        }
    }

    override fun onDraw(canvas: Canvas) {
        val s = session ?: return
        val r = renderer ?: return
        val live = s.previewPoints.isNotEmpty() || s.previewShape != null
        val cached = if (live) ensureCache(s, r) else null
        if (cached != null) canvas.drawBitmap(cached, 0f, 0f, null) else drawPage(canvas, s, r)

        val v = s.viewport
        canvas.save()
        canvas.translate(v.tx, v.ty)
        canvas.scale(v.scale, v.scale)
        overlay.drawWorld(canvas, s, r, density)
        canvas.restore()
        overlay.drawScreen(canvas, s, density)
    }

    // ------------------------------------------------------------------ touch

    private fun kindOf(e: MotionEvent, index: Int): PointerKind = when (e.getToolType(index)) {
        MotionEvent.TOOL_TYPE_ERASER -> PointerKind.ERASER
        MotionEvent.TOOL_TYPE_STYLUS ->
            if (e.buttonState and MotionEvent.BUTTON_STYLUS_PRIMARY != 0) PointerKind.ERASER else PointerKind.STYLUS
        MotionEvent.TOOL_TYPE_MOUSE -> PointerKind.STYLUS
        else -> PointerKind.FINGER
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(e: MotionEvent): Boolean {
        val s = session ?: return false
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                val kind = kindOf(e, 0)
                activeId = e.getPointerId(0)
                lastX = e.x; lastY = e.y
                if (s.wantsPointer(kind)) {
                    mode = Mode.DRAW
                    s.pointerDown(e.x, e.y, e.pressure, kind, e.eventTime)
                } else {
                    mode = Mode.PAN
                }
            }
            MotionEvent.ACTION_POINTER_DOWN -> {
                val idx = e.actionIndex
                when (mode) {
                    Mode.DRAW -> {
                        val ai = e.findPointerIndex(activeId)
                        // A resting palm must not interrupt stylus writing.
                        if (ai >= 0 && kindOf(e, ai) != PointerKind.FINGER && kindOf(e, idx) == PointerKind.FINGER) return true
                        s.cancelGesture()
                        beginPinch(e)
                    }
                    Mode.PAN -> beginPinch(e)
                    Mode.PINCH -> beginPinch(e)
                    else -> {}
                }
            }
            MotionEvent.ACTION_MOVE -> when (mode) {
                Mode.DRAW -> {
                    val i = e.findPointerIndex(activeId)
                    if (i >= 0) {
                        for (h in 0 until e.historySize) {
                            s.pointerMove(e.getHistoricalX(i, h), e.getHistoricalY(i, h), e.getHistoricalPressure(i, h), e.getHistoricalEventTime(h))
                        }
                        s.pointerMove(e.getX(i), e.getY(i), e.getPressure(i), e.eventTime)
                    }
                }
                Mode.PAN -> {
                    val i = e.findPointerIndex(activeId)
                    if (i >= 0) {
                        s.viewport.panBy(e.getX(i) - lastX, e.getY(i) - lastY)
                        lastX = e.getX(i); lastY = e.getY(i)
                        viewportChanged()
                    }
                }
                Mode.PINCH -> if (e.pointerCount >= 2) updatePinch(e, s)
                else -> {}
            }
            MotionEvent.ACTION_POINTER_UP -> if (mode == Mode.PINCH) {
                if (e.pointerCount - 1 >= 2) {
                    beginPinch(e, skipIndex = e.actionIndex)
                } else {
                    mode = Mode.IGNORE // the remaining finger must not start a stroke
                }
            }
            MotionEvent.ACTION_UP -> {
                if (mode == Mode.DRAW) s.pointerUp(e.x, e.y, e.eventTime)
                mode = Mode.NONE
                parent?.requestDisallowInterceptTouchEvent(false)
            }
            MotionEvent.ACTION_CANCEL -> {
                if (mode == Mode.DRAW) s.cancelGesture()
                mode = Mode.NONE
            }
        }
        return true
    }

    private fun beginPinch(e: MotionEvent, skipIndex: Int = -1) {
        val idx = (0 until e.pointerCount).filter { it != skipIndex }.take(2)
        if (idx.size < 2) return
        pinchDist = hypot(e.getX(idx[0]) - e.getX(idx[1]), e.getY(idx[0]) - e.getY(idx[1])).coerceAtLeast(1f)
        pinchCx = (e.getX(idx[0]) + e.getX(idx[1])) / 2f
        pinchCy = (e.getY(idx[0]) + e.getY(idx[1])) / 2f
        mode = Mode.PINCH
    }

    private fun updatePinch(e: MotionEvent, s: DrawingSession) {
        val dist = hypot(e.getX(0) - e.getX(1), e.getY(0) - e.getY(1)).coerceAtLeast(1f)
        val cx = (e.getX(0) + e.getX(1)) / 2f
        val cy = (e.getY(0) + e.getY(1)) / 2f
        s.viewport.panBy(cx - pinchCx, cy - pinchCy)
        s.viewport.zoomAt(dist / pinchDist, cx, cy)
        pinchDist = dist; pinchCx = cx; pinchCy = cy
        viewportChanged()
    }

    /** Mouse wheel / trackpad scroll zooms around the pointer. */
    override fun onGenericMotionEvent(e: MotionEvent): Boolean {
        val s = session ?: return false
        if (e.actionMasked == MotionEvent.ACTION_SCROLL) {
            val dy = e.getAxisValue(MotionEvent.AXIS_VSCROLL)
            s.viewport.zoomAt(1.12f.pow(dy), e.x, e.y)
            viewportChanged()
            return true
        }
        return super.onGenericMotionEvent(e)
    }

    companion object {
        private const val BACKDROP = 0xFF5F6368.toInt()
    }
}
