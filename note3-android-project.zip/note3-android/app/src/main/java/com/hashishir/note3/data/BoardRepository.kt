package com.hashishir.note3.data

import androidx.room.withTransaction
import com.hashishir.note3.data.db.AppDatabase
import com.hashishir.note3.data.db.BoardEntity
import com.hashishir.note3.data.db.BoardSummary
import com.hashishir.note3.data.db.PageEntity
import com.hashishir.note3.engine.model.IdGen
import com.hashishir.note3.engine.model.Page
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.File
import java.io.InputStream
import java.io.OutputStream

data class ImportResult(val boards: Int, val skippedPages: Int)

/** Single entry point for boards and pages: Room holds structure, [PageStore] holds page content. */
class BoardRepository(
    private val db: AppDatabase,
    private val pages: PageStore,
    private val mediaDir: File
) {
    private val boardDao = db.boardDao()
    private val pageDao = db.pageDao()
    private val writeLock = Mutex()

    fun observeBoards(): Flow<List<BoardSummary>> = boardDao.observeSummaries()

    suspend fun boardTitle(id: String): String? = boardDao.get(id)?.title

    suspend fun createBoard(title: String, firstPage: Page): String = withContext(Dispatchers.IO) {
        writeLock.withLock {
            val now = System.currentTimeMillis()
            val id = IdGen.next()
            pages.save(firstPage)
            db.withTransaction {
                boardDao.insert(BoardEntity(id, title.ifBlank { "Untitled" }, now, now))
                pageDao.insert(PageEntity(firstPage.id, id, 0))
            }
            id
        }
    }

    suspend fun renameBoard(id: String, title: String) = withContext(Dispatchers.IO) {
        boardDao.rename(id, title.ifBlank { "Untitled" }, System.currentTimeMillis())
    }

    suspend fun deleteBoard(id: String) = withContext(Dispatchers.IO) {
        writeLock.withLock {
            val ids = pageDao.pagesOf(id).map { it.id }
            boardDao.delete(id) // pages rows cascade
            ids.forEach { pages.delete(it) }
            cleanOrphanMedia()
        }
    }

    suspend fun duplicateBoard(id: String): String? = withContext(Dispatchers.IO) {
        writeLock.withLock {
            val src = boardDao.get(id) ?: return@withLock null
            val newBoardId = IdGen.next()
            val now = System.currentTimeMillis()
            val copies = pageDao.pagesOf(id).mapNotNull { pe ->
                pages.load(pe.id)?.let { remapPageIds(it) }
            }
            if (copies.isEmpty()) return@withLock null
            copies.forEach { pages.save(it) }
            db.withTransaction {
                boardDao.insert(BoardEntity(newBoardId, src.title + " (copy)", now, now))
                copies.forEachIndexed { i, p -> pageDao.insert(PageEntity(p.id, newBoardId, i)) }
            }
            newBoardId
        }
    }

    // ------------------------------------------------------------------ pages

    suspend fun pageIds(boardId: String): List<String> = withContext(Dispatchers.IO) {
        pageDao.pagesOf(boardId).map { it.id }
    }

    suspend fun loadPage(id: String): Page? = withContext(Dispatchers.IO) { pages.load(id) }

    /** Saves page content and bumps the board's modification time. */
    suspend fun savePage(boardId: String, page: Page) = withContext(Dispatchers.IO) {
        writeLock.withLock {
            pages.save(page)
            boardDao.touch(boardId, System.currentTimeMillis())
        }
    }

    suspend fun addPage(boardId: String, page: Page, atIndex: Int): Unit = withContext(Dispatchers.IO) {
        writeLock.withLock {
            pages.save(page)
            val existing = pageDao.pagesOf(boardId)
            val order = existing.map { it.id }.toMutableList()
            val idx = atIndex.coerceIn(0, order.size)
            order.add(idx, page.id)
            db.withTransaction {
                pageDao.insert(PageEntity(page.id, boardId, idx))
                order.forEachIndexed { i, pid -> pageDao.setPosition(pid, i) }
            }
            boardDao.touch(boardId, System.currentTimeMillis())
        }
    }

    suspend fun deletePage(boardId: String, pageId: String) = withContext(Dispatchers.IO) {
        writeLock.withLock {
            val order = pageDao.pagesOf(boardId).map { it.id }
            if (order.size <= 1) return@withLock
            db.withTransaction {
                pageDao.delete(pageId)
                order.filter { it != pageId }.forEachIndexed { i, pid -> pageDao.setPosition(pid, i) }
            }
            pages.delete(pageId)
            boardDao.touch(boardId, System.currentTimeMillis())
            cleanOrphanMedia()
        }
    }

    suspend fun duplicatePage(boardId: String, pageId: String): String? = withContext(Dispatchers.IO) {
        writeLock.withLock {
            val src = pages.load(pageId) ?: return@withLock null
            val copy = remapPageIds(src)
            pages.save(copy)
            val order = pageDao.pagesOf(boardId).map { it.id }.toMutableList()
            val idx = order.indexOf(pageId) + 1
            order.add(idx, copy.id)
            db.withTransaction {
                pageDao.insert(PageEntity(copy.id, boardId, idx))
                order.forEachIndexed { i, pid -> pageDao.setPosition(pid, i) }
            }
            boardDao.touch(boardId, System.currentTimeMillis())
            copy.id
        }
    }

    suspend fun movePage(boardId: String, pageId: String, delta: Int) = withContext(Dispatchers.IO) {
        writeLock.withLock {
            val order = pageDao.pagesOf(boardId).map { it.id }.toMutableList()
            val i = order.indexOf(pageId)
            if (i < 0) return@withLock
            val j = (i + delta).coerceIn(0, order.size - 1)
            if (i == j) return@withLock
            order.add(j, order.removeAt(i))
            db.withTransaction { order.forEachIndexed { k, pid -> pageDao.setPosition(pid, k) } }
            boardDao.touch(boardId, System.currentTimeMillis())
        }
    }

    /** Gives every layer and element a fresh id so copies never collide with the original. */
    private fun remapPageIds(p: Page): Page {
        val layerMap = p.layers.associate { it.id to IdGen.next() }
        val groupMap = HashMap<String, String>()
        return p.copy(
            id = IdGen.next(),
            layers = p.layers.map { it.copy(id = layerMap.getValue(it.id)) },
            elements = p.elements.map { e ->
                e.withMeta(
                    id = IdGen.next(),
                    layerId = layerMap[e.layerId] ?: layerMap.values.first(),
                    groupId = e.groupId?.let { g -> groupMap.getOrPut(g) { IdGen.next() } }
                )
            }
        )
    }

    // ------------------------------------------------------------------ export / import

    /** Writes the given boards (or every board when [boardIds] is null) as an archive. Returns missing-media count. */
    suspend fun exportArchive(boardIds: Collection<String>?, out: OutputStream): Int = withContext(Dispatchers.IO) {
        writeLock.withLock {
            val ids = boardIds?.toList() ?: boardDao.allIds()
            val metas = ids.mapNotNull { id ->
                val b = boardDao.get(id) ?: return@mapNotNull null
                BoardMeta(b.id, b.title, b.createdAt, b.updatedAt, pageDao.pagesOf(id).map { it.id })
            }
            ArchiveIO.write(metas, { pages.load(it) }, mediaDir, JsonArchiveCodec, out)
        }
    }

    /**
     * Imports an archive as new boards (existing boards are never overwritten; ids are remapped).
     * Used for both project files and backup restore.
     */
    suspend fun importArchive(input: InputStream): ImportResult = withContext(Dispatchers.IO) {
        writeLock.withLock {
            val content = ArchiveIO.read(input, mediaDir, JsonArchiveCodec)
            var imported = 0
            for (meta in content.boards) {
                val loaded = meta.pageIds.mapNotNull { content.pages[it] }
                if (loaded.isEmpty()) continue
                val remapped = loaded.map { remapPageIds(it) }
                remapped.forEach { pages.save(it) }
                val newId = IdGen.next()
                db.withTransaction {
                    boardDao.insert(BoardEntity(newId, meta.title, meta.createdAt, System.currentTimeMillis()))
                    remapped.forEachIndexed { i, p -> pageDao.insert(PageEntity(p.id, newId, i)) }
                }
                imported++
            }
            ImportResult(imported, content.skippedPages)
        }
    }

    // ------------------------------------------------------------------ housekeeping

    /** Deletes media files no page references any more. Runs after deletions. */
    private suspend fun cleanOrphanMedia() {
        val referenced = HashSet<String>()
        for (b in boardDao.allIds()) for (pe in pageDao.pagesOf(b)) {
            pages.load(pe.id)?.let { referenced.addAll(ArchiveIO.mediaFilesOf(it)) }
        }
        mediaDir.listFiles()?.forEach { f ->
            if (f.isFile && f.name !in referenced && !f.name.endsWith(".part") && !f.name.startsWith("rec_")) f.delete()
        }
    }
}
