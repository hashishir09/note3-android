package com.hashishir.note3.render

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.media.MediaMetadataRetriever
import com.hashishir.note3.data.MediaFiles
import com.hashishir.note3.engine.math.Rect
import com.hashishir.note3.engine.math.Vec
import com.hashishir.note3.engine.model.Element
import com.hashishir.note3.engine.model.ImageElement
import com.hashishir.note3.engine.model.Layer
import com.hashishir.note3.engine.model.MediaElement
import com.hashishir.note3.engine.model.MediaKind
import com.hashishir.note3.engine.model.PaperStyle
import com.hashishir.note3.engine.model.PdfRef
import com.hashishir.note3.engine.model.Pt
import com.hashishir.note3.engine.model.ShapeElement
import com.hashishir.note3.engine.model.ShapeKind
import com.hashishir.note3.engine.model.StrokeElement
import com.hashishir.note3.engine.model.StrokeTool
import com.hashishir.note3.engine.model.TextElement
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.hypot

/** What the renderer needs to know about a page. */
class RenderPage(
    val paper: PaperStyle,
    val paperColor: Int,
    val pdf: PdfRef?,
    val layers: List<Layer>,
    val elements: List<Element>
)

/** Shared, long-lived rendering resources. [blocking] makes loads synchronous (used for export). */
class RenderResources(
    val media: MediaFiles,
    val pdfPages: PdfPages,
    val bitmaps: AsyncBitmapCache,
    val blocking: Boolean = false
) {
    fun bitmap(key: String, loader: () -> Bitmap?): Bitmap? =
        if (blocking) bitmaps.getBlocking(loader) else bitmaps.get(key, loader)

    fun withBlocking(): RenderResources = RenderResources(media, pdfPages, bitmaps, true)
}

/**
 * Draws a page in world coordinates. The caller applies the viewport transform to the canvas first
 * and passes the visible world rectangle for culling. Contains no Android View code so it is shared
 * by the on-screen view and by the PNG/JPG/PDF exporters.
 */
class PageRenderer(private val res: RenderResources) {

    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val gridPaint = Paint().apply { style = Paint.Style.STROKE }
    private val bmpPaint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val tmpMatrix = Matrix()
    private val tmpRect = RectF()
    private var gridBuf = FloatArray(0)

    // ------------------------------------------------------------------ background

    fun drawBackground(canvas: Canvas, page: RenderPage, scale: Float, visible: Rect) {
        val pdf = page.pdf
        if (pdf != null) {
            drawPdf(canvas, pdf, scale)
            return
        }
        if (page.paper == PaperStyle.BLANK) return
        val dark = luminance(page.paperColor) < 0.45f
        val base = if (dark) 0xFFFFFF else 0x000000
        val spacing = niceSpacing(40f, scale)
        when (page.paper) {
            PaperStyle.GRID -> {
                gridPaint.color = base or (0x30 shl 24)
                gridPaint.strokeWidth = max(1f / scale, 0.5f / scale)
                drawGridLines(canvas, visible, spacing, vertical = true)
                drawGridLines(canvas, visible, spacing, vertical = false)
            }
            PaperStyle.LINES -> {
                gridPaint.color = base or (0x30 shl 24)
                gridPaint.strokeWidth = 1f / scale
                drawGridLines(canvas, visible, niceSpacing(48f, scale), vertical = false)
            }
            PaperStyle.DOTS -> drawDots(canvas, visible, spacing, scale, base or (0x66 shl 24))
            PaperStyle.BLANK -> {}
        }
    }

    private fun niceSpacing(base: Float, scale: Float): Float {
        var s = base
        while (s * scale < 14f) s *= 2f
        return s
    }

    private fun drawGridLines(canvas: Canvas, v: Rect, spacing: Float, vertical: Boolean) {
        val from = if (vertical) v.left else v.top
        val to = if (vertical) v.right else v.bottom
        var t = floor(from / spacing) * spacing
        val n = (((to - t) / spacing).toInt() + 2).coerceAtMost(600)
        if (gridBuf.size < n * 4) gridBuf = FloatArray(n * 4)
        var i = 0
        var count = 0
        while (t <= to && count < n) {
            if (vertical) {
                gridBuf[i++] = t; gridBuf[i++] = v.top; gridBuf[i++] = t; gridBuf[i++] = v.bottom
            } else {
                gridBuf[i++] = v.left; gridBuf[i++] = t; gridBuf[i++] = v.right; gridBuf[i++] = t
            }
            t += spacing
            count++
        }
        canvas.drawLines(gridBuf, 0, count * 4, gridPaint)
    }

    private fun drawDots(canvas: Canvas, v: Rect, spacing: Float, scale: Float, color: Int) {
        val x0 = floor(v.left / spacing) * spacing
        val y0 = floor(v.top / spacing) * spacing
        val cols = (((v.right - x0) / spacing).toInt() + 2).coerceAtMost(80)
        val rows = (((v.bottom - y0) / spacing).toInt() + 2).coerceAtMost(160)
        val need = cols * rows * 2
        if (gridBuf.size < need) gridBuf = FloatArray(need)
        var i = 0
        for (r in 0 until rows) for (c in 0 until cols) {
            gridBuf[i++] = x0 + c * spacing
            gridBuf[i++] = y0 + r * spacing
        }
        gridPaint.color = color
        gridPaint.strokeCap = Paint.Cap.ROUND
        gridPaint.strokeWidth = 3.5f / scale
        canvas.drawPoints(gridBuf, 0, i, gridPaint)
        gridPaint.strokeCap = Paint.Cap.BUTT
    }

    private fun drawPdf(canvas: Canvas, pdf: PdfRef, scale: Float) {
        fillPaint.color = 0x33000000
        canvas.drawRect(4f / scale, 6f / scale, pdf.width + 4f / scale, pdf.height + 6f / scale, fillPaint)
        fillPaint.color = Color.WHITE
        canvas.drawRect(0f, 0f, pdf.width, pdf.height, fillPaint)
        val wanted = pdf.width * scale
        val bucket = PDF_BUCKETS.firstOrNull { it >= wanted } ?: PDF_BUCKETS.last()
        val file = try { res.media.file(pdf.file) } catch (_: IllegalArgumentException) { return }
        val key = "pdf|${pdf.file}|${pdf.pageIndex}|$bucket"
        // While a sharper version loads, keep showing any lower-resolution one already cached.
        val bmp = res.bitmap(key) { res.pdfPages.render(file, pdf.pageIndex, bucket) }
            ?: PDF_BUCKETS.filter { it < bucket }.reversed().firstNotNullOfOrNull {
                res.bitmaps.peek("pdf|${pdf.file}|${pdf.pageIndex}|$it")
            }
        if (bmp != null) {
            tmpRect.set(0f, 0f, pdf.width, pdf.height)
            canvas.drawBitmap(bmp, null, tmpRect, bmpPaint)
        }
    }

    // ------------------------------------------------------------------ elements

    fun drawElements(canvas: Canvas, page: RenderPage, scale: Float, visible: Rect) {
        val layers = page.layers
        if (layers.size == 1) {
            val l = layers[0]
            if (!l.visible) return
            for (e in page.elements) if (e.layerId == l.id) drawElement(canvas, e, scale, visible)
            return
        }
        for (l in layers) {
            if (!l.visible) continue
            for (e in page.elements) if (e.layerId == l.id) drawElement(canvas, e, scale, visible)
        }
    }

    fun drawElement(canvas: Canvas, e: Element, scale: Float, visible: Rect) {
        when (e) {
            is StrokeElement -> {
                if (!cheapBounds(e).intersects(visible)) return
                drawStroke(canvas, e.points, e.color, e.width, e.tool, scale)
            }
            is ShapeElement -> {
                if (!e.bounds().intersects(visible)) return
                drawShape(canvas, e, scale)
            }
            is TextElement -> {
                if (!e.bounds().intersects(visible)) return
                drawText(canvas, e)
            }
            is ImageElement -> {
                if (!e.bounds().intersects(visible)) return
                drawImage(canvas, e, scale)
            }
            is MediaElement -> {
                if (!e.bounds().intersects(visible)) return
                drawMedia(canvas, e, scale)
            }
        }
    }

    private fun cheapBounds(s: StrokeElement): Rect {
        val pts = s.points
        if (pts.isEmpty()) return Rect(0f, 0f, 0f, 0f)
        var l = pts[0].x; var t = pts[0].y; var r = l; var b = t
        for (i in 1 until pts.size) {
            val p = pts[i]
            if (p.x < l) l = p.x; if (p.x > r) r = p.x
            if (p.y < t) t = p.y; if (p.y > b) b = p.y
        }
        val pad = s.width
        return Rect(l - pad, t - pad, r + pad, b + pad)
    }

    /** Pressure-sensitive stroke. Uniform strokes become one smooth path; others are drawn per segment. */
    fun drawStroke(canvas: Canvas, pts: List<Pt>, color: Int, width: Float, tool: StrokeTool, scale: Float) {
        if (pts.isEmpty()) return
        strokePaint.color = color
        val minW = 0.6f / scale
        if (pts.size < 2) {
            fillPaint.color = color
            canvas.drawCircle(pts[0].x, pts[0].y, max(width / 2f, minW / 2f), fillPaint)
            return
        }
        if (tool == StrokeTool.HIGHLIGHTER) {
            strokePaint.strokeWidth = max(width, minW)
            strokePaint.strokeCap = Paint.Cap.SQUARE
            buildSmoothPath(pts)
            canvas.drawPath(path, strokePaint)
            strokePaint.strokeCap = Paint.Cap.ROUND
            return
        }
        var pMin = Float.MAX_VALUE
        var pMax = 0f
        for (p in pts) {
            if (p.p < pMin) pMin = p.p
            if (p.p > pMax) pMax = p.p
        }
        if (pMax - pMin < 0.06f) {
            strokePaint.strokeWidth = max(width * widthFactor(pMax), minW)
            buildSmoothPath(pts)
            canvas.drawPath(path, strokePaint)
            return
        }
        // Variable width: a round-capped segment per interval, width eased between its end points.
        var prev = pts[0]
        var prevW = width * widthFactor(prev.p)
        for (i in 1 until pts.size) {
            val cur = pts[i]
            val w = width * widthFactor(cur.p)
            strokePaint.strokeWidth = max((prevW + w) / 2f, minW)
            canvas.drawLine(prev.x, prev.y, cur.x, cur.y, strokePaint)
            prev = cur
            prevW = w
        }
    }

    private fun widthFactor(pressure: Float): Float = 0.35f + 0.65f * min(pressure, 1.2f)

    private fun buildSmoothPath(pts: List<Pt>) {
        path.rewind()
        path.moveTo(pts[0].x, pts[0].y)
        if (pts.size == 2) {
            path.lineTo(pts[1].x, pts[1].y)
            return
        }
        for (i in 1 until pts.size - 1) {
            val a = pts[i]
            val b = pts[i + 1]
            path.quadTo(a.x, a.y, (a.x + b.x) / 2f, (a.y + b.y) / 2f)
        }
        val last = pts[pts.size - 1]
        path.lineTo(last.x, last.y)
    }

    private fun drawShape(canvas: Canvas, s: ShapeElement, scale: Float) {
        val outline = s.outline(64)
        if (outline.size < 2) return
        path.rewind()
        path.moveTo(outline[0].x, outline[0].y)
        for (i in 1 until outline.size) path.lineTo(outline[i].x, outline[i].y)
        if (s.fillColor != 0 && s.isClosed) {
            fillPaint.color = s.fillColor
            canvas.drawPath(path, fillPaint)
        }
        strokePaint.color = s.color
        strokePaint.strokeWidth = max(s.width, 0.6f / scale)
        canvas.drawPath(path, strokePaint)
        if (s.kind == ShapeKind.ARROW && s.pts.size >= 2) drawArrowHead(canvas, s, scale)
    }

    private fun drawArrowHead(canvas: Canvas, s: ShapeElement, scale: Float) {
        val a: Vec = s.pts[0]
        val b: Vec = s.pts[1]
        val len = hypot(b.x - a.x, b.y - a.y)
        if (len < 1e-3f) return
        val head = min(max(s.width * 5f, 18f), len * 0.6f)
        val ang = atan2(b.y - a.y, b.x - a.x)
        val spread = 0.45f
        path.rewind()
        path.moveTo(b.x, b.y)
        path.lineTo(b.x - head * cos(ang - spread), b.y - head * sin(ang - spread))
        path.moveTo(b.x, b.y)
        path.lineTo(b.x - head * cos(ang + spread), b.y - head * sin(ang + spread))
        strokePaint.color = s.color
        strokePaint.strokeWidth = max(s.width, 0.6f / scale)
        canvas.drawPath(path, strokePaint)
    }

    private fun drawText(canvas: Canvas, t: TextElement) {
        val layout = TextLayouts.layout(t.text, t.fontSize, t.color, t.w)
        canvas.save()
        canvas.translate(t.ox, t.oy)
        canvas.rotate(Math.toDegrees(t.rotation.toDouble()).toFloat())
        layout.draw(canvas)
        canvas.restore()
    }

    private fun drawImage(canvas: Canvas, e: ImageElement, scale: Float) {
        val onScreen = max(e.w, e.h) * scale
        val bucket = IMAGE_BUCKETS.firstOrNull { it >= onScreen } ?: IMAGE_BUCKETS.last()
        val key = "img|${e.file}|$bucket"
        val bmp = res.bitmap(key) { res.media.decodeSampled(e.file, bucket) }
            ?: IMAGE_BUCKETS.filter { it < bucket }.reversed().firstNotNullOfOrNull { res.bitmaps.peek("img|${e.file}|$it") }
        canvas.save()
        canvas.translate(e.ox, e.oy)
        canvas.rotate(Math.toDegrees(e.rotation.toDouble()).toFloat())
        if (bmp != null) {
            tmpRect.set(0f, 0f, e.w, e.h)
            canvas.drawBitmap(bmp, null, tmpRect, bmpPaint)
        } else {
            fillPaint.color = 0x22888888
            canvas.drawRect(0f, 0f, e.w, e.h, fillPaint)
        }
        canvas.restore()
    }

    private fun drawMedia(canvas: Canvas, e: MediaElement, scale: Float) {
        canvas.save()
        canvas.translate(e.ox, e.oy)
        canvas.rotate(Math.toDegrees(e.rotation.toDouble()).toFloat())
        val thumb = if (e.kind == MediaKind.VIDEO) {
            res.bitmap("vid|${e.file}") { videoThumbnail(e.file) }
        } else null
        tmpRect.set(0f, 0f, e.w, e.h)
        fillPaint.color = if (e.kind == MediaKind.VIDEO) 0xFF202124.toInt() else 0xFF2F4858.toInt()
        canvas.drawRoundRect(tmpRect, e.h * 0.08f, e.h * 0.08f, fillPaint)
        if (thumb != null) canvas.drawBitmap(thumb, null, tmpRect, bmpPaint)
        // play badge
        val r = min(e.w, e.h) * 0.22f
        val cx = e.w / 2f
        val cy = e.h / 2f
        fillPaint.color = 0xCCFFFFFF.toInt()
        canvas.drawCircle(cx, cy, r, fillPaint)
        fillPaint.color = 0xFF202124.toInt()
        path.rewind()
        path.moveTo(cx - r * 0.3f, cy - r * 0.5f)
        path.lineTo(cx + r * 0.55f, cy)
        path.lineTo(cx - r * 0.3f, cy + r * 0.5f)
        path.close()
        canvas.drawPath(path, fillPaint)
        // caption
        val tp = captionPaint
        tp.textSize = max(10f, min(e.h * 0.12f, 26f))
        val label = (if (e.kind == MediaKind.VIDEO) "Video: " else "Audio: ") + e.name
        val shown = android.text.TextUtils.ellipsize(label, android.text.TextPaint(tp), e.w - 16f, android.text.TextUtils.TruncateAt.END)
        canvas.drawText(shown.toString(), 8f, e.h - tp.textSize * 0.5f, tp)
        canvas.restore()
    }

    private val captionPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }

    private fun videoThumbnail(file: String): Bitmap? {
        val f = res.media.file(file)
        if (!f.isFile) return null
        val r = MediaMetadataRetriever()
        return try {
            r.setDataSource(f.path)
            r.getFrameAtTime(0, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)?.let {
                val s = 480f / max(it.width, it.height)
                if (s < 1f) Bitmap.createScaledBitmap(it, (it.width * s).toInt().coerceAtLeast(1), (it.height * s).toInt().coerceAtLeast(1), true) else it
            }
        } catch (_: Exception) {
            null
        } finally {
            runCatching { r.release() }
        }
    }

    companion object {
        val PDF_BUCKETS = intArrayOf(600, 1000, 1500, 2000).toList()
        val IMAGE_BUCKETS = intArrayOf(256, 512, 1024, 2048).toList()

        fun luminance(color: Int): Float =
            (0.299f * Color.red(color) + 0.587f * Color.green(color) + 0.114f * Color.blue(color)) / 255f
    }
}
