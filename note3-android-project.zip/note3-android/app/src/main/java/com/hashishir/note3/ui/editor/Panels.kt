package com.hashishir.note3.ui.editor

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.unit.dp
import com.hashishir.note3.data.AppSettings
import com.hashishir.note3.engine.GeoKind
import com.hashishir.note3.engine.RecognizeMode
import com.hashishir.note3.engine.Tool
import com.hashishir.note3.engine.model.ShapeKind
import com.hashishir.note3.ui.components.ChoiceChips
import com.hashishir.note3.ui.components.ColorRow
import com.hashishir.note3.ui.components.PaperPicker
import com.hashishir.note3.ui.components.ScrollRow
import com.hashishir.note3.ui.components.SectionLabel
import com.hashishir.note3.ui.components.TouchTarget

/** Launchers for system pickers, created once in the screen and handed to the panels. */
class PickerActions(
    val image: () -> Unit,
    val pdf: () -> Unit,
    val audio: () -> Unit,
    val video: () -> Unit
)

private val PEN_TOOLS = setOf(Tool.PEN, Tool.BRUSH, Tool.HIGHLIGHTER)

@Composable
private fun PanelButton(text: String, enabled: Boolean = true, primary: Boolean = false, onClick: () -> Unit) {
    val m = Modifier.heightIn(min = TouchTarget)
    if (primary) Button(onClick = onClick, enabled = enabled, modifier = m) { Text(text) }
    else OutlinedButton(onClick = onClick, enabled = enabled, modifier = m) { Text(text) }
}

@Composable
private fun SwitchLine(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth().heightIn(min = TouchTarget).clickable { onChange(!checked) },
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, Modifier.weight(1f), style = MaterialTheme.typography.bodyLarge)
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun StrokePreview(color: Int, widthDp: Float) {
    Canvas(Modifier.fillMaxWidth().height(28.dp)) {
        drawLine(
            color = Color(color or (0xFF shl 24)).copy(alpha = ((color ushr 24) and 0xFF).let { if (it == 0) 1f else it / 255f }),
            start = Offset(16.dp.toPx(), size.height / 2f),
            end = Offset(size.width - 16.dp.toPx(), size.height / 2f),
            strokeWidth = widthDp.dp.toPx().coerceAtMost(size.height),
            cap = StrokeCap.Round
        )
    }
}

// ---------------------------------------------------------------------- draw

@Composable
fun DrawPanel(vm: EditorViewModel, ui: EditorUi, app: AppSettings, onCustomColor: () -> Unit) {
    val s = ui.settings
    SectionLabel("Tool")
    ChoiceChips(
        listOf(
            "Pen" to Tool.PEN, "Brush" to Tool.BRUSH, "Marker" to Tool.HIGHLIGHTER,
            "Erase stroke" to Tool.ERASER_STROKE, "Erase part" to Tool.ERASER_PARTIAL, "Pan" to Tool.HAND
        ),
        s.tool, { t -> vm.updateTool { it.copy(tool = t) } }
    )
    if (s.tool in PEN_TOOLS) {
        SectionLabel("Color")
        ColorRow(s.color, { c -> vm.updateTool { it.copy(color = c) } }, onCustomColor)
        SectionLabel("Width: ${"%.0f".format(s.width)}")
        Slider(
            value = s.width,
            onValueChange = { w -> vm.updateTool { it.withWidth(w) } },
            valueRange = if (s.tool == Tool.HIGHLIGHTER) 8f..60f else 1f..40f
        )
        StrokePreview(s.inkColor, s.width)
        if (s.tool != Tool.HIGHLIGHTER) {
            SectionLabel("Shape recognition")
            ChoiceChips(
                listOf("Off" to RecognizeMode.OFF, "Hold at end" to RecognizeMode.HOLD, "Always" to RecognizeMode.ALWAYS),
                s.recognize, { r -> vm.updateAppSettings { it.copy(recognize = r) } }
            )
            if (s.recognize == RecognizeMode.HOLD) {
                Text("Draw a shape and keep the pen still for half a second before lifting.", style = MaterialTheme.typography.bodySmall)
            }
        }
    } else if (s.tool == Tool.ERASER_PARTIAL || s.tool == Tool.ERASER_STROKE) {
        Text(
            if (s.tool == Tool.ERASER_PARTIAL) "Erases only the part of a stroke you touch." else "Removes whole strokes and shapes you touch.",
            style = MaterialTheme.typography.bodyMedium, modifier = Modifier.padding(top = 8.dp)
        )
        SectionLabel("Eraser size: ${app.eraserRadiusDp.toInt()}")
        Slider(
            value = app.eraserRadiusDp,
            onValueChange = { r -> vm.updateAppSettings { it.copy(eraserRadiusDp = r) } },
            valueRange = 8f..48f
        )
    } else if (s.tool == Tool.HAND) {
        Text("Drag to move the canvas. Pinch with two fingers to zoom in any tool.", style = MaterialTheme.typography.bodyMedium, modifier = Modifier.padding(top = 8.dp))
    }
    SwitchLine("Draw with finger (off = stylus only)", app.fingerDraws) { v -> vm.updateAppSettings { it.copy(fingerDraws = v) } }

    SectionLabel("Geometry aids")
    ScrollRow {
        for ((label, kind) in listOf("Ruler" to GeoKind.RULER, "Set square" to GeoKind.SET_SQUARE, "Protractor" to GeoKind.PROTRACTOR)) {
            FilterChip(
                selected = kind in ui.geometry,
                onClick = { vm.toggleGeometry(kind) },
                label = { Text(label) },
                modifier = Modifier.height(TouchTarget)
            )
        }
    }
    if (ui.geometry.isNotEmpty()) {
        Text("Drag the white dot to move, the orange dot to rotate or resize. Draw along an edge to get a straight line.", style = MaterialTheme.typography.bodySmall)
    }
}

// ---------------------------------------------------------------------- shapes & text

@Composable
fun ShapesPanel(vm: EditorViewModel, ui: EditorUi, onCustomColor: () -> Unit) {
    val s = ui.settings
    val isShape = s.tool == Tool.SHAPE
    SectionLabel("Shape")
    ChoiceChips(
        listOf(
            "Line" to ShapeKind.LINE, "Arrow" to ShapeKind.ARROW, "Circle" to ShapeKind.ELLIPSE,
            "Rectangle" to ShapeKind.RECT, "Triangle" to ShapeKind.TRIANGLE, "Polygon" to ShapeKind.POLYGON
        ),
        if (isShape) s.shapeKind else null,
        { k -> if (k != null) vm.updateTool { it.copy(tool = Tool.SHAPE, shapeKind = k) } }
    )
    if (isShape && s.shapeKind == ShapeKind.POLYGON) {
        Text(
            "Tap to place corners. Tap the first corner again, or press Close polygon, to finish.",
            style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 4.dp)
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            PanelButton("Close polygon (${ui.polygonPoints})", enabled = ui.polygonPoints >= 3, primary = true) { vm.session.finishPolygon() }
            PanelButton("Cancel", enabled = ui.polygonPoints > 0) { vm.session.cancelPolygon(); vm.updateTool { it } }
        }
    }
    SectionLabel("Text")
    ChoiceChips(
        listOf("Text tool" to Tool.TEXT),
        if (s.tool == Tool.TEXT) Tool.TEXT else null,
        { t -> if (t != null) vm.updateTool { it.copy(tool = t) } }
    )
    if (s.tool == Tool.TEXT) {
        Text("Tap the canvas to type. In Select mode, double-tap a text box to edit it.", style = MaterialTheme.typography.bodySmall)
    }
    SectionLabel("Color")
    ColorRow(s.color, { c -> vm.updateTool { it.copy(color = c) } }, onCustomColor)
    if (isShape) {
        SectionLabel("Line width: ${"%.0f".format(s.penWidth)}")
        Slider(value = s.penWidth, onValueChange = { w -> vm.updateTool { it.copy(penWidth = w) } }, valueRange = 1f..24f)
        SwitchLine("Fill closed shapes", s.fillShapes) { v -> vm.updateTool { it.copy(fillShapes = v) } }
        SwitchLine("Snap to grid", s.snapToGrid) { v -> vm.updateTool { it.copy(snapToGrid = v) } }
    }
    if (s.tool == Tool.TEXT) {
        SectionLabel("Text size: ${"%.0f".format(s.textSize)}")
        Slider(value = s.textSize, onValueChange = { w -> vm.updateTool { it.copy(textSize = w) } }, valueRange = 14f..120f)
    }
}

// ---------------------------------------------------------------------- select

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SelectPanel(vm: EditorViewModel, ui: EditorUi, onLayers: () -> Unit) {
    val sess = vm.session
    val has = ui.selectionCount > 0
    SectionLabel("Selection")
    ChoiceChips(
        listOf("Select / lasso" to Tool.SELECT),
        if (ui.settings.tool == Tool.SELECT) Tool.SELECT else null,
        { t -> if (t != null) vm.updateTool { it.copy(tool = t) } }
    )
    Text(
        if (has) "${ui.selectionCount} selected. Drag to move; corners resize; the top handle rotates."
        else "Tap an item, or draw a loop around items to select them.",
        style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(vertical = 4.dp)
    )
    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
        PanelButton("Copy", has) { sess.copy() }
        PanelButton("Cut", has) { sess.cut() }
        PanelButton("Paste", ui.canPaste) { sess.paste() }
        PanelButton("Duplicate", has) { sess.duplicate() }
        PanelButton("Delete", has) { sess.deleteSelection() }
        PanelButton("Group", ui.selectionCount >= 2) { sess.group() }
        PanelButton("Ungroup", ui.selectionGrouped) { sess.ungroup() }
        PanelButton("Bring to front", has) { sess.bringToFront() }
        PanelButton("Send to back", has) { sess.sendToBack() }
        PanelButton("Select all") { sess.selectAll() }
        PanelButton("Deselect", has) { sess.clearSelection() }
        PanelButton("Layers…") { onLayers() }
    }
}

// ---------------------------------------------------------------------- insert

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun InsertPanel(vm: EditorViewModel, ui: EditorUi, pick: PickerActions) {
    SectionLabel("Insert")
    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
        PanelButton("Image") { pick.image() }
        PanelButton("PDF to annotate") { pick.pdf() }
        PanelButton("Audio") { pick.audio() }
        PanelButton("Video") { pick.video() }
        PanelButton("Text box") { vm.addTextBoxAtCenter() }
    }
    Text(
        "Double-tap an audio or video item in Select mode to play it.",
        style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 4.dp)
    )
    if (!ui.isPdfPage) PaperPicker(ui.paper, ui.paperColor) { p, c -> vm.setPaper(p, c) }
    else Text("This page is a PDF; annotations are drawn on top of it.", style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 8.dp))
    SectionLabel("View")
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        PanelButton("Zoom in") { vm.zoom(1.4f) }
        PanelButton("Zoom out") { vm.zoom(1f / 1.4f) }
        PanelButton("Fit") { vm.fitContent() }
    }
}

// ---------------------------------------------------------------------- pages

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun PagesPanel(vm: EditorViewModel, ui: EditorUi, onLayers: () -> Unit, onDeletePage: () -> Unit) {
    SectionLabel("Page ${ui.pageIndex + 1} of ${ui.pageCount}")
    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        itemsIndexed(List(ui.pageCount) { it }) { _, i ->
            FilterChip(
                selected = i == ui.pageIndex,
                onClick = { vm.goToPage(i) },
                label = { Text("${i + 1}") },
                modifier = Modifier.height(TouchTarget)
            )
        }
    }
    Spacer(Modifier.height(8.dp))
    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
        PanelButton("Previous", ui.pageIndex > 0) { vm.goToPage(ui.pageIndex - 1) }
        PanelButton("Next", ui.pageIndex < ui.pageCount - 1) { vm.goToPage(ui.pageIndex + 1) }
        PanelButton("Add page", primary = true) { vm.addPage() }
        PanelButton("Duplicate") { vm.duplicatePage() }
        PanelButton("Move earlier", ui.pageIndex > 0) { vm.movePage(-1) }
        PanelButton("Move later", ui.pageIndex < ui.pageCount - 1) { vm.movePage(1) }
        PanelButton("Delete page", ui.pageCount > 1) { onDeletePage() }
        PanelButton("Layers…") { onLayers() }
    }
}
