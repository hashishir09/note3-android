package com.hashishir.note3.data

import com.hashishir.note3.engine.model.Page
import kotlinx.serialization.json.Json

val AppJson: Json = Json {
    ignoreUnknownKeys = true
    encodeDefaults = true
}

/** Production codec used for `.n3wb` files and backups. */
object JsonArchiveCodec : ArchiveCodec {
    override fun encodePage(page: Page): String = AppJson.encodeToString(Page.serializer(), page)
    override fun decodePage(text: String): Page = AppJson.decodeFromString(Page.serializer(), text)
    override fun encodeManifest(m: ArchiveManifest): String =
        AppJson.encodeToString(ArchiveManifest.serializer(), m)

    override fun decodeManifest(text: String): ArchiveManifest =
        AppJson.decodeFromString(ArchiveManifest.serializer(), text)
}
