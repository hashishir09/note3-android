package com.hashishir.note3.ui.home

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.hashishir.note3.Note3App
import com.hashishir.note3.data.AppSettings
import com.hashishir.note3.data.ArchiveException
import com.hashishir.note3.data.db.BoardSummary
import com.hashishir.note3.engine.model.Page
import com.hashishir.note3.engine.model.PaperStyle
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class HomeViewModel(app: Application) : AndroidViewModel(app) {

    private val container = (app as Note3App).container
    private val repo = container.repository

    val boards: StateFlow<List<BoardSummary>?> = repo.observeBoards()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), null)

    val settings: StateFlow<AppSettings> = container.settings.flow

    private val _busy = MutableStateFlow<String?>(null)
    val busy: StateFlow<String?> = _busy

    private val _messages = MutableSharedFlow<String>(extraBufferCapacity = 16)
    val messages: SharedFlow<String> = _messages

    /** Emits the id of a freshly created board so the UI can open it. */
    private val _created = MutableSharedFlow<String>(extraBufferCapacity = 4)
    val created: SharedFlow<String> = _created

    fun updateSettings(f: (AppSettings) -> AppSettings) = container.settings.update(f)

    fun createBoard(title: String, paper: PaperStyle, paperColor: Int) {
        viewModelScope.launch {
            try {
                val id = repo.createBoard(title, Page.blank(paperColor).copy(paper = paper))
                _created.tryEmit(id)
            } catch (e: Exception) {
                _messages.tryEmit("Could not create the board: ${e.message ?: "storage error"}")
            }
        }
    }

    fun rename(id: String, title: String) {
        viewModelScope.launch { repo.renameBoard(id, title) }
    }

    fun delete(id: String) {
        viewModelScope.launch {
            container.awaitSaves()
            repo.deleteBoard(id)
        }
    }

    fun duplicate(id: String) {
        viewModelScope.launch {
            container.awaitSaves()
            if (repo.duplicateBoard(id) == null) _messages.tryEmit("Could not duplicate this board.")
        }
    }

    private suspend fun <T> busy(label: String, block: suspend () -> T): T {
        _busy.value = label
        try {
            return block()
        } finally {
            _busy.value = null
        }
    }

    /** Exports one board (project file) or all boards (backup) to the chosen document. */
    fun export(uri: Uri, boardId: String?, label: String) {
        viewModelScope.launch {
            try {
                val missing = busy(label) {
                    container.awaitSaves()
                    withContext(Dispatchers.IO) {
                        val out = getApplication<Application>().contentResolver.openOutputStream(uri, "w")
                            ?: throw IllegalStateException("Cannot write to the chosen location")
                        out.use { repo.exportArchive(boardId?.let { listOf(it) }, it) }
                    }
                }
                _messages.tryEmit(if (missing > 0) "Saved ($missing media file(s) were missing)." else "Saved successfully.")
            } catch (e: Exception) {
                _messages.tryEmit("Could not save the file: ${e.message ?: "unknown error"}")
            }
        }
    }

    /** Imports a project file or restores a backup; imported boards are added, nothing is overwritten. */
    fun import(uri: Uri) {
        viewModelScope.launch {
            try {
                val r = busy("Importing…") {
                    withContext(Dispatchers.IO) {
                        val input = getApplication<Application>().contentResolver.openInputStream(uri)
                            ?: throw IllegalStateException("Cannot open the selected file")
                        input.use { repo.importArchive(it) }
                    }
                }
                _messages.tryEmit(
                    when {
                        r.boards == 0 -> "The file contained no boards."
                        r.skippedPages > 0 -> "Imported ${r.boards} board(s); ${r.skippedPages} damaged page(s) were skipped."
                        else -> "Imported ${r.boards} board(s)."
                    }
                )
            } catch (e: ArchiveException) {
                _messages.tryEmit(e.message ?: "The file could not be imported.")
            } catch (e: Exception) {
                _messages.tryEmit("Import failed: ${e.message ?: "unknown error"}")
            }
        }
    }
}
