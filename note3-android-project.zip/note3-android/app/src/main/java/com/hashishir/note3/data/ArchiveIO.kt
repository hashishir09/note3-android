package com.hashishir.note3.data

import com.hashishir.note3.engine.model.ImageElement
import com.hashishir.note3.engine.model.MediaElement
import com.hashishir.note3.engine.model.Page
import kotlinx.serialization.Serializable
import java.io.File
import java.io.InputStream
import java.io.OutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

@Serializable
data class BoardMeta(
    val id: String,
    val title: String,
    val createdAt: Long,
    val updatedAt: Long,
    val pageIds: List<String>
)

@Serializable
data class ArchiveManifest(
    val format: String = ArchiveIO.FORMAT,
    val version: Int = ArchiveIO.VERSION,
    val boards: List<BoardMeta>
)

/** Text encoding of archive contents. Injected so the zip logic is testable without a JSON library. */
interface ArchiveCodec {
    fun encodePage(page: Page): String
    fun decodePage(text: String): Page
    fun encodeManifest(m: ArchiveManifest): String
    fun decodeManifest(text: String): ArchiveManifest
}

class ArchiveException(message: String, cause: Throwable? = null) : Exception(message, cause)

class ArchiveContent(val boards: List<BoardMeta>, val pages: Map<String, Page>, val skippedPages: Int)

/**
 * `.n3wb` project files and full backups share one zip layout:
 *   manifest.json            – boards and their page order
 *   pages/<pageId>.json      – page content
 *   media/<file>             – images, PDFs, audio, video referenced by the pages
 * Entry names are validated on import so a crafted archive cannot write outside the media folder.
 */
object ArchiveIO {
    const val FORMAT = "note3-archive"
    const val VERSION = 1
    const val MAX_ENTRY_BYTES = 1L shl 31 // 2 GiB per media file
    const val MAX_PAGE_BYTES = 64L shl 20 // 64 MiB of JSON per page

    private val pageName = Regex("^pages/([A-Za-z0-9\\-]{1,64})\\.json$")
    private val mediaName = Regex("^media/([A-Za-z0-9._\\-]{1,128})$")

    fun mediaFilesOf(page: Page): Set<String> {
        val out = LinkedHashSet<String>()
        page.pdf?.let { out.add(it.file) }
        for (e in page.elements) {
            when (e) {
                is ImageElement -> out.add(e.file)
                is MediaElement -> out.add(e.file)
                else -> {}
            }
        }
        return out
    }

    fun isSafeMediaName(name: String): Boolean =
        mediaName.matches("media/$name") && name != "." && name != ".."

    /**
     * Writes the archive. [loadPage] is called once per page so memory stays bounded.
     * Returns the number of referenced media files that were missing on disk.
     */
    fun write(
        boards: List<BoardMeta>,
        loadPage: (String) -> Page?,
        mediaDir: File,
        codec: ArchiveCodec,
        out: OutputStream
    ): Int {
        var missing = 0
        val writtenMedia = HashSet<String>()
        ZipOutputStream(out.buffered()).use { zip ->
            zip.setLevel(6)
            putText(zip, "manifest.json", codec.encodeManifest(ArchiveManifest(boards = boards)))
            val seenPages = HashSet<String>()
            for (b in boards) for (pid in b.pageIds) {
                if (!seenPages.add(pid)) continue
                val page = loadPage(pid) ?: continue
                putText(zip, "pages/$pid.json", codec.encodePage(page))
                for (name in mediaFilesOf(page)) {
                    if (!isSafeMediaName(name) || !writtenMedia.add(name)) continue
                    val f = File(mediaDir, name)
                    if (!f.isFile) {
                        missing++
                        continue
                    }
                    zip.putNextEntry(ZipEntry("media/$name"))
                    f.inputStream().use { it.copyTo(zip, 64 * 1024) }
                    zip.closeEntry()
                }
            }
        }
        return missing
    }

    /** Reads an archive, extracting media into [mediaDir]. Pages are returned in memory. */
    fun read(input: InputStream, mediaDir: File, codec: ArchiveCodec): ArchiveContent {
        mediaDir.mkdirs()
        var manifest: ArchiveManifest? = null
        val pages = HashMap<String, Page>()
        var skipped = 0
        ZipInputStream(input.buffered()).use { zip ->
            while (true) {
                val entry = zip.nextEntry ?: break
                if (entry.isDirectory) continue
                val name = entry.name
                when {
                    name == "manifest.json" -> {
                        val text = readText(zip, MAX_PAGE_BYTES)
                        val m = try {
                            codec.decodeManifest(text)
                        } catch (e: Exception) {
                            throw ArchiveException("The project file is damaged (bad manifest).", e)
                        }
                        if (m.format != FORMAT) throw ArchiveException("This is not a Note3 project file.")
                        if (m.version > VERSION) throw ArchiveException("This file was made by a newer version of the app.")
                        manifest = m
                    }
                    pageName.matches(name) -> {
                        val id = pageName.matchEntire(name)!!.groupValues[1]
                        try {
                            pages[id] = codec.decodePage(readText(zip, MAX_PAGE_BYTES))
                        } catch (e: Exception) {
                            skipped++
                        }
                    }
                    mediaName.matches(name) -> {
                        val fileName = mediaName.matchEntire(name)!!.groupValues[1]
                        if (fileName == "." || fileName == "..") continue
                        extract(zip, File(mediaDir, fileName))
                    }
                    else -> { /* ignore unknown entries */ }
                }
            }
        }
        val m = manifest ?: throw ArchiveException("The project file has no manifest.")
        return ArchiveContent(m.boards, pages, skipped)
    }

    private fun putText(zip: ZipOutputStream, name: String, text: String) {
        zip.putNextEntry(ZipEntry(name))
        zip.write(text.toByteArray(Charsets.UTF_8))
        zip.closeEntry()
    }

    private fun readText(zip: ZipInputStream, limit: Long): String {
        val buf = java.io.ByteArrayOutputStream()
        val chunk = ByteArray(16 * 1024)
        var total = 0L
        while (true) {
            val n = zip.read(chunk)
            if (n < 0) break
            total += n
            if (total > limit) throw ArchiveException("The project file contains an oversized entry.")
            buf.write(chunk, 0, n)
        }
        return buf.toString("UTF-8")
    }

    private fun extract(zip: ZipInputStream, target: File) {
        val tmp = File(target.parentFile, target.name + ".part")
        var total = 0L
        try {
            tmp.outputStream().use { os ->
                val chunk = ByteArray(64 * 1024)
                while (true) {
                    val n = zip.read(chunk)
                    if (n < 0) break
                    total += n
                    if (total > MAX_ENTRY_BYTES) throw ArchiveException("A media file in the archive is too large.")
                    os.write(chunk, 0, n)
                }
            }
            if (target.exists()) target.delete()
            if (!tmp.renameTo(target)) throw ArchiveException("Could not store ${target.name}.")
        } finally {
            if (tmp.exists()) tmp.delete()
        }
    }
}
