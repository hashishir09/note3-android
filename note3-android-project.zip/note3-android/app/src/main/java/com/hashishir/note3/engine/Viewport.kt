package com.hashishir.note3.engine

import com.hashishir.note3.engine.math.Rect
import kotlin.math.min

/**
 * Maps between world coordinates (the infinite canvas) and screen pixels:
 * screen = world * scale + translation. Pure Kotlin so it can be unit-tested on the JVM.
 */
class Viewport(var scale: Float = 1f, var tx: Float = 0f, var ty: Float = 0f) {

    fun toWorldX(sx: Float): Float = (sx - tx) / scale
    fun toWorldY(sy: Float): Float = (sy - ty) / scale
    fun toScreenX(wx: Float): Float = wx * scale + tx
    fun toScreenY(wy: Float): Float = wy * scale + ty

    fun panBy(dx: Float, dy: Float) {
        tx += dx
        ty += dy
    }

    /** Multiplies the zoom by [factor] keeping the world point under ([sx], [sy]) fixed on screen. */
    fun zoomAt(factor: Float, sx: Float, sy: Float) {
        val newScale = (scale * factor).coerceIn(MIN_SCALE, MAX_SCALE)
        val f = newScale / scale
        tx = sx - (sx - tx) * f
        ty = sy - (sy - ty) * f
        scale = newScale
    }

    /** Fits [world] into a view of the given size with [padding] pixels around it. */
    fun fit(world: Rect, viewW: Float, viewH: Float, padding: Float = 32f) {
        if (viewW <= 0f || viewH <= 0f) return
        val w = world.width.coerceAtLeast(1f)
        val h = world.height.coerceAtLeast(1f)
        val s = min((viewW - 2 * padding).coerceAtLeast(1f) / w, (viewH - 2 * padding).coerceAtLeast(1f) / h)
            .coerceIn(MIN_SCALE, MAX_SCALE)
        scale = s
        tx = viewW / 2f - world.centerX * s
        ty = viewH / 2f - world.centerY * s
    }

    fun visibleWorld(viewW: Float, viewH: Float): Rect =
        Rect(toWorldX(0f), toWorldY(0f), toWorldX(viewW), toWorldY(viewH))

    fun set(o: Viewport) {
        scale = o.scale
        tx = o.tx
        ty = o.ty
    }

    companion object {
        const val MIN_SCALE = 0.05f
        const val MAX_SCALE = 16f
    }
}
