package com.hashishir.note3.data.db

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "boards")
data class BoardEntity(
    @PrimaryKey val id: String,
    val title: String,
    val createdAt: Long,
    val updatedAt: Long
)

/**
 * Page metadata only. The page content (strokes, text, ...) lives in a JSON file managed by
 * [com.hashishir.note3.data.PageStore] because SQLite rows are limited to ~2 MB on Android.
 */
@Entity(
    tableName = "pages",
    foreignKeys = [
        ForeignKey(
            entity = BoardEntity::class,
            parentColumns = ["id"],
            childColumns = ["boardId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("boardId")]
)
data class PageEntity(
    @PrimaryKey val id: String,
    val boardId: String,
    val position: Int
)

data class BoardSummary(
    val id: String,
    val title: String,
    val createdAt: Long,
    val updatedAt: Long,
    val pageCount: Int
)
