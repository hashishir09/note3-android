package com.hashishir.note3.ui.editor

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.os.Build
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Category
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Fullscreen
import androidx.compose.material.icons.filled.FullscreenExit
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Redo
import androidx.compose.material.icons.filled.SelectAll
import androidx.compose.material.icons.filled.Slideshow
import androidx.compose.material.icons.filled.Undo
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.viewmodel.compose.viewModel
import com.hashishir.note3.Note3App
import com.hashishir.note3.engine.Tool
import com.hashishir.note3.export.ImageFormat
import com.hashishir.note3.recording.RecorderService
import com.hashishir.note3.recording.RecordingBus
import com.hashishir.note3.recording.RecordingState
import com.hashishir.note3.ui.canvas.WhiteboardView
import com.hashishir.note3.ui.components.ChoiceChips
import com.hashishir.note3.ui.components.ColorPickerDialog
import com.hashishir.note3.ui.components.SectionLabel
import com.hashishir.note3.ui.components.TouchTarget
import com.hashishir.note3.ui.home.BusyOverlay

private enum class PanelId(val label: String, val icon: ImageVector) {
    DRAW("Draw", Icons.Default.Edit),
    SHAPES("Shapes", Icons.Default.Category),
    SELECT("Select", Icons.Default.SelectAll),
    INSERT("Insert", Icons.Default.Add),
    PAGES("Pages", Icons.Default.Description),
    TEACH("Teach", Icons.Default.Slideshow)
}

private tailrec fun Context.findActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivity()
    else -> null
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun EditorScreen(boardId: String, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val app = ctx.applicationContext as Note3App
    val vm: EditorViewModel = viewModel(key = "editor-$boardId", factory = EditorViewModel.Factory(app, boardId))
    val ui by vm.ui.collectAsState()
    val appSettings by vm.appSettings.collectAsState()
    val tick by vm.renderTick.collectAsState()
    val textEdit by vm.textEdit.collectAsState()
    val playing by vm.playing.collectAsState()
    val recState by RecordingBus.state.collectAsState()

    val snack = remember { SnackbarHostState() }
    var panel by rememberSaveable { mutableStateOf<PanelId?>(null) }
    var fullscreen by rememberSaveable { mutableStateOf(false) }
    var presentation by rememberSaveable { mutableStateOf(false) }
    var spotlight by rememberSaveable { mutableStateOf(false) }
    var cover by rememberSaveable { mutableStateOf<CoverSide?>(null) }
    var showLayers by rememberSaveable { mutableStateOf(false) }
    var showMenu by remember { mutableStateOf(false) }
    var confirmDeletePage by remember { mutableStateOf(false) }
    var renameBoard by remember { mutableStateOf(false) }
    var colorDialogFor by remember { mutableStateOf<((Int) -> Unit)?>(null) }
    var colorDialogInitial by remember { mutableStateOf(0xFF000000.toInt()) }
    var recordAudio by rememberSaveable { mutableStateOf(false) }
    var exportPdfAll by remember { mutableStateOf(true) }

    val landscape = LocalConfiguration.current.orientation == android.content.res.Configuration.ORIENTATION_LANDSCAPE
    val hideChrome = fullscreen || presentation

    // ---- lifecycle: always persist when the screen goes to the background
    LifecycleEventEffect(Lifecycle.Event.ON_STOP) { vm.flush() }
    LaunchedEffect(tick) { vm.onBitmapReady() }
    LaunchedEffect(Unit) { vm.messages.collect { snack.showSnackbar(it) } }

    // ---- immersive mode for full-screen canvas and presentation
    val view = LocalView.current
    DisposableEffect(hideChrome) {
        val window = ctx.findActivity()?.window
        if (window != null) {
            val c = WindowCompat.getInsetsController(window, view)
            c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            if (hideChrome) c.hide(WindowInsetsCompat.Type.systemBars()) else c.show(WindowInsetsCompat.Type.systemBars())
        }
        onDispose {
            ctx.findActivity()?.window?.let { WindowCompat.getInsetsController(it, view).show(WindowInsetsCompat.Type.systemBars()) }
        }
    }
    DisposableEffect(appSettings.keepScreenOn) {
        view.keepScreenOn = appSettings.keepScreenOn
        onDispose { view.keepScreenOn = false }
    }
    BackHandler(enabled = presentation || fullscreen || panel != null) {
        when {
            presentation -> { presentation = false; spotlight = false; cover = null }
            fullscreen -> fullscreen = false
            else -> panel = null
        }
    }

    // ---- pickers
    val pickImage = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { it?.let(vm::importImage) }
    val pickPdf = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { it?.let(vm::importPdf) }
    val pickAudio = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { it?.let { u -> vm.importMedia(u, com.hashishir.note3.engine.model.MediaKind.AUDIO) } }
    val pickVideo = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { it?.let { u -> vm.importMedia(u, com.hashishir.note3.engine.model.MediaKind.VIDEO) } }
    val pickers = PickerActions(
        image = { pickImage.launch("image/*") },
        pdf = { pickPdf.launch(arrayOf("application/pdf")) },
        audio = { pickAudio.launch("audio/*") },
        video = { pickVideo.launch("video/*") }
    )
    val savePng = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("image/png")) { it?.let { u -> vm.exportImage(u, ImageFormat.PNG) } }
    val saveJpg = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("image/jpeg")) { it?.let { u -> vm.exportImage(u, ImageFormat.JPG) } }
    val savePdf = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { it?.let { u -> vm.exportPdf(u, exportPdfAll) } }
    val saveProject = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")) { it?.let(vm::exportProject) }

    // ---- screen recording
    val projectionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val data = r.data
        if (r.resultCode == Activity.RESULT_OK && data != null) {
            ContextCompat.startForegroundService(ctx, RecorderService.startIntent(ctx, r.resultCode, data, recordAudio))
        } else {
            RecordingBus.set(RecordingState.Failed("Screen recording was cancelled."))
        }
    }
    fun launchCapture() {
        val mpm = ctx.getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projectionLauncher.launch(mpm.createScreenCaptureIntent())
    }
    val micPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (!granted) recordAudio = false
        launchCapture()
    }
    val notifPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    fun startRecording() {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        if (recordAudio && ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            micPermission.launch(Manifest.permission.RECORD_AUDIO)
        } else {
            launchCapture()
        }
    }
    LaunchedEffect(recState) {
        when (val st = recState) {
            is RecordingState.Finished -> { snack.showSnackbar("Recording saved to your gallery (Movies/Note3)."); RecordingBus.set(RecordingState.Idle) }
            is RecordingState.Failed -> { snack.showSnackbar(st.message); RecordingBus.set(RecordingState.Idle) }
            else -> {}
        }
    }
    val recording = recState is RecordingState.Recording

    // ---------------------------------------------------------------- layout
    Scaffold(snackbarHost = { SnackbarHost(snack) }, containerColor = MaterialTheme.colorScheme.background) { _ ->
        Box(Modifier.fillMaxSize()) {
            // drawing surface (full bleed under all chrome)
            AndroidView(
                factory = { c -> WhiteboardView(c).also { vm.attachView(it) } },
                onRelease = { vm.detachView(it) },
                modifier = Modifier.fillMaxSize()
            )

            if (cover != null) ScreenCover(cover!!)
            if (spotlight) SpotlightOverlay()

            if (!ui.loaded) CircularProgressIndicator(Modifier.align(Alignment.Center))

            if (!hideChrome) {
                val panelContent: @Composable () -> Unit = {
                    PanelCard(landscape) {
                        when (panel) {
                            PanelId.DRAW -> DrawPanel(vm, ui, appSettings) { colorDialogInitial = ui.settings.color; colorDialogFor = { c -> vm.updateTool { it.copy(color = c) } } }
                            PanelId.SHAPES -> ShapesPanel(vm, ui) { colorDialogInitial = ui.settings.color; colorDialogFor = { c -> vm.updateTool { it.copy(color = c) } } }
                            PanelId.SELECT -> SelectPanel(vm, ui) { showLayers = true }
                            PanelId.INSERT -> InsertPanel(vm, ui, pickers)
                            PanelId.PAGES -> PagesPanel(vm, ui, { showLayers = true }, { confirmDeletePage = true })
                            PanelId.TEACH -> TeachPanel(
                                spotlight = spotlight, onSpotlight = { spotlight = it },
                                cover = cover, onCover = { cover = it },
                                recording = recording, recordAudio = recordAudio, onRecordAudio = { recordAudio = it },
                                onStartRecording = { startRecording() },
                                onStopRecording = { ctx.startService(RecorderService.stopIntent(ctx)) },
                                onPresent = { presentation = true; panel = null }
                            )
                            null -> {}
                        }
                    }
                }
                if (landscape) {
                    Row(Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.systemBars)) {
                        NavigationRail {
                            Spacer(Modifier.weight(1f))
                            for (p in PanelId.entries) {
                                NavigationRailItem(
                                    selected = panel == p,
                                    onClick = { panel = if (panel == p) null else p },
                                    icon = { Icon(p.icon, contentDescription = null) },
                                    label = { Text(p.label) }
                                )
                            }
                            Spacer(Modifier.weight(1f))
                        }
                        AnimatedVisibility(panel != null) { Box(Modifier.width(320.dp).fillMaxHeight().padding(8.dp)) { panelContent() } }
                        Column(Modifier.weight(1f).fillMaxHeight()) {
                            TopBar(ui, recording, onBack, { vm.undo() }, { vm.redo() }, { fullscreen = true }, showMenu, { showMenu = it },
                                menu = { EditorMenu(vm, ui, { showMenu = false }, { renameBoard = true }, { savePng.launch("page.png") }, { saveJpg.launch("page.jpg") },
                                    { exportPdfAll = false; savePdf.launch("page.pdf") }, { exportPdfAll = true; savePdf.launch("board.pdf") }, { saveProject.launch("board.n3wb") }) },
                                onStopRecording = { ctx.startService(RecorderService.stopIntent(ctx)) })
                            Spacer(Modifier.weight(1f))
                        }
                    }
                } else {
                    Column(Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.systemBars)) {
                        TopBar(ui, recording, onBack, { vm.undo() }, { vm.redo() }, { fullscreen = true }, showMenu, { showMenu = it },
                            menu = { EditorMenu(vm, ui, { showMenu = false }, { renameBoard = true }, { savePng.launch("page.png") }, { saveJpg.launch("page.jpg") },
                                { exportPdfAll = false; savePdf.launch("page.pdf") }, { exportPdfAll = true; savePdf.launch("board.pdf") }, { saveProject.launch("board.n3wb") }) },
                            onStopRecording = { ctx.startService(RecorderService.stopIntent(ctx)) })
                        Spacer(Modifier.weight(1f))
                        AnimatedVisibility(panel != null) { Box(Modifier.padding(horizontal = 8.dp, vertical = 4.dp)) { panelContent() } }
                        NavigationBar {
                            for (p in PanelId.entries) {
                                NavigationBarItem(
                                    selected = panel == p,
                                    onClick = { panel = if (panel == p) null else p },
                                    icon = { Icon(p.icon, contentDescription = null) },
                                    label = { Text(p.label, maxLines = 1) },
                                    alwaysShowLabel = false
                                )
                            }
                        }
                    }
                }
            } else if (presentation) {
                PresentationBar(
                    ui = ui,
                    spotlight = spotlight, onSpotlight = { spotlight = !spotlight },
                    cover = cover != null, onCover = { cover = if (cover == null) CoverSide.TOP else null },
                    onPrev = { vm.goToPage(ui.pageIndex - 1) },
                    onNext = { vm.goToPage(ui.pageIndex + 1) },
                    onPen = { vm.updateTool { it.copy(tool = if (it.tool == Tool.HAND) Tool.PEN else Tool.HAND) } },
                    panning = ui.settings.tool == Tool.HAND,
                    onExit = { presentation = false; spotlight = false; cover = null },
                    modifier = Modifier.align(Alignment.BottomCenter)
                )
            } else {
                // plain full-screen canvas: only a small restore pill
                Row(
                    Modifier.align(Alignment.TopEnd).windowInsetsPadding(WindowInsets.systemBars).padding(8.dp)
                        .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.85f), MaterialTheme.shapes.extraLarge),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = { vm.undo() }, enabled = ui.canUndo) { Icon(Icons.Default.Undo, "Undo") }
                    IconButton(onClick = { vm.redo() }, enabled = ui.canRedo) { Icon(Icons.Default.Redo, "Redo") }
                    IconButton(onClick = { fullscreen = false }) { Icon(Icons.Default.FullscreenExit, "Exit full screen") }
                }
            }

            if (ui.busy != null) BusyOverlay(ui.busy!!)
        }
    }

    // ---------------------------------------------------------------- dialogs
    if (showLayers) LayersSheet(vm, ui) { showLayers = false }

    textEdit?.let { st ->
        TextEditDialog(
            state = st,
            onCancel = { vm.cancelText() },
            onDelete = { vm.deleteText(st) },
            onCommit = { t, s, c -> vm.commitText(st, t, s, c) },
            onCustomColor = { initial, cb -> colorDialogInitial = initial; colorDialogFor = cb }
        )
    }
    playing?.let { el -> MediaPlayerDialog(el, vm.mediaFile(el.file)) { vm.stopPlaying() } }
    colorDialogFor?.let { cb ->
        ColorPickerDialog(colorDialogInitial, onDismiss = { colorDialogFor = null }, onPick = { c -> cb(c); colorDialogFor = null })
    }
    if (confirmDeletePage) {
        AlertDialog(
            onDismissRequest = { confirmDeletePage = false },
            title = { Text("Delete page ${ui.pageIndex + 1}?") },
            text = { Text("The page and everything on it will be removed. This cannot be undone.") },
            confirmButton = { TextButton(onClick = { confirmDeletePage = false; vm.deletePage() }) { Text("Delete") } },
            dismissButton = { TextButton(onClick = { confirmDeletePage = false }) { Text("Cancel") } }
        )
    }
    if (renameBoard) {
        var name by remember { mutableStateOf(ui.title) }
        AlertDialog(
            onDismissRequest = { renameBoard = false },
            title = { Text("Rename board") },
            text = { OutlinedTextField(name, { name = it }, singleLine = true) },
            confirmButton = { TextButton(onClick = { vm.renameBoard(name); renameBoard = false }) { Text("Rename") } },
            dismissButton = { TextButton(onClick = { renameBoard = false }) { Text("Cancel") } }
        )
    }
}

// ---------------------------------------------------------------------- pieces

@Composable
private fun PanelCard(landscape: Boolean, content: @Composable () -> Unit) {
    Surface(
        shape = MaterialTheme.shapes.large,
        tonalElevation = 6.dp,
        shadowElevation = 6.dp,
        modifier = if (landscape) Modifier.fillMaxSize() else Modifier.fillMaxWidth().heightIn(max = 340.dp)
    ) {
        Column(Modifier.verticalScroll(rememberScrollState()).padding(horizontal = 12.dp, vertical = 8.dp)) { content() }
    }
}

@Composable
private fun TopBar(
    ui: EditorUi,
    recording: Boolean,
    onBack: () -> Unit,
    onUndo: () -> Unit,
    onRedo: () -> Unit,
    onFullscreen: () -> Unit,
    menuOpen: Boolean,
    setMenuOpen: (Boolean) -> Unit,
    menu: @Composable () -> Unit,
    onStopRecording: () -> Unit
) {
    Surface(
        shape = MaterialTheme.shapes.extraLarge,
        tonalElevation = 6.dp,
        shadowElevation = 4.dp,
        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp).fillMaxWidth()
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back to boards") }
            Column(Modifier.weight(1f)) {
                Text(ui.title, style = MaterialTheme.typography.titleSmall, maxLines = 1)
                Text("Page ${ui.pageIndex + 1}/${ui.pageCount}", style = MaterialTheme.typography.labelSmall)
            }
            if (recording) {
                TextButton(onClick = onStopRecording) { Text("● REC", color = Color(0xFFD32F2F)) }
            }
            IconButton(onClick = onUndo, enabled = ui.canUndo) { Icon(Icons.Default.Undo, "Undo") }
            IconButton(onClick = onRedo, enabled = ui.canRedo) { Icon(Icons.Default.Redo, "Redo") }
            IconButton(onClick = onFullscreen) { Icon(Icons.Default.Fullscreen, "Full screen canvas") }
            Box {
                IconButton(onClick = { setMenuOpen(true) }) { Icon(Icons.Default.MoreVert, "More") }
                DropdownMenu(expanded = menuOpen, onDismissRequest = { setMenuOpen(false) }) { menu() }
            }
        }
    }
}

@Composable
private fun EditorMenu(
    vm: EditorViewModel,
    ui: EditorUi,
    close: () -> Unit,
    rename: () -> Unit,
    png: () -> Unit,
    jpg: () -> Unit,
    pdfPage: () -> Unit,
    pdfAll: () -> Unit,
    project: () -> Unit
) {
    DropdownMenuItem(text = { Text("Rename board") }, onClick = { close(); rename() })
    DropdownMenuItem(text = { Text("Export page as PNG") }, onClick = { close(); png() })
    DropdownMenuItem(text = { Text("Export page as JPG") }, onClick = { close(); jpg() })
    DropdownMenuItem(text = { Text("Export this page as PDF") }, onClick = { close(); pdfPage() })
    DropdownMenuItem(text = { Text("Export all ${ui.pageCount} pages as PDF") }, onClick = { close(); pdfAll() })
    DropdownMenuItem(text = { Text("Save project file (.n3wb)") }, onClick = { close(); project() })
    DropdownMenuItem(text = { Text("Fit to content") }, onClick = { close(); vm.fitContent() })
}

@Composable
private fun TeachPanel(
    spotlight: Boolean,
    onSpotlight: (Boolean) -> Unit,
    cover: CoverSide?,
    onCover: (CoverSide?) -> Unit,
    recording: Boolean,
    recordAudio: Boolean,
    onRecordAudio: (Boolean) -> Unit,
    onStartRecording: () -> Unit,
    onStopRecording: () -> Unit,
    onPresent: () -> Unit
) {
    SectionLabel("Presentation")
    Button(onClick = onPresent, modifier = Modifier.heightIn(min = TouchTarget)) { Text("Start presentation mode") }
    Text(
        "Full screen with a compact control bar for page turning, spotlight and screen cover. Drawing stays available. Press Back to leave.",
        style = MaterialTheme.typography.bodySmall
    )
    SectionLabel("Spotlight")
    Row(Modifier.fillMaxWidth().heightIn(min = TouchTarget).clickable { onSpotlight(!spotlight) }, verticalAlignment = Alignment.CenterVertically) {
        Text("Spotlight (drag to move, pinch to resize)", Modifier.weight(1f))
        Switch(checked = spotlight, onCheckedChange = onSpotlight)
    }
    if (spotlight) Text("While the spotlight is on, touches move the spotlight instead of drawing.", style = MaterialTheme.typography.bodySmall)
    SectionLabel("Screen cover")
    ChoiceChips(
        listOf("Off" to null) + CoverSide.entries.map { it.label to it },
        cover, onCover
    )
    SectionLabel("Screen recording")
    Row(Modifier.fillMaxWidth().heightIn(min = TouchTarget).clickable(enabled = !recording) { onRecordAudio(!recordAudio) }, verticalAlignment = Alignment.CenterVertically) {
        Text("Record microphone audio", Modifier.weight(1f))
        Switch(checked = recordAudio, onCheckedChange = onRecordAudio, enabled = !recording)
    }
    if (!recording) {
        Button(onClick = onStartRecording, modifier = Modifier.heightIn(min = TouchTarget)) { Text("Start recording") }
        Text("Android will ask for permission to capture the screen. The video is saved to Movies/Note3.", style = MaterialTheme.typography.bodySmall)
    } else {
        OutlinedButton(onClick = onStopRecording, modifier = Modifier.heightIn(min = TouchTarget)) { Text("Stop and save recording") }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun PresentationBar(
    ui: EditorUi,
    spotlight: Boolean,
    onSpotlight: () -> Unit,
    cover: Boolean,
    onCover: () -> Unit,
    onPrev: () -> Unit,
    onNext: () -> Unit,
    onPen: () -> Unit,
    panning: Boolean,
    onExit: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = MaterialTheme.shapes.extraLarge,
        tonalElevation = 8.dp,
        shadowElevation = 8.dp,
        color = MaterialTheme.colorScheme.surface.copy(alpha = 0.92f),
        modifier = modifier.windowInsetsPadding(WindowInsets.systemBars).padding(8.dp)
    ) {
        FlowRow(
            Modifier.padding(horizontal = 8.dp),
            horizontalArrangement = Arrangement.Center,
            verticalArrangement = Arrangement.Center
        ) {
            TextButton(onClick = onPrev, enabled = ui.pageIndex > 0, modifier = Modifier.heightIn(min = TouchTarget)) { Text("‹ Prev") }
            Text("${ui.pageIndex + 1}/${ui.pageCount}", Modifier.align(Alignment.CenterVertically).padding(horizontal = 4.dp))
            TextButton(onClick = onNext, enabled = ui.pageIndex < ui.pageCount - 1, modifier = Modifier.heightIn(min = TouchTarget)) { Text("Next ›") }
            TextButton(onClick = onPen, modifier = Modifier.heightIn(min = TouchTarget)) { Text(if (panning) "Draw" else "Pan") }
            TextButton(onClick = onSpotlight, modifier = Modifier.heightIn(min = TouchTarget)) { Text(if (spotlight) "Spot ✓" else "Spot") }
            TextButton(onClick = onCover, modifier = Modifier.heightIn(min = TouchTarget)) { Text(if (cover) "Cover ✓" else "Cover") }
            TextButton(onClick = onExit, modifier = Modifier.heightIn(min = TouchTarget)) { Text("Exit") }
        }
    }
}
