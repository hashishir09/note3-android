package com.hashishir.note3.engine.model

import com.hashishir.note3.engine.math.Affine
import com.hashishir.note3.engine.math.Geo
import com.hashishir.note3.engine.math.Rect
import com.hashishir.note3.engine.math.Vec
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import java.util.UUID
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.sin

object IdGen {
    fun next(): String = UUID.randomUUID().toString()
}

/** A stroke sample. [p] is normalized pressure (0..1+). */
@Serializable
data class Pt(val x: Float, val y: Float, val p: Float = 1f)

@Serializable
enum class StrokeTool { PEN, BRUSH, HIGHLIGHTER }

@Serializable
enum class ShapeKind { LINE, ARROW, ELLIPSE, RECT, TRIANGLE, POLYGON }

@Serializable
enum class MediaKind { AUDIO, VIDEO }

/** Rotated rectangle geometry shared by text, image and media elements. Origin is the top-left corner. */
interface Boxed {
    val ox: Float
    val oy: Float
    val w: Float
    val h: Float
    val rotation: Float
}

data class BoxGeom(val ox: Float, val oy: Float, val w: Float, val h: Float, val rotation: Float)

fun Boxed.corners(): List<Vec> {
    val cs = cos(rotation)
    val sn = sin(rotation)
    val p0 = Vec(ox, oy)
    val u = Vec(cs * w, sn * w)
    val v = Vec(-sn * h, cs * h)
    return listOf(p0, p0 + u, p0 + u + v, p0 + v)
}

fun Boxed.boxBounds(): Rect = Rect.fromPoints(corners())

fun Boxed.boxContains(x: Float, y: Float, tol: Float): Boolean {
    // Inverse-rotate the point into the box's local frame.
    val cs = cos(-rotation)
    val sn = sin(-rotation)
    val dx = x - ox
    val dy = y - oy
    val lx = cs * dx - sn * dy
    val ly = sn * dx + cs * dy
    return lx >= -tol && lx <= w + tol && ly >= -tol && ly <= h + tol
}

fun Boxed.transformBox(m: Affine): BoxGeom {
    val cs = cos(rotation)
    val sn = sin(rotation)
    val q0 = m.map(Vec(ox, oy))
    val q1 = m.map(Vec(ox + cs * w, oy + sn * w))
    val q3 = m.map(Vec(ox - sn * h, oy + cs * h))
    val ux = q1.x - q0.x
    val uy = q1.y - q0.y
    val vx = q3.x - q0.x
    val vy = q3.y - q0.y
    return BoxGeom(
        ox = q0.x, oy = q0.y,
        w = kotlin.math.hypot(ux, uy),
        h = kotlin.math.hypot(vx, vy),
        rotation = atan2(uy, ux)
    )
}

@Serializable
sealed class Element {
    abstract val id: String
    abstract val layerId: String
    abstract val groupId: String?

    abstract fun transformed(m: Affine): Element
    abstract fun bounds(): Rect
    abstract fun hitTest(x: Float, y: Float, tolerance: Float): Boolean
    abstract fun withMeta(id: String = this.id, layerId: String = this.layerId, groupId: String? = this.groupId): Element
}

@Serializable
@SerialName("stroke")
data class StrokeElement(
    override val id: String,
    override val layerId: String,
    override val groupId: String? = null,
    val points: List<Pt>,
    val color: Int,
    val width: Float,
    val tool: StrokeTool = StrokeTool.PEN
) : Element() {

    override fun transformed(m: Affine): Element {
        val f = m.scaleFactor
        return copy(
            points = points.map { Pt(m.mapX(it.x, it.y), m.mapY(it.x, it.y), it.p) },
            width = max(0.1f, width * f)
        )
    }

    override fun bounds(): Rect {
        if (points.isEmpty()) return Rect(0f, 0f, 0f, 0f)
        var l = points[0].x
        var t = points[0].y
        var r = l
        var b = t
        for (p in points) {
            if (p.x < l) l = p.x
            if (p.x > r) r = p.x
            if (p.y < t) t = p.y
            if (p.y > b) b = p.y
        }
        return Rect(l, t, r, b).inflate(width / 2f)
    }

    override fun hitTest(x: Float, y: Float, tolerance: Float): Boolean {
        if (points.isEmpty()) return false
        val reach = tolerance + width / 2f
        if (!bounds().inflate(tolerance).contains(x, y)) return false
        if (points.size == 1) return hypotF(x - points[0].x, y - points[0].y) <= reach
        for (i in 1 until points.size) {
            val a = points[i - 1]
            val b = points[i]
            if (Geo.distPointSegment(x, y, a.x, a.y, b.x, b.y) <= reach) return true
        }
        return false
    }

    override fun withMeta(id: String, layerId: String, groupId: String?): Element =
        copy(id = id, layerId = layerId, groupId = groupId)
}

/**
 * Geometric shape. Vertex layout per kind:
 * LINE/ARROW: 2 points; RECT: 4 corners in order; TRIANGLE: 3; POLYGON: n >= 3;
 * ELLIPSE: [center, center + u, center + v] (u, v are conjugate semi-axis tips, so any affine map stays exact).
 */
@Serializable
@SerialName("shape")
data class ShapeElement(
    override val id: String,
    override val layerId: String,
    override val groupId: String? = null,
    val kind: ShapeKind,
    val pts: List<Vec>,
    val color: Int,
    val width: Float,
    val fillColor: Int = 0
) : Element() {

    val isClosed: Boolean get() = kind != ShapeKind.LINE && kind != ShapeKind.ARROW

    /** Polyline outline in world coordinates; ellipses are sampled. */
    fun outline(ellipseSegments: Int = 64): List<Vec> {
        if (kind == ShapeKind.ELLIPSE && pts.size >= 3) {
            val c = pts[0]
            val u = pts[1] - c
            val v = pts[2] - c
            val out = ArrayList<Vec>(ellipseSegments + 1)
            for (i in 0..ellipseSegments) {
                val th = (i.toFloat() / ellipseSegments) * (2f * Math.PI.toFloat())
                val cs = cos(th)
                val sn = sin(th)
                out.add(Vec(c.x + u.x * cs + v.x * sn, c.y + u.y * cs + v.y * sn))
            }
            return out
        }
        if (isClosed && pts.isNotEmpty()) return pts + pts[0]
        return pts
    }

    override fun transformed(m: Affine): Element =
        copy(pts = pts.map { m.map(it) }, width = max(0.1f, width * m.scaleFactor))

    override fun bounds(): Rect = Rect.fromPoints(outline(32)).inflate(width / 2f)

    override fun hitTest(x: Float, y: Float, tolerance: Float): Boolean {
        val reach = tolerance + width / 2f
        val line = outline(48)
        if (!Rect.fromPoints(line).inflate(reach).contains(x, y)) return false
        if (fillColor != 0 && isClosed && Geo.pointInPolygon(x, y, line)) return true
        for (i in 1 until line.size) {
            if (Geo.distPointSegment(x, y, line[i - 1].x, line[i - 1].y, line[i].x, line[i].y) <= reach) return true
        }
        return false
    }

    override fun withMeta(id: String, layerId: String, groupId: String?): Element =
        copy(id = id, layerId = layerId, groupId = groupId)
}

@Serializable
@SerialName("text")
data class TextElement(
    override val id: String,
    override val layerId: String,
    override val groupId: String? = null,
    override val ox: Float,
    override val oy: Float,
    override val w: Float,
    override val h: Float,
    override val rotation: Float = 0f,
    val text: String,
    val color: Int,
    val fontSize: Float
) : Element(), Boxed {

    override fun transformed(m: Affine): Element {
        val g = transformBox(m)
        return copy(ox = g.ox, oy = g.oy, w = g.w, h = g.h, rotation = g.rotation, fontSize = fontSize * m.scaleFactor)
    }

    override fun bounds(): Rect = boxBounds()
    override fun hitTest(x: Float, y: Float, tolerance: Float): Boolean = boxContains(x, y, tolerance)
    override fun withMeta(id: String, layerId: String, groupId: String?): Element =
        copy(id = id, layerId = layerId, groupId = groupId)
}

/** [file] is a path relative to the app's media directory (see MediaStore). */
@Serializable
@SerialName("image")
data class ImageElement(
    override val id: String,
    override val layerId: String,
    override val groupId: String? = null,
    override val ox: Float,
    override val oy: Float,
    override val w: Float,
    override val h: Float,
    override val rotation: Float = 0f,
    val file: String
) : Element(), Boxed {

    override fun transformed(m: Affine): Element {
        val g = transformBox(m)
        return copy(ox = g.ox, oy = g.oy, w = g.w, h = g.h, rotation = g.rotation)
    }

    override fun bounds(): Rect = boxBounds()
    override fun hitTest(x: Float, y: Float, tolerance: Float): Boolean = boxContains(x, y, tolerance)
    override fun withMeta(id: String, layerId: String, groupId: String?): Element =
        copy(id = id, layerId = layerId, groupId = groupId)
}

@Serializable
@SerialName("media")
data class MediaElement(
    override val id: String,
    override val layerId: String,
    override val groupId: String? = null,
    override val ox: Float,
    override val oy: Float,
    override val w: Float,
    override val h: Float,
    override val rotation: Float = 0f,
    val kind: MediaKind,
    val file: String,
    val name: String
) : Element(), Boxed {

    override fun transformed(m: Affine): Element {
        val g = transformBox(m)
        return copy(ox = g.ox, oy = g.oy, w = g.w, h = g.h, rotation = g.rotation)
    }

    override fun bounds(): Rect = boxBounds()
    override fun hitTest(x: Float, y: Float, tolerance: Float): Boolean = boxContains(x, y, tolerance)
    override fun withMeta(id: String, layerId: String, groupId: String?): Element =
        copy(id = id, layerId = layerId, groupId = groupId)
}

@Serializable
data class Layer(
    val id: String,
    val name: String,
    val visible: Boolean = true,
    val locked: Boolean = false
)

@Serializable
enum class PaperStyle { BLANK, GRID, DOTS, LINES }

/** A PDF page used as the page background; strokes annotate on top of it. */
@Serializable
data class PdfRef(val file: String, val pageIndex: Int, val width: Float, val height: Float)

@Serializable
data class Page(
    val id: String,
    val paper: PaperStyle = PaperStyle.BLANK,
    val paperColor: Int = 0xFFFFFFFF.toInt(),
    val pdf: PdfRef? = null,
    val layers: List<Layer> = listOf(Layer(IdGen.next(), "Layer 1")),
    val elements: List<Element> = emptyList()
) {
    companion object {
        fun blank(paperColor: Int = 0xFFFFFFFF.toInt()): Page = Page(id = IdGen.next(), paperColor = paperColor)
    }
}

@Serializable
data class Board(
    val id: String,
    val title: String,
    val createdAt: Long,
    val updatedAt: Long,
    val pages: List<Page>
)

private fun hypotF(x: Float, y: Float): Float = kotlin.math.hypot(x, y)
