package com.hashishir.note3.data

import android.content.ContentResolver
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.net.Uri
import android.provider.OpenableColumns
import android.webkit.MimeTypeMap
import com.hashishir.note3.engine.model.IdGen
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import kotlin.math.max

data class ImportedFile(val name: String, val displayName: String)
data class ImportedImage(val name: String, val width: Int, val height: Int)

/**
 * App-private storage for everything pages reference by file name (images, PDFs, audio, video).
 * Files are copied in, so projects keep working when the original is moved or deleted.
 */
class MediaFiles(val dir: File, private val resolver: ContentResolver) {

    init {
        dir.mkdirs()
    }

    fun file(name: String): File {
        require(ArchiveIO.isSafeMediaName(name)) { "Unsafe media name" }
        return File(dir, name)
    }

    fun displayName(uri: Uri): String? = try {
        resolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(0) else null
        }
    } catch (_: Exception) {
        null
    }

    private fun extensionFor(uri: Uri, display: String?, fallback: String): String {
        val fromName = display?.substringAfterLast('.', "")?.lowercase().orEmpty()
        if (fromName.matches(Regex("[a-z0-9]{1,5}"))) return fromName
        val mime = try { resolver.getType(uri) } catch (_: Exception) { null }
        val fromMime = mime?.let { MimeTypeMap.getSingleton().getExtensionFromMimeType(it) }
        if (!fromMime.isNullOrBlank() && fromMime.matches(Regex("[a-z0-9]{1,5}"))) return fromMime
        return fallback
    }

    /** Copies any file (PDF, audio, video) into the media folder. */
    @Throws(IOException::class)
    fun importRaw(uri: Uri, fallbackExt: String): ImportedFile {
        val display = displayName(uri) ?: "file.$fallbackExt"
        val name = "${IdGen.next()}.${extensionFor(uri, display, fallbackExt)}"
        val target = File(dir, name)
        val tmp = File(dir, "$name.part")
        try {
            val input = resolver.openInputStream(uri) ?: throw IOException("Cannot open the selected file")
            input.use { ins -> FileOutputStream(tmp).use { os -> ins.copyTo(os, 64 * 1024) } }
            if (!tmp.renameTo(target)) throw IOException("Could not store the file")
        } finally {
            if (tmp.exists()) tmp.delete()
        }
        return ImportedFile(name, display)
    }

    /**
     * Imports an image: downsamples very large photos, applies the EXIF rotation, and stores the result
     * as PNG (when the source can have transparency) or JPEG.
     */
    @Throws(IOException::class)
    fun importImage(uri: Uri): ImportedImage {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        (resolver.openInputStream(uri) ?: throw IOException("Cannot open the image")).use {
            BitmapFactory.decodeStream(it, null, bounds)
        }
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) throw IOException("This file is not a readable image")
        var sample = 1
        while (max(bounds.outWidth, bounds.outHeight) / sample > MAX_IMPORT_EDGE) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        var bmp: Bitmap = (resolver.openInputStream(uri) ?: throw IOException("Cannot open the image")).use {
            BitmapFactory.decodeStream(it, null, opts)
        } ?: throw IOException("This file is not a readable image")

        val orientation = try {
            resolver.openInputStream(uri)?.use {
                ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
            } ?: ExifInterface.ORIENTATION_NORMAL
        } catch (_: Exception) {
            ExifInterface.ORIENTATION_NORMAL
        }
        val m = Matrix()
        when (orientation) {
            ExifInterface.ORIENTATION_ROTATE_90 -> m.postRotate(90f)
            ExifInterface.ORIENTATION_ROTATE_180 -> m.postRotate(180f)
            ExifInterface.ORIENTATION_ROTATE_270 -> m.postRotate(270f)
            ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> m.postScale(-1f, 1f)
            ExifInterface.ORIENTATION_FLIP_VERTICAL -> m.postScale(1f, -1f)
            ExifInterface.ORIENTATION_TRANSPOSE -> { m.postRotate(90f); m.postScale(-1f, 1f) }
            ExifInterface.ORIENTATION_TRANSVERSE -> { m.postRotate(270f); m.postScale(-1f, 1f) }
        }
        if (!m.isIdentity) {
            val rotated = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
            if (rotated !== bmp) bmp.recycle()
            bmp = rotated
        }

        val mime = try { resolver.getType(uri) } catch (_: Exception) { null } ?: ""
        val png = mime.contains("png") || mime.contains("webp") || mime.contains("gif")
        val name = "${IdGen.next()}.${if (png) "png" else "jpg"}"
        val target = File(dir, name)
        val tmp = File(dir, "$name.part")
        try {
            FileOutputStream(tmp).use { os ->
                val ok = bmp.compress(if (png) Bitmap.CompressFormat.PNG else Bitmap.CompressFormat.JPEG, 92, os)
                if (!ok) throw IOException("Could not encode the image")
            }
            if (!tmp.renameTo(target)) throw IOException("Could not store the image")
        } finally {
            if (tmp.exists()) tmp.delete()
        }
        val result = ImportedImage(name, bmp.width, bmp.height)
        bmp.recycle()
        return result
    }

    /** Decodes a stored image so that its longest side is at most about [maxEdge] pixels. */
    fun decodeSampled(name: String, maxEdge: Int): Bitmap? {
        if (!ArchiveIO.isSafeMediaName(name)) return null
        val f = File(dir, name)
        if (!f.isFile) return null
        val b = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(f.path, b)
        if (b.outWidth <= 0) return null
        var sample = 1
        while (max(b.outWidth, b.outHeight) / (sample * 2) >= maxEdge) sample *= 2
        return try {
            BitmapFactory.decodeFile(f.path, BitmapFactory.Options().apply { inSampleSize = sample })
        } catch (_: OutOfMemoryError) {
            null
        }
    }

    companion object {
        const val MAX_IMPORT_EDGE = 2560
    }
}
