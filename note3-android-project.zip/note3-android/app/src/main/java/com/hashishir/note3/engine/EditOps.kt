package com.hashishir.note3.engine

import com.hashishir.note3.engine.math.Affine
import com.hashishir.note3.engine.math.Geo
import com.hashishir.note3.engine.math.Rect
import com.hashishir.note3.engine.math.Vec
import com.hashishir.note3.engine.model.Element
import com.hashishir.note3.engine.model.IdGen
import com.hashishir.note3.engine.model.Layer

/** The undoable content of one page: its layers and its z-ordered elements. */
data class PageContent(val layers: List<Layer>, val elements: List<Element>)

object EditOps {

    /** An element can be edited if its layer exists, is visible and is not locked. */
    fun editablePredicate(layers: List<Layer>): (Element) -> Boolean {
        val ok = layers.filter { it.visible && !it.locked }.map { it.id }.toHashSet()
        return { e -> e.layerId in ok }
    }

    fun visiblePredicate(layers: List<Layer>): (Element) -> Boolean {
        val ok = layers.filter { it.visible }.map { it.id }.toHashSet()
        return { e -> e.layerId in ok }
    }

    /** Topmost editable element under a point, honoring layer order and z-order inside layers. */
    fun topmostAt(elements: List<Element>, layers: List<Layer>, x: Float, y: Float, tol: Float): Element? {
        val editable = editablePredicate(layers)
        val rank = layers.withIndex().associate { it.value.id to it.index }
        var best: Element? = null
        var bestRank = -1
        for (e in elements) { // later in the list == higher z inside a layer
            if (!editable(e)) continue
            if (!e.hitTest(x, y, tol)) continue
            val r = rank[e.layerId] ?: continue
            if (r >= bestRank) {
                best = e
                bestRank = r
            }
        }
        return best
    }

    /** Elements whose bounds center falls inside the lasso polygon. */
    fun inLasso(elements: List<Element>, layers: List<Layer>, lasso: List<Vec>): Set<String> {
        if (lasso.size < 3) return emptySet()
        val editable = editablePredicate(layers)
        val out = LinkedHashSet<String>()
        for (e in elements) {
            if (!editable(e)) continue
            val b = e.bounds()
            if (Geo.pointInPolygon(b.centerX, b.centerY, lasso)) out.add(e.id)
        }
        return out
    }

    /** Selecting one member of a group selects the whole group. */
    fun expandToGroups(elements: List<Element>, ids: Set<String>): Set<String> {
        if (ids.isEmpty()) return ids
        val groups = elements.filter { it.id in ids }.mapNotNull { it.groupId }.toHashSet()
        if (groups.isEmpty()) return ids
        val out = LinkedHashSet(ids)
        for (e in elements) if (e.groupId in groups) out.add(e.id)
        return out
    }

    fun selectionBounds(elements: List<Element>, ids: Set<String>): Rect? {
        var r: Rect? = null
        for (e in elements) {
            if (e.id !in ids) continue
            val b = e.bounds()
            r = if (r == null) b else r.union(b)
        }
        return r
    }

    fun transform(elements: List<Element>, ids: Set<String>, m: Affine): List<Element> {
        if (ids.isEmpty()) return elements
        return elements.map { if (it.id in ids) it.transformed(m) else it }
    }

    fun delete(elements: List<Element>, ids: Set<String>): List<Element> {
        if (ids.isEmpty()) return elements
        return elements.filter { it.id !in ids }
    }

    fun snapshot(elements: List<Element>, ids: Set<String>): List<Element> =
        elements.filter { it.id in ids }

    /** Inserts copies of [source] (new ids, new group ids) offset by (dx, dy). Returns new list and new ids. */
    fun insertCopies(
        elements: List<Element>,
        source: List<Element>,
        layerIdOverride: String?,
        dx: Float,
        dy: Float
    ): Pair<List<Element>, Set<String>> {
        if (source.isEmpty()) return elements to emptySet()
        val groupMap = HashMap<String, String>()
        val move = Affine.translate(dx, dy)
        val copies = source.map { e ->
            val newGroup = e.groupId?.let { g -> groupMap.getOrPut(g) { IdGen.next() } }
            e.transformed(move).withMeta(
                id = IdGen.next(),
                layerId = layerIdOverride ?: e.layerId,
                groupId = newGroup
            )
        }
        return (elements + copies) to copies.map { it.id }.toSet()
    }

    fun group(elements: List<Element>, ids: Set<String>): List<Element> {
        if (ids.size < 2) return elements
        val g = IdGen.next()
        return elements.map { if (it.id in ids) it.withMeta(groupId = g) else it }
    }

    fun ungroup(elements: List<Element>, ids: Set<String>): List<Element> {
        if (ids.isEmpty()) return elements
        return elements.map { if (it.id in ids && it.groupId != null) it.withMeta(groupId = null) else it }
    }

    fun bringToFront(elements: List<Element>, ids: Set<String>): List<Element> {
        if (ids.isEmpty()) return elements
        val (sel, rest) = elements.partition { it.id in ids }
        return rest + sel
    }

    fun sendToBack(elements: List<Element>, ids: Set<String>): List<Element> {
        if (ids.isEmpty()) return elements
        val (sel, rest) = elements.partition { it.id in ids }
        return sel + rest
    }

    fun moveToLayer(elements: List<Element>, ids: Set<String>, layerId: String): List<Element> =
        elements.map { if (it.id in ids) it.withMeta(layerId = layerId) else it }
}

object LayerOps {

    fun add(c: PageContent, name: String): Pair<PageContent, String> {
        val layer = Layer(IdGen.next(), name)
        return c.copy(layers = c.layers + layer) to layer.id
    }

    /** Removes a layer and all of its elements. The last remaining layer cannot be removed. */
    fun remove(c: PageContent, layerId: String): PageContent {
        if (c.layers.size <= 1 || c.layers.none { it.id == layerId }) return c
        return PageContent(
            layers = c.layers.filter { it.id != layerId },
            elements = c.elements.filter { it.layerId != layerId }
        )
    }

    fun rename(c: PageContent, layerId: String, name: String): PageContent =
        c.copy(layers = c.layers.map { if (it.id == layerId) it.copy(name = name) else it })

    fun setVisible(c: PageContent, layerId: String, visible: Boolean): PageContent =
        c.copy(layers = c.layers.map { if (it.id == layerId) it.copy(visible = visible) else it })

    fun setLocked(c: PageContent, layerId: String, locked: Boolean): PageContent =
        c.copy(layers = c.layers.map { if (it.id == layerId) it.copy(locked = locked) else it })

    /** Moves a layer by [delta] positions in the stack (positive = towards the top). */
    fun move(c: PageContent, layerId: String, delta: Int): PageContent {
        val i = c.layers.indexOfFirst { it.id == layerId }
        if (i < 0) return c
        val j = (i + delta).coerceIn(0, c.layers.size - 1)
        if (i == j) return c
        val list = c.layers.toMutableList()
        val l = list.removeAt(i)
        list.add(j, l)
        return c.copy(layers = list)
    }
}
